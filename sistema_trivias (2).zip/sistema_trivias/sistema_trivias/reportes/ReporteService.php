<?php

namespace App\Reportes;

use App\Config\Database;
use App\Interfaces\ReporteInterface;
use PDO;

/**
 * ReporteService
 * Centraliza las consultas de estadísticas para que tanto la página
 * del reporte (reporte_jugadores.php) como el exportador a Excel
 * (reporte_exportar_excel.php) usen exactamente los mismos datos.
 */
class ReporteService implements ReporteInterface
{
    private PDO $conexion;

    public function __construct(private Database $database)
    {
        $this->conexion = $this->database->obtenerConexion();
    }

    public function obtenerReportePorJugador(): array
    {
        $stmt = $this->conexion->query(
            "SELECT
                u.id_usuario,
                u.nombre,
                u.apodo,
                u.correo,
                u.estado,
                u.puntos_totales,
                COUNT(DISTINCT pj.id_partida_jugador) AS partidas_jugadas,
                ROUND(AVG(pj.tiempo_respuesta_promedio), 2) AS tiempo_promedio_seg,
                COUNT(ru.id_respuesta_usuario) AS total_respuestas,
                COALESCE(SUM(ru.es_correcta), 0) AS total_correctas,
                CASE
                    WHEN COUNT(ru.id_respuesta_usuario) > 0
                    THEN ROUND(SUM(ru.es_correcta) / COUNT(ru.id_respuesta_usuario) * 100, 2)
                    ELSE 0
                END AS porcentaje_aciertos
             FROM usuario u
             LEFT JOIN partida_jugador pj ON pj.id_usuario = u.id_usuario
             LEFT JOIN respuesta_usuario ru ON ru.id_partida_jugador = pj.id_partida_jugador
             WHERE u.id_rol = 1
             GROUP BY u.id_usuario, u.nombre, u.apodo, u.correo, u.estado, u.puntos_totales
             ORDER BY u.puntos_totales DESC, partidas_jugadas DESC"
        );

        return $stmt->fetchAll();
    }


    public function obtenerTotalesGenerales(): array
    {
        $stmt = $this->conexion->query(
            "SELECT
                COUNT(DISTINCT u.id_usuario) AS total_jugadores,
                COUNT(DISTINCT pj.id_partida_jugador) AS total_partidas,
                ROUND(AVG(pj.tiempo_respuesta_promedio), 2) AS tiempo_promedio_global,
                CASE
                    WHEN COUNT(ru.id_respuesta_usuario) > 0
                    THEN ROUND(SUM(ru.es_correcta) / COUNT(ru.id_respuesta_usuario) * 100, 2)
                    ELSE 0
                END AS porcentaje_aciertos_global
             FROM usuario u
             LEFT JOIN partida_jugador pj ON pj.id_usuario = u.id_usuario
             LEFT JOIN respuesta_usuario ru ON ru.id_partida_jugador = pj.id_partida_jugador
             WHERE u.id_rol = 1"
        );

        $fila = $stmt->fetch();

        return [
            'total_jugadores'           => (int) ($fila['total_jugadores'] ?? 0),
            'total_partidas'            => (int) ($fila['total_partidas'] ?? 0),
            'tiempo_promedio_global'    => $fila['tiempo_promedio_global'] !== null ? (float) $fila['tiempo_promedio_global'] : null,
            'porcentaje_aciertos_global'=> (float) ($fila['porcentaje_aciertos_global'] ?? 0),
        ];
    }

    public function obtenerDistribucionPorNivel(): array
    {
        $stmt = $this->conexion->query(
            "SELECT
                n.id_nivel,
                n.nombre_nivel,
                n.orden,
                COUNT(up.id_progreso) AS total_intentos,
                SUM(CASE WHEN up.estado = 'aprobado' THEN 1 ELSE 0 END) AS total_aprobados
             FROM nivel_conocimiento n
             LEFT JOIN tema_nivel tn ON tn.id_nivel = n.id_nivel
             LEFT JOIN usuario_progreso up ON up.id_tema_nivel = tn.id_tema_nivel
             GROUP BY n.id_nivel, n.nombre_nivel, n.orden
             ORDER BY n.orden"
        );

        return $stmt->fetchAll();
    }
}
