-- =========================================================
-- SEED DE PREGUNTAS PARA TODOS LOS NIVELES
--
-- Agrega 10 preguntas (opcion_multiple / verdadero_falso), con sus
-- opciones de respuesta, a cada uno de los 8 niveles existentes:
-- PHP Básico, PHP Intermedio (Bases de Datos), PHP Avanzado,
-- JavaScript Básico, JavaScript Intermedio, JavaScript Avanzado,
-- Laravel Intermedio y Laravel Avanzado.
--
-- Es seguro ejecutar este script varias veces: no duplica preguntas
-- ni opciones si ya existen (usa WHERE NOT EXISTS con comparación
-- binaria para evitar falsos positivos por mayúsculas/minúsculas).
--
-- Los niveles se identifican por tema (PHP/JavaScript/Laravel) y
-- por el 'orden' del nivel de conocimiento (1=Básico/Novato,
-- 2=Intermedio, 3=Avanzado) en lugar del texto con tildes, para
-- evitar problemas si la base de datos fue importada con una
-- codificación de caracteres distinta a utf8mb4.
--
-- Cómo ejecutarlo (ejemplo por línea de comandos):
--   mysql --default-character-set=utf8mb4 -u tu_usuario -p sistema_trivias < preguntas_seed.sql
-- =========================================================

SET NAMES utf8mb4;
USE sistema_trivias;
SET @id_creador = COALESCE(
    (SELECT u.id_usuario FROM usuario u
     JOIN rol r ON r.id_rol = u.id_rol
     WHERE r.nombre_rol IN ('administrador','armador')
     ORDER BY u.id_usuario LIMIT 1),
    (SELECT id_usuario FROM usuario ORDER BY id_usuario LIMIT 1)
);

-- =========================================================
-- NIVEL: PHP Básico
-- =========================================================
SET @id_tema_nivel = (
    SELECT tn.id_tema_nivel FROM tema_nivel tn
    JOIN tema t ON t.id_tema = tn.id_tema
    JOIN nivel_conocimiento n ON n.id_nivel = tn.id_nivel
    WHERE t.nombre_tema = 'PHP' AND n.orden = 1
    LIMIT 1
);

-- Pregunta: ¿Cómo se declara una variable en PHP?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Cómo se declara una variable en PHP?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cómo se declara una variable en PHP?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cómo se declara una variable en PHP?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '$variable = valor;', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '$variable = valor;'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'var variable = valor;', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'var variable = valor;'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'variable := valor;', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'variable := valor;'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'let variable = valor;', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'let variable = valor;'
);

-- Pregunta: ¿Qué símbolo se usa para iniciar un bloque de código PHP?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué símbolo se usa para iniciar un bloque de código PHP?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué símbolo se usa para iniciar un bloque de código PHP?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué símbolo se usa para iniciar un bloque de código PHP?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '<?php', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '<?php'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '<script>', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '<script>'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '<%', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '<%'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '#!php', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '#!php'
);

-- Pregunta: ¿Cuál es la función más básica para imprimir texto en pantalla en PHP?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Cuál es la función más básica para imprimir texto en pantalla en PHP?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es la función más básica para imprimir texto en pantalla en PHP?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es la función más básica para imprimir texto en pantalla en PHP?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'echo', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'echo'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'console.log', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'console.log'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'System.out.println', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'System.out.println'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Debug.Print', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Debug.Print'
);

-- Pregunta: ¿Cómo se concatenan cadenas de texto en PHP?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Cómo se concatenan cadenas de texto en PHP?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cómo se concatenan cadenas de texto en PHP?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cómo se concatenan cadenas de texto en PHP?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Con el operador .', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Con el operador .'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Con el operador +', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Con el operador +'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Con el operador &', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Con el operador &'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Con la función concat()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Con la función concat()'
);

-- Pregunta: ¿Cuál de los siguientes es un array asociativo válido en PHP?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Cuál de los siguientes es un array asociativo válido en PHP?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál de los siguientes es un array asociativo válido en PHP?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál de los siguientes es un array asociativo válido en PHP?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '$a = array("clave" => "valor");', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '$a = array("clave" => "valor");'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '$a = {"clave": "valor"};', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '$a = {"clave": "valor"};'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '$a = ["clave" -> "valor"];', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '$a = ["clave" -> "valor"];'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '$a = new Map("clave", "valor");', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '$a = new Map("clave", "valor");'
);

-- Pregunta: ¿Qué función determina si una variable está definida y no es null?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué función determina si una variable está definida y no es null?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué función determina si una variable está definida y no es null?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué función determina si una variable está definida y no es null?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'isset()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'isset()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'empty()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'empty()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'is_null()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'is_null()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'exists()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'exists()'
);

-- Pregunta: ¿Cuál es el operador de comparación estricta en PHP (compara valor y t...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Cuál es el operador de comparación estricta en PHP (compara valor y tipo)?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es el operador de comparación estricta en PHP (compara valor y tipo)?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es el operador de comparación estricta en PHP (compara valor y tipo)?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '===', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '==='
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '==', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '=='
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '=', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '='
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '<=>', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '<=>'
);

-- Pregunta: ¿Qué estructura de control se usa para repetir un bloque de código mie...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué estructura de control se usa para repetir un bloque de código mientras una condición sea verdadera?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué estructura de control se usa para repetir un bloque de código mientras una condición sea verdadera?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué estructura de control se usa para repetir un bloque de código mientras una condición sea verdadera?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'while', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'while'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'switch', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'switch'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'if', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'if'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'function', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'function'
);

-- Pregunta: PHP es un lenguaje de script que se ejecuta principalmente del lado de...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, 'PHP es un lenguaje de script que se ejecuta principalmente del lado del servidor.', 'verdadero_falso', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'PHP es un lenguaje de script que se ejecuta principalmente del lado del servidor.'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'PHP es un lenguaje de script que se ejecuta principalmente del lado del servidor.' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Verdadero', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Verdadero'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Falso', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Falso'
);

-- Pregunta: ¿Qué función convierte una cadena a mayúsculas en PHP?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué función convierte una cadena a mayúsculas en PHP?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué función convierte una cadena a mayúsculas en PHP?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué función convierte una cadena a mayúsculas en PHP?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'strtoupper()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'strtoupper()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'toUpperCase()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'toUpperCase()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'upper()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'upper()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'strToUpper()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'strToUpper()'
);

-- =========================================================
-- NIVEL: PHP Intermedio (Bases de Datos)
-- =========================================================
SET @id_tema_nivel = (
    SELECT tn.id_tema_nivel FROM tema_nivel tn
    JOIN tema t ON t.id_tema = tn.id_tema
    JOIN nivel_conocimiento n ON n.id_nivel = tn.id_nivel
    WHERE t.nombre_tema = 'PHP' AND n.orden = 2
    LIMIT 1
);

-- Pregunta: ¿Qué extensión de PHP se recomienda actualmente para conectarse a base...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué extensión de PHP se recomienda actualmente para conectarse a bases de datos de forma orientada a objetos y con soporte multi-motor?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué extensión de PHP se recomienda actualmente para conectarse a bases de datos de forma orientada a objetos y con soporte multi-motor?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué extensión de PHP se recomienda actualmente para conectarse a bases de datos de forma orientada a objetos y con soporte multi-motor?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'PDO', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'PDO'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'mysql_connect', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'mysql_connect'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'ODBC clásico', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'ODBC clásico'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'curl', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'curl'
);

-- Pregunta: ¿Cuál es la principal ventaja de usar sentencias preparadas (prepared ...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Cuál es la principal ventaja de usar sentencias preparadas (prepared statements)?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es la principal ventaja de usar sentencias preparadas (prepared statements)?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es la principal ventaja de usar sentencias preparadas (prepared statements)?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Prevenir inyección SQL', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Prevenir inyección SQL'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Hacer las consultas más lentas', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Hacer las consultas más lentas'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Eliminar la necesidad de una base de datos', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Eliminar la necesidad de una base de datos'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Aumentar el tamaño del código', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Aumentar el tamaño del código'
);

-- Pregunta: ¿Qué método de PDO se usa para ejecutar una consulta preparada con par...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué método de PDO se usa para ejecutar una consulta preparada con parámetros?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método de PDO se usa para ejecutar una consulta preparada con parámetros?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método de PDO se usa para ejecutar una consulta preparada con parámetros?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'execute()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'execute()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'run()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'run()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'query()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'query()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'send()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'send()'
);

-- Pregunta: ¿Qué método de PDO obtiene todas las filas resultantes de una consulta...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué método de PDO obtiene todas las filas resultantes de una consulta?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método de PDO obtiene todas las filas resultantes de una consulta?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método de PDO obtiene todas las filas resultantes de una consulta?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'fetchAll()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'fetchAll()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'getAll()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'getAll()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'fetchRow()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'fetchRow()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'selectAll()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'selectAll()'
);

-- Pregunta: En una sentencia preparada con marcadores nombrados, ¿cómo se identifi...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, 'En una sentencia preparada con marcadores nombrados, ¿cómo se identifica un parámetro?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'En una sentencia preparada con marcadores nombrados, ¿cómo se identifica un parámetro?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'En una sentencia preparada con marcadores nombrados, ¿cómo se identifica un parámetro?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Con dos puntos, por ejemplo :nombre', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Con dos puntos, por ejemplo :nombre'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Con un símbolo de arroba @nombre', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Con un símbolo de arroba @nombre'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Con corchetes [nombre]', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Con corchetes [nombre]'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Con signo de dólar duplicado $$nombre', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Con signo de dólar duplicado $$nombre'
);

-- Pregunta: ¿Qué método se usa para iniciar una transacción en PDO?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué método se usa para iniciar una transacción en PDO?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método se usa para iniciar una transacción en PDO?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método se usa para iniciar una transacción en PDO?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'beginTransaction()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'beginTransaction()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'startTransaction()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'startTransaction()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'openTransaction()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'openTransaction()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'initTransaction()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'initTransaction()'
);

-- Pregunta: Usar concatenación directa de variables dentro de una consulta SQL es ...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, 'Usar concatenación directa de variables dentro de una consulta SQL es una práctica segura.', 'verdadero_falso', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'Usar concatenación directa de variables dentro de una consulta SQL es una práctica segura.'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'Usar concatenación directa de variables dentro de una consulta SQL es una práctica segura.' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Falso', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Falso'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Verdadero', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Verdadero'
);

-- Pregunta: ¿Qué método de PDO revierte los cambios de una transacción si ocurre u...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué método de PDO revierte los cambios de una transacción si ocurre un error?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método de PDO revierte los cambios de una transacción si ocurre un error?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método de PDO revierte los cambios de una transacción si ocurre un error?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'rollBack()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'rollBack()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'undo()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'undo()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'cancel()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'cancel()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'revert()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'revert()'
);

-- Pregunta: ¿Cuál es el método para obtener el último ID insertado en PDO?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Cuál es el método para obtener el último ID insertado en PDO?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es el método para obtener el último ID insertado en PDO?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es el método para obtener el último ID insertado en PDO?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'lastInsertId()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'lastInsertId()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'getLastId()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'getLastId()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'lastId()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'lastId()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'insertId()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'insertId()'
);

-- Pregunta: ¿Qué tipo de JOIN devuelve solo las filas que tienen coincidencia en a...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué tipo de JOIN devuelve solo las filas que tienen coincidencia en ambas tablas?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué tipo de JOIN devuelve solo las filas que tienen coincidencia en ambas tablas?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué tipo de JOIN devuelve solo las filas que tienen coincidencia en ambas tablas?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'INNER JOIN', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'INNER JOIN'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'LEFT JOIN', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'LEFT JOIN'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'RIGHT JOIN', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'RIGHT JOIN'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'CROSS JOIN', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'CROSS JOIN'
);

-- =========================================================
-- NIVEL: PHP Avanzado
-- =========================================================
SET @id_tema_nivel = (
    SELECT tn.id_tema_nivel FROM tema_nivel tn
    JOIN tema t ON t.id_tema = tn.id_tema
    JOIN nivel_conocimiento n ON n.id_nivel = tn.id_nivel
    WHERE t.nombre_tema = 'PHP' AND n.orden = 3
    LIMIT 1
);

-- Pregunta: ¿Qué palabra clave se usa en PHP para definir una interfaz?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué palabra clave se usa en PHP para definir una interfaz?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué palabra clave se usa en PHP para definir una interfaz?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué palabra clave se usa en PHP para definir una interfaz?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'interface', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'interface'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'abstract', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'abstract'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'trait', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'trait'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'implements', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'implements'
);

-- Pregunta: ¿Qué permite reutilizar métodos entre clases sin usar herencia múltipl...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué permite reutilizar métodos entre clases sin usar herencia múltiple en PHP?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué permite reutilizar métodos entre clases sin usar herencia múltiple en PHP?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué permite reutilizar métodos entre clases sin usar herencia múltiple en PHP?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Traits', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Traits'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Interfaces', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Interfaces'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Namespaces', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Namespaces'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Constantes', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Constantes'
);

-- Pregunta: ¿Qué palabra clave se usa para que una clase herede de otra en PHP?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué palabra clave se usa para que una clase herede de otra en PHP?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué palabra clave se usa para que una clase herede de otra en PHP?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué palabra clave se usa para que una clase herede de otra en PHP?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'extends', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'extends'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'implements', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'implements'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'inherits', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'inherits'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'using', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'using'
);

-- Pregunta: ¿Qué modificador permite acceder a una propiedad o método sin instanci...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué modificador permite acceder a una propiedad o método sin instanciar la clase?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué modificador permite acceder a una propiedad o método sin instanciar la clase?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué modificador permite acceder a una propiedad o método sin instanciar la clase?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'static', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'static'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'public', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'public'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'protected', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'protected'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'final', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'final'
);

-- Pregunta: ¿Qué mecanismo permite capturar y manejar errores en tiempo de ejecuci...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué mecanismo permite capturar y manejar errores en tiempo de ejecución en PHP?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué mecanismo permite capturar y manejar errores en tiempo de ejecución en PHP?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué mecanismo permite capturar y manejar errores en tiempo de ejecución en PHP?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'try/catch', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'try/catch'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'if/else', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'if/else'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'switch/case', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'switch/case'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'foreach', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'foreach'
);

-- Pregunta: ¿Qué palabra clave evita que una clase pueda ser heredada?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué palabra clave evita que una clase pueda ser heredada?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué palabra clave evita que una clase pueda ser heredada?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué palabra clave evita que una clase pueda ser heredada?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'final', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'final'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'static', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'static'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'abstract', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'abstract'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'const', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'const'
);

-- Pregunta: Una clase abstracta en PHP puede ser instanciada directamente....
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, 'Una clase abstracta en PHP puede ser instanciada directamente.', 'verdadero_falso', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'Una clase abstracta en PHP puede ser instanciada directamente.'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'Una clase abstracta en PHP puede ser instanciada directamente.' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Falso', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Falso'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Verdadero', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Verdadero'
);

-- Pregunta: ¿Qué patrón de diseño garantiza que una clase tenga una única instanci...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué patrón de diseño garantiza que una clase tenga una única instancia?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué patrón de diseño garantiza que una clase tenga una única instancia?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué patrón de diseño garantiza que una clase tenga una única instancia?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Singleton', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Singleton'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Factory', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Factory'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Observer', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Observer'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Strategy', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Strategy'
);

-- Pregunta: ¿Qué función estándar se usa para registrar un autoloader de clases en...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué función estándar se usa para registrar un autoloader de clases en PHP (base de PSR-4 con Composer)?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué función estándar se usa para registrar un autoloader de clases en PHP (base de PSR-4 con Composer)?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué función estándar se usa para registrar un autoloader de clases en PHP (base de PSR-4 con Composer)?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'spl_autoload_register', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'spl_autoload_register'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'include_all()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'include_all()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'autoload_classes()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'autoload_classes()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'require_all()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'require_all()'
);

-- Pregunta: ¿Qué visibilidad permite que un método sea accedido solo desde la mism...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué visibilidad permite que un método sea accedido solo desde la misma clase y sus clases hijas?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué visibilidad permite que un método sea accedido solo desde la misma clase y sus clases hijas?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué visibilidad permite que un método sea accedido solo desde la misma clase y sus clases hijas?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'protected', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'protected'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'public', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'public'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'private', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'private'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'static', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'static'
);

-- =========================================================
-- NIVEL: JavaScript Básico
-- =========================================================
SET @id_tema_nivel = (
    SELECT tn.id_tema_nivel FROM tema_nivel tn
    JOIN tema t ON t.id_tema = tn.id_tema
    JOIN nivel_conocimiento n ON n.id_nivel = tn.id_nivel
    WHERE t.nombre_tema = 'JavaScript' AND n.orden = 1
    LIMIT 1
);

-- Pregunta: ¿Qué palabra clave se recomienda actualmente para declarar variables c...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué palabra clave se recomienda actualmente para declarar variables cuyo valor no cambiará?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué palabra clave se recomienda actualmente para declarar variables cuyo valor no cambiará?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué palabra clave se recomienda actualmente para declarar variables cuyo valor no cambiará?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'const', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'const'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'var', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'var'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'let', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'let'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'static', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'static'
);

-- Pregunta: ¿Qué método se usa para mostrar un mensaje en la consola del navegador...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué método se usa para mostrar un mensaje en la consola del navegador?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método se usa para mostrar un mensaje en la consola del navegador?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método se usa para mostrar un mensaje en la consola del navegador?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'console.log()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'console.log()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'print()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'print()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'echo()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'echo()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'alert.log()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'alert.log()'
);

-- Pregunta: ¿Cuál es el resultado de typeof "hola" en JavaScript?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Cuál es el resultado de typeof "hola" en JavaScript?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es el resultado de typeof "hola" en JavaScript?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es el resultado de typeof "hola" en JavaScript?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '"string"', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '"string"'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '"text"', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '"text"'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '"char"', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '"char"'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '"str"', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '"str"'
);

-- Pregunta: ¿Qué método agrega un elemento al final de un array?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué método agrega un elemento al final de un array?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método agrega un elemento al final de un array?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método agrega un elemento al final de un array?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'push()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'push()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'add()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'add()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'append()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'append()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'insert()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'insert()'
);

-- Pregunta: ¿Qué operador se usa para comparar valor y tipo en JavaScript?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué operador se usa para comparar valor y tipo en JavaScript?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué operador se usa para comparar valor y tipo en JavaScript?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué operador se usa para comparar valor y tipo en JavaScript?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '===', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '==='
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '==', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '=='
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '=', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '='
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '!=', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '!='
);

-- Pregunta: ¿Qué estructura se usa para ejecutar código solo si una condición se c...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué estructura se usa para ejecutar código solo si una condición se cumple?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué estructura se usa para ejecutar código solo si una condición se cumple?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué estructura se usa para ejecutar código solo si una condición se cumple?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'if', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'if'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'for', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'for'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'function', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'function'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'class', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'class'
);

-- Pregunta: En JavaScript, 'let' tiene alcance de bloque (block scope)....
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, 'En JavaScript, \'let\' tiene alcance de bloque (block scope).', 'verdadero_falso', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'En JavaScript, \'let\' tiene alcance de bloque (block scope).'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'En JavaScript, \'let\' tiene alcance de bloque (block scope).' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Verdadero', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Verdadero'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Falso', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Falso'
);

-- Pregunta: ¿Qué método selecciona un elemento del DOM por su id?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué método selecciona un elemento del DOM por su id?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método selecciona un elemento del DOM por su id?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método selecciona un elemento del DOM por su id?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'document.getElementById()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'document.getElementById()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'document.query()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'document.query()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'document.find()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'document.find()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'document.selectId()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'document.selectId()'
);

-- Pregunta: ¿Cómo se define correctamente una función flecha (arrow function) en J...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Cómo se define correctamente una función flecha (arrow function) en JavaScript?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cómo se define correctamente una función flecha (arrow function) en JavaScript?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cómo se define correctamente una función flecha (arrow function) en JavaScript?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'const suma = (a, b) => a + b;', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'const suma = (a, b) => a + b;'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'function => suma(a, b) { a + b }', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'function => suma(a, b) { a + b }'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'const suma = function:(a,b) a+b', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'const suma = function:(a,b) a+b'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'suma := (a,b) -> a+b', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'suma := (a,b) -> a+b'
);

-- Pregunta: ¿Cuál es el valor de Boolean(0) en JavaScript?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Cuál es el valor de Boolean(0) en JavaScript?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es el valor de Boolean(0) en JavaScript?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es el valor de Boolean(0) en JavaScript?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'false', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'false'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'true', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'true'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'undefined', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'undefined'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'NaN', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'NaN'
);

-- =========================================================
-- NIVEL: JavaScript Intermedio
-- =========================================================
SET @id_tema_nivel = (
    SELECT tn.id_tema_nivel FROM tema_nivel tn
    JOIN tema t ON t.id_tema = tn.id_tema
    JOIN nivel_conocimiento n ON n.id_nivel = tn.id_nivel
    WHERE t.nombre_tema = 'JavaScript' AND n.orden = 2
    LIMIT 1
);

-- Pregunta: ¿Qué es una closure (clausura) en JavaScript?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué es una closure (clausura) en JavaScript?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué es una closure (clausura) en JavaScript?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué es una closure (clausura) en JavaScript?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Una función que recuerda el entorno donde fue creada', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Una función que recuerda el entorno donde fue creada'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Un tipo de bucle', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Un tipo de bucle'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Un método para cerrar el navegador', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Un método para cerrar el navegador'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Una forma de eliminar variables', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Una forma de eliminar variables'
);

-- Pregunta: ¿Qué método transforma cada elemento de un array y devuelve un nuevo a...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué método transforma cada elemento de un array y devuelve un nuevo array?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método transforma cada elemento de un array y devuelve un nuevo array?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método transforma cada elemento de un array y devuelve un nuevo array?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'map()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'map()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'forEach()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'forEach()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'filter()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'filter()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'reduce()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'reduce()'
);

-- Pregunta: ¿Qué método filtra los elementos de un array según una condición?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué método filtra los elementos de un array según una condición?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método filtra los elementos de un array según una condición?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método filtra los elementos de un array según una condición?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'filter()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'filter()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'map()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'map()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'find()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'find()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'some()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'some()'
);

-- Pregunta: ¿Qué representa una Promise en JavaScript?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué representa una Promise en JavaScript?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué representa una Promise en JavaScript?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué representa una Promise en JavaScript?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Un objeto que representa la eventual finalización de una operación asíncrona', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Un objeto que representa la eventual finalización de una operación asíncrona'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Una variable global', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Una variable global'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Un tipo de bucle infinito', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Un tipo de bucle infinito'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Una función síncrona', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Una función síncrona'
);

-- Pregunta: ¿Qué técnica permite extraer valores de un array u objeto en variables...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué técnica permite extraer valores de un array u objeto en variables individuales?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué técnica permite extraer valores de un array u objeto en variables individuales?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué técnica permite extraer valores de un array u objeto en variables individuales?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Destructuring (usando { } o [ ])', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Destructuring (usando { } o [ ])'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Spread', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Spread'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Import', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Import'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Export', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Export'
);

-- Pregunta: ¿Qué hace el operador spread (...) con un array?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué hace el operador spread (...) con un array?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué hace el operador spread (...) con un array?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué hace el operador spread (...) con un array?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Expande sus elementos individualmente', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Expande sus elementos individualmente'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Los convierte en un string', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Los convierte en un string'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Elimina los duplicados', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Elimina los duplicados'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Los ordena alfabéticamente', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Los ordena alfabéticamente'
);

-- Pregunta: El método reduce() de un array siempre devuelve un array....
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, 'El método reduce() de un array siempre devuelve un array.', 'verdadero_falso', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'El método reduce() de un array siempre devuelve un array.'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'El método reduce() de un array siempre devuelve un array.' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Falso', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Falso'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Verdadero', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Verdadero'
);

-- Pregunta: ¿Qué valor de 'this' tiene una función flecha (arrow function)?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué valor de \'this\' tiene una función flecha (arrow function)?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué valor de \'this\' tiene una función flecha (arrow function)?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué valor de \'this\' tiene una función flecha (arrow function)?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'El mismo \'this\' del contexto donde fue definida', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'El mismo \'this\' del contexto donde fue definida'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Siempre apunta al objeto global', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Siempre apunta al objeto global'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Siempre es undefined', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Siempre es undefined'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Cambia dinámicamente según quién la llame', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Cambia dinámicamente según quién la llame'
);

-- Pregunta: ¿Qué método convierte un array en un solo valor acumulado?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué método convierte un array en un solo valor acumulado?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método convierte un array en un solo valor acumulado?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método convierte un array en un solo valor acumulado?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'reduce()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'reduce()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'map()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'map()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'concat()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'concat()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'join()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'join()'
);

-- Pregunta: ¿Cómo se declara una plantilla de cadena (template literal) en JavaScr...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Cómo se declara una plantilla de cadena (template literal) en JavaScript?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cómo se declara una plantilla de cadena (template literal) en JavaScript?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cómo se declara una plantilla de cadena (template literal) en JavaScript?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Con comillas invertidas (backticks)', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Con comillas invertidas (backticks)'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Con comillas dobles ""', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Con comillas dobles ""'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Con comillas simples \'\'', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Con comillas simples \'\''
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Con corchetes []', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Con corchetes []'
);

-- =========================================================
-- NIVEL: JavaScript Avanzado
-- =========================================================
SET @id_tema_nivel = (
    SELECT tn.id_tema_nivel FROM tema_nivel tn
    JOIN tema t ON t.id_tema = tn.id_tema
    JOIN nivel_conocimiento n ON n.id_nivel = tn.id_nivel
    WHERE t.nombre_tema = 'JavaScript' AND n.orden = 3
    LIMIT 1
);

-- Pregunta: ¿Qué palabra clave se usa junto con async para esperar la resolución d...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué palabra clave se usa junto con async para esperar la resolución de una promesa?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué palabra clave se usa junto con async para esperar la resolución de una promesa?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué palabra clave se usa junto con async para esperar la resolución de una promesa?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'await', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'await'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'then', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'then'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'resolve', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'resolve'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'yield', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'yield'
);

-- Pregunta: ¿Qué es el Event Loop en JavaScript?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué es el Event Loop en JavaScript?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué es el Event Loop en JavaScript?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué es el Event Loop en JavaScript?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'El mecanismo que gestiona la ejecución de código asíncrono y la cola de tareas', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'El mecanismo que gestiona la ejecución de código asíncrono y la cola de tareas'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Un bucle for infinito', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Un bucle for infinito'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Un método del DOM', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Un método del DOM'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Una librería externa', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Una librería externa'
);

-- Pregunta: ¿Qué método permite ejecutar múltiples promesas en paralelo y esperar ...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué método permite ejecutar múltiples promesas en paralelo y esperar a que todas se resuelvan?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método permite ejecutar múltiples promesas en paralelo y esperar a que todas se resuelvan?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método permite ejecutar múltiples promesas en paralelo y esperar a que todas se resuelvan?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Promise.all()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Promise.all()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Promise.wait()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Promise.wait()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Promise.sync()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Promise.sync()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Promise.chain()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Promise.chain()'
);

-- Pregunta: ¿Qué mecanismo permite a los objetos de JavaScript heredar propiedades...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué mecanismo permite a los objetos de JavaScript heredar propiedades de otros objetos?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué mecanismo permite a los objetos de JavaScript heredar propiedades de otros objetos?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué mecanismo permite a los objetos de JavaScript heredar propiedades de otros objetos?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Prototype (prototipo)', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Prototype (prototipo)'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Interfaces', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Interfaces'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Traits', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Traits'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Namespaces', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Namespaces'
);

-- Pregunta: ¿Qué son las funciones de orden superior (higher order functions)?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué son las funciones de orden superior (higher order functions)?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué son las funciones de orden superior (higher order functions)?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué son las funciones de orden superior (higher order functions)?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Funciones que reciben o devuelven otras funciones', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Funciones que reciben o devuelven otras funciones'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Funciones que solo trabajan con números', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Funciones que solo trabajan con números'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Funciones definidas dentro de una clase', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Funciones definidas dentro de una clase'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Funciones que no aceptan parámetros', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Funciones que no aceptan parámetros'
);

-- Pregunta: ¿Qué sistema de módulos usa las palabras clave import y export de form...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué sistema de módulos usa las palabras clave import y export de forma nativa?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué sistema de módulos usa las palabras clave import y export de forma nativa?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué sistema de módulos usa las palabras clave import y export de forma nativa?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'ES Modules', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'ES Modules'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'CommonJS', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'CommonJS'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'AMD', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'AMD'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'UMD', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'UMD'
);

-- Pregunta: JavaScript es un lenguaje de un solo hilo (single-threaded) en su ejec...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, 'JavaScript es un lenguaje de un solo hilo (single-threaded) en su ejecución principal.', 'verdadero_falso', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'JavaScript es un lenguaje de un solo hilo (single-threaded) en su ejecución principal.'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'JavaScript es un lenguaje de un solo hilo (single-threaded) en su ejecución principal.' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Verdadero', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Verdadero'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Falso', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Falso'
);

-- Pregunta: ¿Qué hace el método Object.freeze()?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué hace el método Object.freeze()?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué hace el método Object.freeze()?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué hace el método Object.freeze()?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Impide que se modifiquen las propiedades de un objeto', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Impide que se modifiquen las propiedades de un objeto'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Elimina el objeto de la memoria', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Elimina el objeto de la memoria'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Convierte el objeto en un array', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Convierte el objeto en un array'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Clona el objeto de forma profunda', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Clona el objeto de forma profunda'
);

-- Pregunta: ¿Qué es un generator (función generadora) en JavaScript?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué es un generator (función generadora) en JavaScript?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué es un generator (función generadora) en JavaScript?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué es un generator (función generadora) en JavaScript?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Una función que puede pausar y reanudar su ejecución usando yield', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Una función que puede pausar y reanudar su ejecución usando yield'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Una función que genera números aleatorios', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Una función que genera números aleatorios'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Un tipo de bucle for', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Un tipo de bucle for'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Una función que siempre retorna una promesa', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Una función que siempre retorna una promesa'
);

-- Pregunta: ¿Qué operador se usa para acceder de forma segura a propiedades anidad...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué operador se usa para acceder de forma segura a propiedades anidadas que podrían no existir?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué operador se usa para acceder de forma segura a propiedades anidadas que podrían no existir?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué operador se usa para acceder de forma segura a propiedades anidadas que podrían no existir?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '?. (optional chaining)', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '?. (optional chaining)'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '??', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '??'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '&&', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '&&'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '!!', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '!!'
);

-- =========================================================
-- NIVEL: Laravel Intermedio
-- =========================================================
SET @id_tema_nivel = (
    SELECT tn.id_tema_nivel FROM tema_nivel tn
    JOIN tema t ON t.id_tema = tn.id_tema
    JOIN nivel_conocimiento n ON n.id_nivel = tn.id_nivel
    WHERE t.nombre_tema = 'Laravel' AND n.orden = 2
    LIMIT 1
);

-- Pregunta: ¿Qué archivo define las rutas web principales de una aplicación Larave...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué archivo define las rutas web principales de una aplicación Laravel?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué archivo define las rutas web principales de una aplicación Laravel?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué archivo define las rutas web principales de una aplicación Laravel?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'routes/web.php', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'routes/web.php'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'app/routes.php', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'app/routes.php'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'config/routes.php', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'config/routes.php'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'public/routes.php', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'public/routes.php'
);

-- Pregunta: ¿Qué comando de Artisan crea un nuevo controlador?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué comando de Artisan crea un nuevo controlador?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué comando de Artisan crea un nuevo controlador?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué comando de Artisan crea un nuevo controlador?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan make:controller', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan make:controller'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan create:controller', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan create:controller'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan new:controller', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan new:controller'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan generate:controller', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan generate:controller'
);

-- Pregunta: ¿Qué motor de plantillas usa Laravel por defecto?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué motor de plantillas usa Laravel por defecto?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué motor de plantillas usa Laravel por defecto?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué motor de plantillas usa Laravel por defecto?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Blade', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Blade'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Twig', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Twig'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Smarty', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Smarty'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Handlebars', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Handlebars'
);

-- Pregunta: ¿Qué componente de Laravel se usa para el mapeo objeto-relacional (ORM...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué componente de Laravel se usa para el mapeo objeto-relacional (ORM)?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué componente de Laravel se usa para el mapeo objeto-relacional (ORM)?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué componente de Laravel se usa para el mapeo objeto-relacional (ORM)?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Eloquent', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Eloquent'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Doctrine', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Doctrine'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'PDO Manager', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'PDO Manager'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'QueryBuilder Plus', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'QueryBuilder Plus'
);

-- Pregunta: ¿Qué comando de Artisan genera una nueva migración?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué comando de Artisan genera una nueva migración?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué comando de Artisan genera una nueva migración?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué comando de Artisan genera una nueva migración?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan make:migration', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan make:migration'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan make:db', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan make:db'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan create:table', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan create:table'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan db:new', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan db:new'
);

-- Pregunta: ¿Cuál es la sintaxis correcta de Blade para imprimir una variable esca...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Cuál es la sintaxis correcta de Blade para imprimir una variable escapada?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es la sintaxis correcta de Blade para imprimir una variable escapada?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Cuál es la sintaxis correcta de Blade para imprimir una variable escapada?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '{{ $variable }}', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '{{ $variable }}'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '<?= $variable ?>', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '<?= $variable ?>'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '{% variable %}', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '{% variable %}'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '{$variable}', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '{$variable}'
);

-- Pregunta: ¿Qué método de Eloquent obtiene todos los registros de un modelo?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué método de Eloquent obtiene todos los registros de un modelo?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método de Eloquent obtiene todos los registros de un modelo?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué método de Eloquent obtiene todos los registros de un modelo?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'all()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'all()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'getAll()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'getAll()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'fetchAll()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'fetchAll()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'list()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'list()'
);

-- Pregunta: En Laravel, el archivo .env se usa para almacenar variables de entorno...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, 'En Laravel, el archivo .env se usa para almacenar variables de entorno y configuración sensible.', 'verdadero_falso', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'En Laravel, el archivo .env se usa para almacenar variables de entorno y configuración sensible.'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'En Laravel, el archivo .env se usa para almacenar variables de entorno y configuración sensible.' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Verdadero', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Verdadero'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Falso', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Falso'
);

-- Pregunta: ¿Qué comando ejecuta las migraciones pendientes?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué comando ejecuta las migraciones pendientes?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué comando ejecuta las migraciones pendientes?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué comando ejecuta las migraciones pendientes?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan migrate', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan migrate'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan db:migrate', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan db:migrate'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan run:migrations', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan run:migrations'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan migrate:run', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan migrate:run'
);

-- Pregunta: ¿Qué directiva de Blade se usa para extender una plantilla base?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué directiva de Blade se usa para extender una plantilla base?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué directiva de Blade se usa para extender una plantilla base?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué directiva de Blade se usa para extender una plantilla base?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '@extends', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '@extends'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '@include', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '@include'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '@layout', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '@layout'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, '@use', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY '@use'
);

-- =========================================================
-- NIVEL: Laravel Avanzado
-- =========================================================
SET @id_tema_nivel = (
    SELECT tn.id_tema_nivel FROM tema_nivel tn
    JOIN tema t ON t.id_tema = tn.id_tema
    JOIN nivel_conocimiento n ON n.id_nivel = tn.id_nivel
    WHERE t.nombre_tema = 'Laravel' AND n.orden = 3
    LIMIT 1
);

-- Pregunta: ¿Qué son los Middleware en Laravel?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué son los Middleware en Laravel?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué son los Middleware en Laravel?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué son los Middleware en Laravel?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Filtros que procesan las peticiones HTTP antes o después de llegar al controlador', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Filtros que procesan las peticiones HTTP antes o después de llegar al controlador'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Modelos de base de datos', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Modelos de base de datos'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Archivos de configuración', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Archivos de configuración'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Plantillas de vistas', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Plantillas de vistas'
);

-- Pregunta: ¿Qué clase se usa para registrar servicios y enlaces en el contenedor ...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué clase se usa para registrar servicios y enlaces en el contenedor de Laravel?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué clase se usa para registrar servicios y enlaces en el contenedor de Laravel?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué clase se usa para registrar servicios y enlaces en el contenedor de Laravel?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Service Provider', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Service Provider'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Facade', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Facade'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Kernel', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Kernel'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Middleware', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Middleware'
);

-- Pregunta: ¿Qué tipo de relación de Eloquent se usa cuando un modelo pertenece a ...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué tipo de relación de Eloquent se usa cuando un modelo pertenece a otro (relación inversa de uno a muchos)?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué tipo de relación de Eloquent se usa cuando un modelo pertenece a otro (relación inversa de uno a muchos)?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué tipo de relación de Eloquent se usa cuando un modelo pertenece a otro (relación inversa de uno a muchos)?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'belongsTo()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'belongsTo()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'hasMany()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'hasMany()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'hasOne()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'hasOne()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'belongsToMany()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'belongsToMany()'
);

-- Pregunta: ¿Qué sistema de Laravel permite ejecutar tareas en segundo plano fuera...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué sistema de Laravel permite ejecutar tareas en segundo plano fuera del ciclo de solicitud-respuesta?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué sistema de Laravel permite ejecutar tareas en segundo plano fuera del ciclo de solicitud-respuesta?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué sistema de Laravel permite ejecutar tareas en segundo plano fuera del ciclo de solicitud-respuesta?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Colas (Queues)', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Colas (Queues)'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Middleware', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Middleware'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Blade Components', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Blade Components'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Route Model Binding', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Route Model Binding'
);

-- Pregunta: ¿Qué patrón implementan las Facades de Laravel?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué patrón implementan las Facades de Laravel?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué patrón implementan las Facades de Laravel?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué patrón implementan las Facades de Laravel?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Proveer una interfaz estática simplificada a servicios del contenedor', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Proveer una interfaz estática simplificada a servicios del contenedor'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Encapsular consultas SQL directamente', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Encapsular consultas SQL directamente'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Generar automáticamente controladores', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Generar automáticamente controladores'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Reemplazar el sistema de rutas', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Reemplazar el sistema de rutas'
);

-- Pregunta: ¿Qué mecanismo de Laravel permite reaccionar a acciones del sistema, c...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué mecanismo de Laravel permite reaccionar a acciones del sistema, como el registro de un usuario, de forma desacoplada?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué mecanismo de Laravel permite reaccionar a acciones del sistema, como el registro de un usuario, de forma desacoplada?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué mecanismo de Laravel permite reaccionar a acciones del sistema, como el registro de un usuario, de forma desacoplada?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Eventos y Listeners', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Eventos y Listeners'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Middleware', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Middleware'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Migraciones', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Migraciones'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Seeders', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Seeders'
);

-- Pregunta: El Route Model Binding permite inyectar automáticamente una instancia ...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, 'El Route Model Binding permite inyectar automáticamente una instancia de modelo en un controlador según el parámetro de la ruta.', 'verdadero_falso', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'El Route Model Binding permite inyectar automáticamente una instancia de modelo en un controlador según el parámetro de la ruta.'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY 'El Route Model Binding permite inyectar automáticamente una instancia de modelo en un controlador según el parámetro de la ruta.' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Verdadero', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Verdadero'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'Falso', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'Falso'
);

-- Pregunta: ¿Qué comando de Artisan crea un nuevo Job para las colas?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué comando de Artisan crea un nuevo Job para las colas?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué comando de Artisan crea un nuevo Job para las colas?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué comando de Artisan crea un nuevo Job para las colas?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan make:job', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan make:job'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan make:queue', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan make:queue'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan make:task', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan make:task'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan create:job', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan create:job'
);

-- Pregunta: ¿Qué relación de Eloquent se usa para una relación muchos a muchos?...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué relación de Eloquent se usa para una relación muchos a muchos?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué relación de Eloquent se usa para una relación muchos a muchos?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué relación de Eloquent se usa para una relación muchos a muchos?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'belongsToMany()', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'belongsToMany()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'hasMany()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'hasMany()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'hasOneThrough()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'hasOneThrough()'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'morphMany()', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'morphMany()'
);

-- Pregunta: ¿Qué comando de Artisan sirve para poblar la base de datos con datos d...
INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
SELECT @id_tema_nivel, '¿Qué comando de Artisan sirve para poblar la base de datos con datos de prueba mediante Seeders?', 'opcion_multiple', @id_creador
FROM DUAL
WHERE @id_tema_nivel IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué comando de Artisan sirve para poblar la base de datos con datos de prueba mediante Seeders?'
);
SET @id_pregunta_actual = (SELECT id_pregunta FROM pregunta WHERE id_tema_nivel = @id_tema_nivel AND BINARY enunciado = BINARY '¿Qué comando de Artisan sirve para poblar la base de datos con datos de prueba mediante Seeders?' LIMIT 1);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan db:seed', 1
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan db:seed'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan seed:run', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan seed:run'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan db:fill', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan db:fill'
);
INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
SELECT @id_pregunta_actual, 'php artisan populate', 0
FROM DUAL
WHERE @id_pregunta_actual IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM opcion_respuesta WHERE id_pregunta = @id_pregunta_actual AND BINARY texto_opcion = BINARY 'php artisan populate'
);

-- =========================================================
-- FIN DEL SCRIPT
-- Total de preguntas insertadas (si no existían): 80
-- Total de opciones de respuesta insertadas (si no existían): 304
-- =========================================================
