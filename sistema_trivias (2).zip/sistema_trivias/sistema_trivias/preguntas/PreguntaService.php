<?php

namespace App\Preguntas;

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Interfaces\ManejadorErroresInterface;
use App\Interfaces\PreguntaInterface;
use App\Interfaces\ValidadorInterface;
use PDO;
use PDOException;


class PreguntaService implements PreguntaInterface
{
    private const TIPOS_VALIDOS = ['opcion_multiple', 'verdadero_falso'];

    private PDO $conexion;

    public function __construct(
        private Database $database,
        private ValidadorInterface $validador,
        private ManejadorErroresInterface $manejadorErrores
    ) {
        $this->conexion = $this->database->obtenerConexion();
    }

    public function crear(int $idTemaNivel, string $enunciado, string $tipoPregunta, int $idUsuarioCreador, array $opciones): int
    {
        $enunciadoValido = $this->validador->validarTextoObligatorio($enunciado, 'enunciado', 5, 500);
        $tipoValido = $this->validador->validarEnLista($tipoPregunta, self::TIPOS_VALIDOS, 'tipo_pregunta');

        if (!$enunciadoValido || !$tipoValido) {
            throw new AutenticacionException(implode(' ', $this->validador->obtenerErrores()));
        }

        $this->validarOpciones($tipoValido, $opciones);

        try {
            $this->conexion->beginTransaction();

            $stmt = $this->conexion->prepare(
                'INSERT INTO pregunta (id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador)
                 VALUES (:id_tema_nivel, :enunciado, :tipo_pregunta, :id_usuario_creador)'
            );
            $stmt->execute([
                'id_tema_nivel' => $idTemaNivel,
                'enunciado' => $enunciadoValido,
                'tipo_pregunta' => $tipoValido,
                'id_usuario_creador' => $idUsuarioCreador,
            ]);

            $idPregunta = (int) $this->conexion->lastInsertId();

            $stmtOpcion = $this->conexion->prepare(
                'INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, es_correcta)
                 VALUES (:id_pregunta, :texto_opcion, :es_correcta)'
            );

            foreach ($opciones as $opcion) {
                $textoOpcion = $this->validador->sanitizarTexto($opcion['texto']);
                $stmtOpcion->execute([
                    'id_pregunta' => $idPregunta,
                    'texto_opcion' => $textoOpcion,
                    'es_correcta' => !empty($opcion['es_correcta']) ? 1 : 0,
                ]);
            }

            $this->conexion->commit();

            return $idPregunta;

        } catch (PDOException $e) {
            $this->conexion->rollBack();
            $this->manejadorErrores->registrarError($e->getMessage(), 'PreguntaService::crear');
            throw new AutenticacionException('No se pudo crear la pregunta.');
        }
    }

    private function validarOpciones(string $tipoPregunta, array $opciones): void
    {
        $totalCorrectas = 0;
        foreach ($opciones as $opcion) {
            if (!empty($opcion['es_correcta'])) {
                $totalCorrectas++;
            }
        }

        if ($tipoPregunta === 'verdadero_falso' && count($opciones) !== 2) {
            throw new AutenticacionException('Una pregunta de verdadero/falso debe tener exactamente 2 opciones.');
        }

        if ($tipoPregunta === 'opcion_multiple' && count($opciones) < 2) {
            throw new AutenticacionException('Una pregunta de opción múltiple debe tener al menos 2 opciones.');
        }

        if ($totalCorrectas !== 1) {
            throw new AutenticacionException('La pregunta debe tener exactamente una opción marcada como correcta.');
        }
    }

    public function listarPorTemaNivel(int $idTemaNivel): array
    {
        $stmt = $this->conexion->prepare(
            'SELECT id_pregunta, enunciado, tipo_pregunta, fecha_creacion
             FROM pregunta
             WHERE id_tema_nivel = :id_tema_nivel
             ORDER BY id_pregunta DESC'
        );
        $stmt->execute(['id_tema_nivel' => $idTemaNivel]);
        $preguntas = $stmt->fetchAll();

        foreach ($preguntas as &$pregunta) {
            $pregunta['opciones'] = $this->obtenerOpciones($pregunta['id_pregunta']);
        }

        return $preguntas;
    }

    public function obtenerPorId(int $idPregunta): ?array
    {
        $stmt = $this->conexion->prepare(
            'SELECT id_pregunta, id_tema_nivel, enunciado, tipo_pregunta, id_usuario_creador, fecha_creacion
             FROM pregunta WHERE id_pregunta = :id'
        );
        $stmt->execute(['id' => $idPregunta]);
        $pregunta = $stmt->fetch();

        if (!$pregunta) {
            return null;
        }

        $pregunta['opciones'] = $this->obtenerOpciones($idPregunta);
        return $pregunta;
    }

    private function obtenerOpciones(int $idPregunta): array
    {
        $stmt = $this->conexion->prepare(
            'SELECT id_opcion, texto_opcion, es_correcta FROM opcion_respuesta WHERE id_pregunta = :id'
        );
        $stmt->execute(['id' => $idPregunta]);
        return $stmt->fetchAll();
    }

    public function actualizarEnunciado(int $idPregunta, string $nuevoEnunciado): bool
    {
        $enunciadoValido = $this->validador->validarTextoObligatorio($nuevoEnunciado, 'enunciado', 5, 500);

        if (!$enunciadoValido) {
            throw new AutenticacionException(implode(' ', $this->validador->obtenerErrores()));
        }

        $stmt = $this->conexion->prepare('UPDATE pregunta SET enunciado = :enunciado WHERE id_pregunta = :id');
        return $stmt->execute(['enunciado' => $enunciadoValido, 'id' => $idPregunta]);
    }

    public function eliminar(int $idPregunta): bool
    {
        try {
            $this->conexion->beginTransaction();

            $stmt = $this->conexion->prepare('DELETE FROM opcion_respuesta WHERE id_pregunta = :id');
            $stmt->execute(['id' => $idPregunta]);

            $stmt = $this->conexion->prepare('DELETE FROM pregunta WHERE id_pregunta = :id');
            $resultado = $stmt->execute(['id' => $idPregunta]);

            $this->conexion->commit();
            return $resultado;

        } catch (PDOException $e) {
            $this->conexion->rollBack();
            $this->manejadorErrores->registrarError($e->getMessage(), 'PreguntaService::eliminar');
            throw new AutenticacionException('No se pudo eliminar la pregunta.');
        }
    }
}
