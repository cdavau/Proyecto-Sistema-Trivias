<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Temas\TemaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ARMADOR, Roles::ADMINISTRADOR]);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: gestion_temas.php');
    exit;
} \App\Utils\Csrf::validar();

$db = Database::obtenerInstancia();
$temaService = new TemaService($db, new Validador(), new ManejadorErroresArchivo());

try {
    $temaService->crearTemaNivel(
        (int) ($_POST['id_tema'] ?? 0),
        (int) ($_POST['id_nivel'] ?? 0),
        $_POST['nombre_especifico'] ?? ''
    );
    header('Location: gestion_temas.php?exito=1');
    exit;

} catch (AutenticacionException $e) {
    header('Location: gestion_temas.php?error=' . urlencode($e->getMessage()));
    exit;
}
