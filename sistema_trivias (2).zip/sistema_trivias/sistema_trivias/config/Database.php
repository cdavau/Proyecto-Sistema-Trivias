<?php

namespace App\Config;

use App\Exceptions\DatabaseException;
use App\Interfaces\ManejadorErroresInterface;
use App\Utils\ManejadorErroresArchivo;
use PDO;
use PDOException;
class Database
{
    private static ?Database $instancia = null;
    private PDO $conexion;
    private ManejadorErroresInterface $manejadorErrores;
    private function __construct(?ManejadorErroresInterface $manejadorErrores = null)
    {
        $this->manejadorErrores = $manejadorErrores ?? new ManejadorErroresArchivo();

        $config = require __DIR__ . '/config.php';

        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            $config['host'],
            $config['port'],
            $config['dbname'],
            $config['charset']
        );

        $opciones = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, 
        ];

        try {
            $this->conexion = new PDO($dsn, $config['user'], $config['password'], $opciones);
        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError(
                $e->getMessage(),
                'Database::__construct',
                ['dsn' => $dsn]
            );
            throw new DatabaseException(
                $this->manejadorErrores->mensajeParaUsuario($e->getMessage())
            );
        }
    }
    public static function obtenerInstancia(): Database
    {
        if (self::$instancia === null) {
            self::$instancia = new self();
        }

        return self::$instancia;
    }
    public function obtenerConexion(): PDO
    {
        return $this->conexion;
    }

    private function __clone(): void
    {
    }

    public function __wakeup(): void
    {
        throw new DatabaseException('No se permite deserializar esta clase.');
    }
}
