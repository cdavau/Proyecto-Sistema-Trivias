<?php

if (!defined('ENTORNO_APP_CONFIGURADO')) {
    define('ENTORNO_APP_CONFIGURADO', true);

    $configuracionApp = require __DIR__ . '/config.php';
    $entornoApp = $configuracionApp['entorno'] ?? 'produccion';

    error_reporting(E_ALL);
    ini_set('display_startup_errors', $entornoApp === 'desarrollo' ? '1' : '0');
    ini_set('display_errors', $entornoApp === 'desarrollo' ? '1' : '0');

    unset($configuracionApp, $entornoApp);
}
