<?php
return [
    'host'     => '127.0.0.1',
    'port'     => '3306',
    'dbname'   => 'sistema_trivias',
    'user'     => 'root',
    'password' => '',          
    'charset'  => 'utf8mb4',
    // 'desarrollo': muestra TODOS los errores/warnings/notices en pantalla.
    // 'produccion': los oculta del usuario final (ManejadorErrores los sigue registrando en logs/errores.log).
    // Cambiar a 'produccion' antes de publicar el sistema en un servidor real.
    'entorno'  => 'desarrollo',
    'url_base' => null,
    'clave_integridad' => '5d44a9ec3f6fbaa7a6649ef5fce02e69cbd74e3d7c7c938357b05c1f4a9e051d',
];
