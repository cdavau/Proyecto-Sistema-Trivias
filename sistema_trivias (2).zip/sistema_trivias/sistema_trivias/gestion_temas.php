<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Temas\TemaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ARMADOR, Roles::ADMINISTRADOR]);
$usuarioSesion = SesionUtil::usuarioActual();

$db = Database::obtenerInstancia();
$temaService = new TemaService($db, new Validador(), new ManejadorErroresArchivo());

$temas = $temaService->listarTemas();
$nivelesTema = $temaService->listarTemaNivel();

$paginaActiva = 'temas';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestión de Temas — Trivias UTP</title>
<link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="contenido">
        <div class="encabezado">
            <div>
                <span class="eyebrow">📚 Gestión</span>
                <h1 style="margin-top:10px;">Temas y niveles</h1>
            </div>
        </div>

        <?php if (isset($_GET['error'])): ?>
            <p class="mensaje-error">⚠️ <?= htmlspecialchars($_GET['error']) ?></p>
        <?php endif; ?>
        <?php if (isset($_GET['exito'])): ?>
            <p class="mensaje-exito">✅ <?= $_GET['exito'] === 'eliminado' ? 'Eliminado correctamente.' : 'Guardado correctamente.' ?></p>
        <?php endif; ?>

        <div class="grid-cards" style="grid-template-columns: 1fr 1fr;">
            <!-- Formulario: crear tema -->
            <div class="tarjeta">
                <h3 style="margin-bottom:12px;">➕ Nuevo tema</h3>
                <form action="procesar_crear_tema.php" method="POST">
                    <?= \App\Utils\Csrf::campo() ?>
                    <label for="nombre_tema">Nombre del tema</label>
                    <input type="text" id="nombre_tema" name="nombre_tema" placeholder="Ej: Python" required>

                    <label for="descripcion">Descripción</label>
                    <textarea id="descripcion" name="descripcion" rows="3" placeholder="Breve descripción del tema"></textarea>

                    <button type="submit" class="buzzer">Crear tema</button>
                </form>
            </div>

            <!-- Formulario: crear nivel para un tema -->
            <div class="tarjeta">
                <h3 style="margin-bottom:12px;">➕ Nuevo nivel para un tema</h3>
                <form action="procesar_crear_tema_nivel.php" method="POST">
                    <?= \App\Utils\Csrf::campo() ?>
                    <label for="id_tema">Tema</label>
                    <select id="id_tema" name="id_tema" required>
                        <?php foreach ($temas as $t): ?>
                            <option value="<?= $t['id_tema'] ?>"><?= htmlspecialchars($t['nombre_tema']) ?></option>
                        <?php endforeach; ?>
                    </select>

                    <label for="id_nivel">Nivel</label>
                    <select id="id_nivel" name="id_nivel" required>
                        <option value="1">Novato</option>
                        <option value="2">Intermedio</option>
                        <option value="3">Avanzado</option>
                    </select>

                    <label for="nombre_especifico">Nombre específico</label>
                    <input type="text" id="nombre_especifico" name="nombre_especifico" placeholder="Ej: Python Básico" required>

                    <button type="submit" class="buzzer teal">Crear nivel</button>
                </form>
            </div>
        </div>

        <div class="tarjeta" style="margin-bottom:24px;">
            <h3 style="margin-bottom:6px;">Temas existentes (<?= count($temas) ?>)</h3>
            <table id="tabla-temas" class="display" style="width:100%">
                <thead><tr><th>ID</th><th>Nombre</th><th>Descripción</th><th>Acciones</th></tr></thead>
                <tbody>
                <?php foreach ($temas as $t): ?>
                <tr>
                    <td>#<?= $t['id_tema'] ?></td>
                    <td><?= htmlspecialchars($t['nombre_tema']) ?></td>
                    <td><?= htmlspecialchars($t['descripcion']) ?></td>
                    <td>
                        <form action="procesar_eliminar_tema.php" method="POST" onsubmit="return confirm('¿Eliminar el tema \'<?= htmlspecialchars(addslashes($t['nombre_tema'])) ?>\'? Esto fallará si todavía tiene niveles o preguntas asociadas.');" style="margin:0;">
                            <?= \App\Utils\Csrf::campo() ?>
                            <input type="hidden" name="id_tema" value="<?= (int) $t['id_tema'] ?>">
                            <button type="submit" class="buzzer eliminar" style="padding:6px 12px;">🗑️ Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="tarjeta">
            <h3 style="margin-bottom:6px;">Niveles configurados (<?= count($nivelesTema) ?>)</h3>
            <table id="tabla-niveles" class="display" style="width:100%">
                <thead><tr><th>ID</th><th>Tema</th><th>Nivel</th><th>Nombre específico</th><th>Acciones</th></tr></thead>
                <tbody>
                <?php foreach ($nivelesTema as $n): ?>
                <tr>
                    <td>#<?= $n['id_tema_nivel'] ?></td>
                    <td><?= htmlspecialchars($n['nombre_tema']) ?></td>
                    <td><?= htmlspecialchars($n['nombre_nivel']) ?></td>
                    <td><?= htmlspecialchars($n['nombre_especifico']) ?></td>
                    <td>
                        <form action="procesar_eliminar_tema_nivel.php" method="POST" onsubmit="return confirm('¿Eliminar el nivel \'<?= htmlspecialchars(addslashes($n['nombre_especifico'])) ?>\'? Esto fallará si todavía tiene preguntas asociadas.');" style="margin:0;">
                            <?= \App\Utils\Csrf::campo() ?>
                            <input type="hidden" name="id_tema_nivel" value="<?= (int) $n['id_tema_nivel'] ?>">
                            <button type="submit" class="buzzer eliminar" style="padding:6px 12px;">🗑️ Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script>
    $(function () {
        const opciones = {
            language: {
                search: 'Buscar:',
                lengthMenu: 'Mostrar _MENU_ registros',
                info: 'Mostrando _START_ a _END_ de _TOTAL_ registros',
                infoEmpty: 'No hay registros para mostrar',
                infoFiltered: '(filtrado de _MAX_ registros en total)',
                zeroRecords: 'Ningún registro coincide con la búsqueda',
                paginate: { previous: 'Anterior', next: 'Siguiente' }
            }
        };
        $('#tabla-temas').DataTable(opciones);
        $('#tabla-niveles').DataTable(opciones);
    });
</script>
</body>
</html>
