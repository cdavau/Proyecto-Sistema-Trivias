<?php

namespace App\Premios;

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Interfaces\ManejadorErroresInterface;
use App\Interfaces\PremioInterface;
use App\Interfaces\ValidadorInterface;
use PDO;
use PDOException;

/**
 * PremioService
 *
 * CRUD del módulo de Premios. Los premios incluyen una imagen y una
 * ponderación de puntos, y corresponden al éxito de un nivel y/o tema,
 * según el alcance del proyecto.
 */
class PremioService implements PremioInterface
{
    private PDO $conexion;

    public function __construct(
        private Database $database,
        private ValidadorInterface $validador,
        private ManejadorErroresInterface $manejadorErrores
    ) {
        $this->conexion = $this->database->obtenerConexion();
    }

    public function crear(string $nombrePremio, string $imagen, int $ponderacionPuntos, ?int $idNivel, ?int $idTema): int
    {
        $nombreValido = $this->validador->validarTextoObligatorio($nombrePremio, 'nombre_premio', 3, 100);
        $imagenValida = $this->validador->sanitizarTexto($imagen);
        $puntosValidos = $this->validador->validarEntero($ponderacionPuntos, 1, 100000);

        if (!$nombreValido || empty($imagenValida) || $puntosValidos === null) {
            throw new AutenticacionException(implode(' ', $this->validador->obtenerErrores()) ?: 'Datos del premio inválidos.');
        }

        try {
            $stmt = $this->conexion->prepare(
                'INSERT INTO premio (nombre_premio, imagen, ponderacion_puntos, id_nivel, id_tema)
                 VALUES (:nombre_premio, :imagen, :ponderacion_puntos, :id_nivel, :id_tema)'
            );
            $stmt->execute([
                'nombre_premio' => $nombreValido,
                'imagen' => $imagenValida,
                'ponderacion_puntos' => $puntosValidos,
                'id_nivel' => $idNivel,
                'id_tema' => $idTema,
            ]);

            return (int) $this->conexion->lastInsertId();

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'PremioService::crear');
            throw new AutenticacionException('No se pudo crear el premio.');
        }
    }

    public function listar(): array
    {
        $stmt = $this->conexion->query(
            'SELECT p.id_premio, p.nombre_premio, p.imagen, p.ponderacion_puntos,
                    p.id_nivel, p.id_tema, n.nombre_nivel, t.nombre_tema
             FROM premio p
             LEFT JOIN nivel_conocimiento n ON n.id_nivel = p.id_nivel
             LEFT JOIN tema t ON t.id_tema = p.id_tema
             ORDER BY p.ponderacion_puntos DESC'
        );

        return $stmt->fetchAll();
    }

    public function obtenerPorId(int $idPremio): ?array
    {
        $stmt = $this->conexion->prepare(
            'SELECT p.id_premio, p.nombre_premio, p.imagen, p.ponderacion_puntos,
                    p.id_nivel, p.id_tema, n.nombre_nivel, t.nombre_tema
             FROM premio p
             LEFT JOIN nivel_conocimiento n ON n.id_nivel = p.id_nivel
             LEFT JOIN tema t ON t.id_tema = p.id_tema
             WHERE p.id_premio = :id'
        );
        $stmt->execute(['id' => $idPremio]);
        $premio = $stmt->fetch();

        return $premio ?: null;
    }

    public function actualizar(int $idPremio, array $datos): bool
    {
        $camposPermitidos = ['nombre_premio', 'imagen', 'ponderacion_puntos', 'id_nivel', 'id_tema'];
        $sets = [];
        $parametros = ['id' => $idPremio];

        foreach ($datos as $campo => $valor) {
            if (!in_array($campo, $camposPermitidos, true)) {
                continue;
            }

            if ($campo === 'nombre_premio') {
                $valor = $this->validador->validarTextoObligatorio($valor, 'nombre_premio', 3, 100);
                if (!$valor) {
                    throw new AutenticacionException('Nombre de premio inválido.');
                }
            } elseif ($campo === 'imagen') {
                $valor = $this->validador->sanitizarTexto($valor);
            } elseif ($campo === 'ponderacion_puntos') {
                $valor = $this->validador->validarEntero($valor, 1, 100000);
                if ($valor === null) {
                    throw new AutenticacionException('Ponderación de puntos inválida.');
                }
            }

            $sets[] = "{$campo} = :{$campo}";
            $parametros[$campo] = $valor;
        }

        if (empty($sets)) {
            return false;
        }

        $sql = 'UPDATE premio SET ' . implode(', ', $sets) . ' WHERE id_premio = :id';
        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute($parametros);
    }

    public function eliminar(int $idPremio): bool
    {
        try {
            $stmt = $this->conexion->prepare('DELETE FROM premio WHERE id_premio = :id');
            return $stmt->execute(['id' => $idPremio]);

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'PremioService::eliminar');
            throw new AutenticacionException('No se pudo eliminar el premio.');
        }
    }

    public function otorgarPremiosPorNivelAprobado(int $idUsuario, int $idTema, int $idNivel): array
    {
        try {
            $stmt = $this->conexion->prepare(
                'SELECT id_premio, nombre_premio, imagen, ponderacion_puntos
                 FROM premio
                 WHERE (id_nivel = :id_nivel AND id_tema IS NULL)
                    OR (id_tema = :id_tema AND id_nivel IS NULL)
                    OR (id_tema = :id_tema2 AND id_nivel = :id_nivel2)'
            );
            $stmt->execute([
                'id_nivel'  => $idNivel,
                'id_tema'   => $idTema,
                'id_tema2'  => $idTema,
                'id_nivel2' => $idNivel,
            ]);
            $premiosAplicables = $stmt->fetchAll();

            $otorgados = [];

            foreach ($premiosAplicables as $premio) {
                $check = $this->conexion->prepare(
                    'SELECT id_usuario_premio FROM usuario_premio
                     WHERE id_usuario = :id_usuario AND id_premio = :id_premio LIMIT 1'
                );
                $check->execute(['id_usuario' => $idUsuario, 'id_premio' => $premio['id_premio']]);

                if ($check->fetch()) {
                    continue; 
                }

                $this->conexion->beginTransaction();
                try {
                    $insertar = $this->conexion->prepare(
                        'INSERT INTO usuario_premio (id_usuario, id_premio) VALUES (:id_usuario, :id_premio)'
                    );
                    $insertar->execute(['id_usuario' => $idUsuario, 'id_premio' => $premio['id_premio']]);

                    $sumarPuntos = $this->conexion->prepare(
                        'UPDATE usuario SET puntos_totales = puntos_totales + :puntos WHERE id_usuario = :id_usuario'
                    );
                    $sumarPuntos->execute([
                        'puntos' => (int) $premio['ponderacion_puntos'],
                        'id_usuario' => $idUsuario,
                    ]);

                    $this->conexion->commit();
                    $otorgados[] = $premio;

                } catch (PDOException $e) {
                    $this->conexion->rollBack();
                    $this->manejadorErrores->registrarError($e->getMessage(), 'PremioService::otorgarPremiosPorNivelAprobado');
                }
            }

            return $otorgados;

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'PremioService::otorgarPremiosPorNivelAprobado');
            return [];
        }
    }
}
