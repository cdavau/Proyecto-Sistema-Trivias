<?php

// Genera un backup .sql completo (estructura + datos) de la base de datos,
// pero anonimiza nombre/apodo/cedula/correo de la tabla usuario antes de
// exportarlos. Mantiene id_usuario, password_hash, avatar, id_rol,
// puntos_totales y estado, así que el sistema sigue funcionando igual
// si alguien restaura este backup.
// No usa mysqldump ni shell_exec: arma el SQL directo con PDO.
// Borrar este script del servidor después de usarlo.

ini_set('display_errors', '1');
error_reporting(E_ALL);

ob_start();

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;

$db = Database::obtenerInstancia();
$pdo = $db->obtenerConexion();

$nombreBaseDatos = $pdo->query('SELECT DATABASE()')->fetchColumn();

const COLUMNAS_ANONIMIZAR_USUARIO = ['nombre', 'apodo', 'cedula', 'correo'];

function valorAnonimizado(string $columna, array $fila): string
{
    $id = (int) $fila['id_usuario'];

    return match ($columna) {
        'nombre' => "Usuario de Prueba {$id}",
        'apodo'  => "usuario_{$id}",
        'cedula' => sprintf('9-%03d-%04d', $id, ($id * 37) % 10000),
        'correo' => "usuario{$id}@ejemplo.com",
        default  => (string) $fila[$columna],
    };
}

function escaparValorSql(PDO $pdo, $valor): string
{
    if ($valor === null) {
        return 'NULL';
    }
    return $pdo->quote((string) $valor);
}

$stmtTipos = $pdo->query('SHOW FULL TABLES');
$tablasBase = [];
$vistas = [];

foreach ($stmtTipos->fetchAll(PDO::FETCH_NUM) as [$nombre, $tipo]) {
    if ($tipo === 'VIEW') {
        $vistas[] = $nombre;
    } else {
        $tablasBase[] = $nombre;
    }
}

$sql = "-- Backup de {$nombreBaseDatos}\n";
$sql .= "-- Generado el " . date('Y-m-d H:i:s') . "\n";
$sql .= "-- Datos personales de usuario anonimizados.\n\n";
$sql .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";

foreach ($vistas as $vista) {
    $sql .= "DROP VIEW IF EXISTS `{$vista}`;\n";
}
$sql .= "\n";

foreach ($tablasBase as $tabla) {

    $filaCreate = $pdo->query("SHOW CREATE TABLE `{$tabla}`")->fetch(PDO::FETCH_ASSOC);
    $createStatement = $filaCreate['Create Table'];

    $sql .= "-- Tabla `{$tabla}`\n";
    $sql .= "DROP TABLE IF EXISTS `{$tabla}`;\n";
    $sql .= $createStatement . ";\n\n";

    $stmtDatos = $pdo->query("SELECT * FROM `{$tabla}`");
    $filas = $stmtDatos->fetchAll(PDO::FETCH_ASSOC);

    if (!$filas) {
        continue;
    }

    $columnas = array_keys($filas[0]);
    $columnasEscapadas = '`' . implode('`, `', $columnas) . '`';

    foreach (array_chunk($filas, 200) as $lote) {
        $valoresPorFila = [];

        foreach ($lote as $fila) {
            $valores = [];
            foreach ($columnas as $columna) {
                if ($tabla === 'usuario' && in_array($columna, COLUMNAS_ANONIMIZAR_USUARIO, true)) {
                    $valores[] = escaparValorSql($pdo, valorAnonimizado($columna, $fila));
                } else {
                    $valores[] = escaparValorSql($pdo, $fila[$columna]);
                }
            }
            $valoresPorFila[] = '(' . implode(', ', $valores) . ')';
        }

        $sql .= "INSERT INTO `{$tabla}` ({$columnasEscapadas}) VALUES\n"
            . implode(",\n", $valoresPorFila) . ";\n\n";
    }
}

// las vistas van al final porque dependen de las tablas
foreach ($vistas as $vista) {
    $filaCreate = $pdo->query("SHOW CREATE VIEW `{$vista}`")->fetch(PDO::FETCH_ASSOC);
    $createStatement = $filaCreate['Create View'];

    $sql .= "-- Vista `{$vista}`\n";
    $sql .= $createStatement . ";\n\n";
}

$sql .= "SET FOREIGN_KEY_CHECKS = 1;\n";

$nombreArchivo = 'sistema_trivias_backup_' . date('Ymd_His') . '.sql';

ob_end_clean();

header('Content-Type: application/sql; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $nombreArchivo . '"');
header('Content-Length: ' . strlen($sql));

echo $sql;
