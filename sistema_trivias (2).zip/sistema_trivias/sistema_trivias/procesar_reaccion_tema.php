<?php
require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Temas\TemaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::iniciar();
if (!SesionUtil::estaAutenticado()) {
    header('Location: login.php');
    exit;
} \App\Utils\Csrf::validar();

$usuarioSesion = SesionUtil::usuarioActual();
$idTema = (int) ($_POST['id_tema'] ?? 0);
$tipoReaccion = (string) ($_POST['tipo_reaccion'] ?? '');
$volverA = $_POST['volver_a'] ?? 'jugar.php';

$paginasPermitidas = ['jugar.php', 'resultado_partida.php', 'dashboard.php'];
if (!in_array($volverA, $paginasPermitidas, true)) {
    $volverA = 'jugar.php';
}

$db = Database::obtenerInstancia();
$temaService = new TemaService($db, new Validador(), new ManejadorErroresArchivo());

try {
    if ($idTema <= 0) {
        throw new \App\Exceptions\AutenticacionException('Tema inválido.');
    }

    $temaService->registrarReaccionTema((int) $usuarioSesion['id_usuario'], $idTema, $tipoReaccion);
    header('Location: ' . $volverA . '?reaccion_ok=1#tema-' . $idTema);
    exit;

} catch (\App\Exceptions\AutenticacionException $e) {
    header('Location: ' . $volverA . '?error=' . urlencode($e->getMessage()) . '#tema-' . $idTema);
    exit;
}
