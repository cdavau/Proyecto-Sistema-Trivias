<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Temas\TemaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Validador;

$db = Database::obtenerInstancia();
$temaService = new TemaService($db, new Validador(), new ManejadorErroresArchivo());
$temas = $temaService->listarTemas();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trivias UTP — Aprende jugando</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@600;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
    :root {
        --bg-deep: #15123c;
        --bg-deep-2: #201a5c;
        --magenta: #ff2e63;
        --yellow: #ffd23f;
        --teal: #08d9d6;
        --text-light: #f5f4ff;
        --text-muted: #a9a3d6;
    }
    * { box-sizing: border-box; }
    body {
        margin: 0;
        font-family: 'Inter', sans-serif;
        background: linear-gradient(160deg, var(--bg-deep) 0%, var(--bg-deep-2) 100%);
        color: var(--text-light);
    }

    nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 22px 60px;
    }
    nav .logo { font-family: 'Baloo 2', sans-serif; font-weight: 800; font-size: 20px; }
    nav .botones a {
        text-decoration: none;
        color: var(--text-light);
        font-weight: 600;
        font-size: 14px;
        margin-left: 18px;
    }
    nav .botones a.cta {
        background: linear-gradient(180deg, var(--yellow), #ffb703);
        color: #1a1140;
        padding: 10px 20px;
        border-radius: 999px;
    }

    .hero {
        text-align: center;
        padding: 70px 20px 90px;
        position: relative;
        overflow: hidden;
    }
    .hero::before {
        content: "";
        position: absolute;
        inset: 0;
        background:
            radial-gradient(circle at 20% 20%, rgba(255,46,99,0.22), transparent 40%),
            radial-gradient(circle at 80% 80%, rgba(8,217,214,0.2), transparent 40%);
        z-index: 0;
    }
    .hero > * { position: relative; z-index: 1; }

    .eyebrow {
        display: inline-flex;
        gap: 6px;
        background: linear-gradient(90deg, var(--magenta), #ff6b9d);
        padding: 6px 16px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
    }

    .hero h1 {
        font-family: 'Baloo 2', sans-serif;
        font-weight: 800;
        font-size: 48px;
        margin: 24px 0 16px;
        line-height: 1.15;
    }
    .hero h1 span { color: var(--yellow); }

    .hero p.sub {
        color: var(--text-muted);
        max-width: 520px;
        margin: 0 auto 32px;
        font-size: 16px;
    }

    .hero .cta-grande {
        display: inline-block;
        background: linear-gradient(180deg, var(--yellow), #ffb703);
        color: #1a1140;
        font-family: 'Baloo 2', sans-serif;
        font-weight: 800;
        font-size: 17px;
        text-decoration: none;
        padding: 16px 36px;
        border-radius: 999px;
        box-shadow: 0 6px 0 #d68f00, 0 12px 24px rgba(255,178,3,0.35);
    }

    section.temas { padding: 60px 60px 80px; }
    section.temas h2 {
        font-family: 'Baloo 2', sans-serif;
        text-align: center;
        font-size: 28px;
        margin-bottom: 8px;
    }
    section.temas p.desc {
        text-align: center;
        color: var(--text-muted);
        margin-bottom: 40px;
    }

    .grid-temas {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 22px;
        max-width: 900px;
        margin: 0 auto;
    }

    .tarjeta-tema {
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 18px;
        padding: 26px;
    }
    .tarjeta-tema .icono { font-size: 30px; margin-bottom: 10px; }
    .tarjeta-tema h3 { font-family: 'Baloo 2', sans-serif; margin: 0 0 8px; font-size: 18px; }
    .tarjeta-tema p { color: var(--text-muted); font-size: 13.5px; margin: 0; }

    section.beneficios {
        background: rgba(0,0,0,0.2);
        padding: 60px;
    }
    .grid-beneficios {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
        gap: 30px;
        max-width: 1000px;
        margin: 0 auto;
    }
    .beneficio { text-align: center; }
    .beneficio .num {
        font-family: 'Baloo 2', sans-serif;
        font-size: 34px;
        color: var(--teal);
        margin-bottom: 8px;
    }
    .beneficio h4 { font-family: 'Baloo 2', sans-serif; margin: 0 0 8px; }
    .beneficio p { color: var(--text-muted); font-size: 14px; }

    section.importancia { padding: 60px; }
    section.importancia h2 { font-family: 'Baloo 2', sans-serif; text-align: center; font-size: 28px; margin-bottom: 8px; }
    section.importancia p.desc { text-align: center; color: var(--text-muted); margin-bottom: 40px; max-width: 640px; margin-left:auto; margin-right:auto; }
    .grid-importancia {
        display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
        gap: 22px; max-width: 1000px; margin: 0 auto;
    }
    .tarjeta-importancia {
        background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);
        border-radius: 18px; padding: 26px;
    }
    .tarjeta-importancia .icono { font-size: 28px; margin-bottom: 10px; }
    .tarjeta-importancia h4 { font-family: 'Baloo 2', sans-serif; margin: 0 0 8px; font-size: 16px; }
    .tarjeta-importancia p { color: var(--text-muted); font-size: 13.5px; margin: 0; }

    section.noticias { background: rgba(0,0,0,0.2); padding: 60px; }
    section.noticias h2 { font-family: 'Baloo 2', sans-serif; text-align: center; font-size: 28px; margin-bottom: 8px; }
    section.noticias p.desc { text-align: center; color: var(--text-muted); margin-bottom: 40px; }
    .lista-noticias { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 20px; max-width: 1000px; margin: 0 auto; }
    .tarjeta-noticia {
        background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);
        border-radius: 18px; padding: 22px;
    }
    .tarjeta-noticia .fecha { font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--teal); font-weight: 700; margin-bottom: 8px; display:block; }
    .tarjeta-noticia h4 { font-family: 'Baloo 2', sans-serif; margin: 0 0 8px; font-size: 15.5px; }
    .tarjeta-noticia p { color: var(--text-muted); font-size: 13.5px; margin: 0; }

    section.contactos { padding: 60px; }
    section.contactos h2 { font-family: 'Baloo 2', sans-serif; text-align: center; font-size: 28px; margin-bottom: 8px; }
    section.contactos p.desc { text-align: center; color: var(--text-muted); margin-bottom: 40px; }
    .grid-contactos {
        display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 22px; max-width: 900px; margin: 0 auto; text-align: center;
    }
    .tarjeta-contacto { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 18px; padding: 24px; }
    .tarjeta-contacto .icono { font-size: 26px; margin-bottom: 10px; }
    .tarjeta-contacto h4 { font-family: 'Baloo 2', sans-serif; margin: 0 0 6px; font-size: 14.5px; }
    .tarjeta-contacto p, .tarjeta-contacto a { color: var(--text-muted); font-size: 13.5px; margin: 0; text-decoration: none; }
    .tarjeta-contacto a:hover { color: var(--teal); }

    footer {
        text-align: center;
        padding: 40px;
        color: var(--text-muted);
        font-size: 13px;
    }
    footer a { color: var(--teal); text-decoration: none; }

    @media (max-width: 700px) {
        nav, section.temas, section.beneficios { padding-left: 24px; padding-right: 24px; }
        .hero h1 { font-size: 34px; }
    }
</style>
</head>
<body>

<nav>
    <div class="logo">🎮 Trivias UTP</div>
    <div class="botones">
        <a href="#importancia">Para capacitaciones</a>
        <a href="#noticias">Noticias</a>
        <a href="#contactos">Contactos</a>
        <a href="promocional.php">Encuesta</a>
        <a href="login.php">Iniciar sesión</a>
        <a href="registro.php" class="cta">Regístrate</a>
    </div>
</nav>

<section class="hero">
    <span class="eyebrow">🚀 Facultad de Ingeniería de Sistemas Computacionales</span>
    <h1>Aprende <span>PHP</span>, <span>JavaScript</span><br>y <span>Laravel</span> jugando</h1>
    <p class="sub">
        Compite en trivias por niveles, gana premios y sube en el marcador
        mientras dominas los temas clave de Desarrollo de Software.
    </p>
    <a href="registro.php" class="cta-grande">🔔 Empezar a jugar gratis</a>
</section>

<section class="temas">
    <h2>Temas disponibles</h2>
    <p class="desc">Cada tema tiene niveles progresivos: no puedes avanzar sin dominar el anterior.</p>
    <div class="grid-temas">
        <?php
        $iconos = ['PHP' => '🐘', 'JavaScript' => '⚡', 'Laravel' => '🔺'];
        foreach ($temas as $tema):
            $icono = $iconos[$tema['nombre_tema']] ?? '📘';
        ?>
        <div class="tarjeta-tema">
            <div class="icono"><?= $icono ?></div>
            <h3><?= htmlspecialchars($tema['nombre_tema']) ?></h3>
            <p><?= htmlspecialchars($tema['descripcion']) ?></p>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="beneficios">
    <div class="grid-beneficios">
        <div class="beneficio">
            <div class="num">🏆</div>
            <h4>Gana premios</h4>
            <p>Desbloquea premios visuales por cada nivel y tema que domines.</p>
        </div>
        <div class="beneficio">
            <div class="num">👥</div>
            <h4>Multijugador</h4>
            <p>Reta a otros jugadores en un mismo set de preguntas y compara tu conocimiento.</p>
        </div>
        <div class="beneficio">
            <div class="num">📊</div>
            <h4>Progreso medible</h4>
            <p>Consulta tus puntos y estadísticas de qué temas dominas mejor.</p>
        </div>
    </div>
</section>

<section class="importancia" id="importancia">
    <span class="eyebrow" style="display:block; width:fit-content; margin:0 auto 16px;">🎓 Más allá del salón de clases</span>
    <h2>Importancia para capacitaciones</h2>
    <p class="desc">
        El sistema no es solo un juego: sirve como herramienta de evaluación y
        capacitación técnica para facultades, departamentos de TI y empresas que
        necesitan medir y reforzar el dominio real de sus estudiantes o colaboradores.
    </p>
    <div class="grid-importancia">
        <div class="tarjeta-importancia">
            <div class="icono">🧠</div>
            <h4>Refuerza el aprendizaje activo</h4>
            <p>Convierte la teoría de cada curso en preguntas prácticas que se responden jugando, mejorando la retención frente a una clase puramente expositiva.</p>
        </div>
        <div class="tarjeta-importancia">
            <div class="icono">📈</div>
            <h4>Mide el avance real</h4>
            <p>El progreso por niveles y el reporte de estadísticas permiten a un instructor o encargado de capacitación identificar quién domina un tema y quién necesita repaso.</p>
        </div>
        <div class="tarjeta-importancia">
            <div class="icono">🏢</div>
            <h4>Escalable a empresas</h4>
            <p>La misma dinámica de temas, niveles y premios puede reutilizarse para capacitar nuevos colaboradores en procesos internos, herramientas o normativas.</p>
        </div>
        <div class="tarjeta-importancia">
            <div class="icono">🎯</div>
            <h4>Motiva con gamificación</h4>
            <p>Puntos, premios y ranking incentivan que las personas completen la capacitación por su propia cuenta, en lugar de verla como una obligación.</p>
        </div>
    </div>
</section>

<section class="noticias" id="noticias">
    <h2>Noticias</h2>
    <p class="desc">Las últimas novedades del sistema de trivias.</p>
    <div class="lista-noticias">
        <div class="tarjeta-noticia">
            <span class="fecha">Julio 2026</span>
            <h4>🆕 Nuevo módulo de reportes</h4>
            <p>Ya puedes consultar tiempos, porcentaje de aciertos y exportar el reporte completo de jugadores a Excel desde el panel de administración.</p>
        </div>
        <div class="tarjeta-noticia">
            <span class="fecha">Julio 2026</span>
            <h4>⭐ Calificación de temas</h4>
            <p>Ahora puedes calificar cada tema con una reacción (genial / interesante / aburrido) y dejarnos tu sugerencia de qué tema o tecnología te gustaría ver a continuación.</p>
        </div>
        <div class="tarjeta-noticia">
            <span class="fecha">Junio 2026</span>
            <h4>🎮 Lanzamiento de la plataforma</h4>
            <p>Salió la primera versión pública del sistema con trivias de PHP, JavaScript y Laravel, niveles progresivos y premios desbloqueables.</p>
        </div>
    </div>
</section>

<section class="contactos" id="contactos">
    <h2>Contactos</h2>
    <p class="desc">¿Dudas, sugerencias o interés en usar el sistema para capacitaciones? Escríbenos.</p>
    <div class="grid-contactos">
        <div class="tarjeta-contacto">
            <div class="icono">✉️</div>
            <h4>Correo</h4>
            <a href="mailto:trivias.utp@estudiante.utp.ac.pa">trivias.utp@estudiante.utp.ac.pa</a>
        </div>
        <div class="tarjeta-contacto">
            <div class="icono">📞</div>
            <h4>Teléfono</h4>
            <p>+507 6000-0000</p>
        </div>
        <div class="tarjeta-contacto">
            <div class="icono">📍</div>
            <h4>Ubicación</h4>
            <p>Universidad Tecnológica de Panamá<br>Facultad de Ingeniería de Sistemas Computacionales</p>
        </div>
        <div class="tarjeta-contacto">
            <div class="icono">💬</div>
            <h4>Sugerencias</h4>
            <a href="promocional.php">Déjanos tu idea aquí →</a>
        </div>
    </div>
</section>

<footer>
    Sistema de Trivias — Grupo 1GS132 — Facultad de Ingeniería de Sistemas Computacionales, UTP<br>
    <a href="promocional.php">¿Qué temas te gustaría ver? Cuéntanos aquí →</a>
</footer>

</body>
</html>
