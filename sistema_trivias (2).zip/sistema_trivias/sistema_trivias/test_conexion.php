<?php

// Prueba que la clase Database conecta bien y puede leer la tabla "tema".

require_once __DIR__ . '/config/entorno.php';
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/exceptions/DatabaseException.php';
require_once __DIR__ . '/interfaces/ManejadorErroresInterface.php';
require_once __DIR__ . '/utils/ManejadorErroresArchivo.php';
require_once __DIR__ . '/config/Database.php';

use App\Config\Database;
use App\Exceptions\DatabaseException;

header('Content-Type: text/plain; charset=utf-8');

try {
    $db = Database::obtenerInstancia();
    $pdo = $db->obtenerConexion();

    echo "✅ Conexión exitosa a la base de datos 'sistema_trivias'\n\n";

    $stmt = $pdo->query('SELECT id_tema, nombre_tema, descripcion FROM tema');
    $temas = $stmt->fetchAll();

    echo "Temas encontrados (" . count($temas) . "):\n";
    foreach ($temas as $tema) {
        echo "- [{$tema['id_tema']}] {$tema['nombre_tema']}: {$tema['descripcion']}\n";
    }

    $db2 = Database::obtenerInstancia();
    echo "\n¿Es la misma instancia (Singleton)? " . ($db === $db2 ? "SÍ ✅" : "NO ❌");

} catch (DatabaseException $e) {
    echo "❌ Error de conexión: " . $e->getMessage();
}
