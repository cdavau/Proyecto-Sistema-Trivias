<?php

namespace App\Interfaces;

/**
 * JuegoInterface
 *
 * Contrato del módulo de juego: lista de niveles disponibles según
 * el progreso del jugador, inicio de partidas, registro de respuestas
 * y cierre de partida (con actualización de puntos y progreso).
 */
interface JuegoInterface
{
    /** Devuelve todos los tema_nivel con su estado para este usuario: bloqueado, disponible o aprobado. */
    public function obtenerNivelesConEstado(int $idUsuario): array;

    /** Requisito #8: mejor % logrado por otros jugadores en este mismo tema_nivel. */
    public function obtenerAvanceDeOtros(int $idTemaNivel, int $idUsuarioExcluir, int $limite = 5): array;

    /** Verifica si el usuario puede jugar este tema_nivel (según su progreso). */
    public function nivelDesbloqueado(int $idUsuario, int $idTemaNivel): bool;

    /** Crea la partida y el registro de jugador; devuelve el id_partida_jugador. */
    public function iniciarPartida(int $idUsuario, int $idTemaNivel): int;

    /** Registra la respuesta de una pregunta (con tiempo en segundos) y devuelve si fue correcta. */
    public function registrarRespuesta(int $idPartidaJugador, int $idPregunta, int $idOpcionSeleccionada, ?float $tiempoRespuesta = null): bool;

    /** Cierra la partida: calcula puntaje, actualiza progreso y puntos totales del usuario. */
    public function finalizarPartida(int $idPartidaJugador, int $idUsuario, int $idTemaNivel, int $totalPreguntas, int $totalCorrectas): array;
}
