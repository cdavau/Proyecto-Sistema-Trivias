<?php

namespace App\Interfaces;

/**
 * PreguntaInterface
 *
 * Contrato CRUD para preguntas de opción múltiple o verdadero/falso,
 * alineadas a un tema+nivel específico.
 */
interface PreguntaInterface
{
   
    public function crear(int $idTemaNivel, string $enunciado, string $tipoPregunta, int $idUsuarioCreador, array $opciones): int;
    public function listarPorTemaNivel(int $idTemaNivel): array;
    public function obtenerPorId(int $idPregunta): ?array;
    public function actualizarEnunciado(int $idPregunta, string $nuevoEnunciado): bool;
    public function eliminar(int $idPregunta): bool;
}
