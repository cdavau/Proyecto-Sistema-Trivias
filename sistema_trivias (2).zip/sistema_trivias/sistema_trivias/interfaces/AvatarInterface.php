<?php

namespace App\Interfaces;

/**
 * AvatarInterface
 *
 * Contrato CRUD para el catálogo de avatares disponibles. A diferencia
 * de "eliminar" en otros módulos, aquí no existe borrado físico: el
 * campo "activo" permite retirar un avatar de la lista de selección
 * sin borrar el historial de quién ya lo tiene puesto.
 */
interface AvatarInterface
{
    public function crear(string $nombre, string $tipo, string $valor): int;

    /** Devuelve todos los avatares (activos e inactivos), para el panel de admin. */
    public function listar(): array;

    /** Devuelve solo los avatares activos, para que el jugador elija uno. */
    public function listarActivos(): array;

    public function obtenerPorId(int $idAvatar): ?array;

    public function actualizar(int $idAvatar, array $datos): bool;

    /** Baja lógica: activo = false. El avatar deja de ofrecerse, pero no se borra. */
    public function desactivar(int $idAvatar): bool;

    /** Reactiva un avatar previamente desactivado. */
    public function activar(int $idAvatar): bool;
}
