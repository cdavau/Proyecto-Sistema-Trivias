<?php

namespace App\Interfaces;
interface AutenticacionInterface
{
    /**
     * Intenta autenticar a un usuario con correo y contraseña.
     * Registra cada intento (exitoso o no) con IP y fecha.
     *
     * @throws \App\Exceptions\AutenticacionException si las credenciales
     *         son inválidas o la cuenta está bloqueada temporalmente.
     *
     * @return array Datos básicos del usuario autenticado (id, nombre, rol).
     */
    public function autenticar(string $correo, string $password, string $ip): array;
}
