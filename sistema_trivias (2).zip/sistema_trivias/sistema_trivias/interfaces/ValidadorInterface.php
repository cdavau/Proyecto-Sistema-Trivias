<?php

namespace App\Interfaces;

/**
 * ValidadorInterface
 *
 * Contrato para cualquier clase que sanitice y valide datos de entrada
 * del usuario (formularios, APIs, etc.), siguiendo las recomendaciones
 * de OWASP sobre validación de entradas.
 */
interface ValidadorInterface
{
    public function sanitizarTexto(string $valor): string;
    public function validarCorreo(string $correo): ?string;
    public function validarPassword(string $password): bool;
    public function validarEntero(mixed $valor, int $min = 0, int $max = PHP_INT_MAX): ?int;
    public function validarCedula(string $cedula): ?string;
    public function obtenerErrores(): array;
}
