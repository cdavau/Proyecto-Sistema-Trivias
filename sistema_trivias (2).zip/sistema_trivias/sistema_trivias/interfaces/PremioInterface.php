<?php

namespace App\Interfaces;

/**
 * PremioInterface
 *
 * Contrato CRUD para premios (con imagen y ponderación de puntos),
 * asociados a un nivel y/o tema.
 */
interface PremioInterface
{
    public function crear(string $nombrePremio, string $imagen, int $ponderacionPuntos, ?int $idNivel, ?int $idTema): int;
    public function listar(): array;
    public function obtenerPorId(int $idPremio): ?array;
    public function actualizar(int $idPremio, array $datos): bool;
    public function eliminar(int $idPremio): bool;
    public function otorgarPremiosPorNivelAprobado(int $idUsuario, int $idTema, int $idNivel): array;
}
