<?php

namespace App\Interfaces;

/**
 * EncuestaInterface
 *
 * Contrato para el módulo de encuestas de la página promocional,
 * donde se le pregunta al visitante qué temas le gustaría ver
 * implementados en el sistema de trivias.
 */
interface EncuestaInterface
{
    public function crearEncuesta(string $preguntaEncuesta): int;
    public function listarEncuestas(): array;
    public function registrarRespuesta(int $idEncuesta, ?string $nombreContacto, string $respuestaTexto): int;
    public function listarRespuestas(int $idEncuesta): array;
}
