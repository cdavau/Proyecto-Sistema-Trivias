<?php

namespace App\Interfaces;

/**
 * ManejadorErroresInterface
 *
 * Define el contrato que debe cumplir cualquier clase encargada de
 * manejar/registrar errores dentro del sistema .
 *
 * Cualquier módulo del sistema (Login, CRUD Usuarios, Preguntas, etc.)
 * puede depender de esta interfaz en lugar de una implementación
 * concreta.
 */
interface ManejadorErroresInterface
{
    /**
     * Registra un error (en archivo, base de datos, log, etc.)
     *
     * @param string $mensaje   Descripción del error
     * @param string $contexto  Módulo o clase donde ocurrió 
     * @param array  $datosExtra Información adicional (ip, usuario, query, etc.)
     */
    public function registrarError(string $mensaje, string $contexto = '', array $datosExtra = []): void;
    public function mensajeParaUsuario(string $mensajeInterno): string;
}
