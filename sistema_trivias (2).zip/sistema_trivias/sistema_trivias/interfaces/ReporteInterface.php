<?php

namespace App\Interfaces;

/**
 * ReporteInterface
 *
 * Contrato del módulo de reportes (requisito #15): reporte de
 * jugadores con tiempos y estadísticas, y datos listos para exportar.
 */
interface ReporteInterface
{
    public function obtenerReportePorJugador(): array;

    public function obtenerTotalesGenerales(): array;

    public function obtenerDistribucionPorNivel(): array;
}
