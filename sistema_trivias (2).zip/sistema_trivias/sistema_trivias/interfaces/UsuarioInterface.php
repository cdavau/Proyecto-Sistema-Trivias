<?php

namespace App\Interfaces;

/**
 * UsuarioInterface
 *
 * Contrato CRUD para la gestión de usuarios (altas, bajas, consultas)
 * que pide el alcance del proyecto.
 */
interface UsuarioInterface
{
    public function crear(string $nombre, string $apodo, string $cedula, string $correo, string $password, int $idRol): int;

    public function listar(): array;

    public function obtenerPorId(int $idUsuario): ?array;

    public function actualizar(int $idUsuario, array $datos): bool;
    public function eliminar(int $idUsuario): bool;
}
