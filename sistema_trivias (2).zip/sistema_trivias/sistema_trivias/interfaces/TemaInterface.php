<?php

namespace App\Interfaces;

/**
 * TemaInterface
 *
 * Contrato CRUD para el módulo de Temas y sus niveles asociados
 * 
 */
interface TemaInterface
{
    public function crearTema(string $nombreTema, string $descripcion): int;
    public function listarTemas(): array;
    public function obtenerTemaPorId(int $idTema): ?array;
    public function actualizarTema(int $idTema, array $datos): bool;
    public function eliminarTema(int $idTema): bool;

    public function crearTemaNivel(int $idTema, int $idNivel, string $nombreEspecifico): int;
    public function listarTemaNivel(): array;
    public function eliminarTemaNivel(int $idTemaNivel): bool;
    public function registrarReaccionTema(int $idUsuario, int $idTema, string $tipoReaccion): bool;

    public function obtenerConteoReaccionesPorTema(int $idTema): array;
    public function obtenerReaccionDeUsuario(int $idUsuario, int $idTema): ?string;
}
