<?php
require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Juego\JuegoService;
use App\Utils\ManejadorErroresArchivo;

$idPartidaJugador = 1; // 

$db = Database::obtenerInstancia();
$juego = new JuegoService($db, new ManejadorErroresArchivo());

$integro = $juego->verificarIntegridadPartida($idPartidaJugador);

echo $integro
    ? "✅ ÍNTEGRO: los datos no han sido manipulados."
    : "⚠️ MANIPULADO: la firma no coincide con los datos.";