<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Preguntas\PreguntaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ARMADOR, Roles::ADMINISTRADOR]);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: gestion_preguntas.php');
    exit;
} \App\Utils\Csrf::validar();

$idTemaNivel = (int) ($_POST['id_tema_nivel'] ?? 0);
$tipoPregunta = $_POST['tipo_pregunta'] ?? 'opcion_multiple';
$enunciado = $_POST['enunciado'] ?? '';
$idUsuarioCreador = (int) ($_POST['id_usuario_creador'] ?? 0);

$opciones = [];

if ($tipoPregunta === 'verdadero_falso') {
    $respuestaCorrecta = $_POST['respuesta_vf'] ?? 'verdadero';
    $opciones = [
        ['texto' => 'Verdadero', 'es_correcta' => $respuestaCorrecta === 'verdadero'],
        ['texto' => 'Falso', 'es_correcta' => $respuestaCorrecta === 'falso'],
    ];
} else {
    $textos = $_POST['opcion_texto'] ?? [];
    $indiceCorrecta = (int) ($_POST['opcion_correcta'] ?? 0);

    foreach ($textos as $i => $texto) {
        if (trim($texto) === '') {
            continue; 
        }
        $opciones[] = ['texto' => $texto, 'es_correcta' => $i === $indiceCorrecta];
    }
}

$db = Database::obtenerInstancia();
$preguntaService = new PreguntaService($db, new Validador(), new ManejadorErroresArchivo());

try {
    $preguntaService->crear($idTemaNivel, $enunciado, $tipoPregunta, $idUsuarioCreador, $opciones);
    header('Location: gestion_preguntas.php?id_tema_nivel=' . $idTemaNivel . '&exito=1');
    exit;

} catch (AutenticacionException $e) {
    header('Location: gestion_preguntas.php?id_tema_nivel=' . $idTemaNivel . '&error=' . urlencode($e->getMessage()));
    exit;
}
