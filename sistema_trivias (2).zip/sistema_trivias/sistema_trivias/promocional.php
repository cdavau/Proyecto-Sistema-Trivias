<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Encuestas\EncuestaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Validador;

$db = Database::obtenerInstancia();
$encuestaService = new EncuestaService($db, new Validador(), new ManejadorErroresArchivo());

$encuestas = $encuestaService->listarEncuestas();
if (empty($encuestas)) {
    $encuestaService->crearEncuesta('¿Qué temas o tecnologías te gustaría ver en el sistema de trivias?');
    $encuestas = $encuestaService->listarEncuestas();
}
$encuestaActual = $encuestas[0];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trivias UTP — Cuéntanos qué quieres aprender</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@600;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
    :root {
        --bg-deep: #15123c; --bg-deep-2: #201a5c;
        --magenta: #ff2e63; --yellow: #ffd23f; --teal: #08d9d6;
        --text-light: #f5f4ff; --text-muted: #a9a3d6;
    }
    * { box-sizing: border-box; }
    body {
        margin: 0; min-height: 100vh; display: flex; align-items: center; justify-content: center;
        font-family: 'Inter', sans-serif; padding: 20px;
        background:
            radial-gradient(circle at 20% 20%, rgba(255,210,63,0.18), transparent 40%),
            radial-gradient(circle at 80% 80%, rgba(255,46,99,0.2), transparent 40%),
            linear-gradient(160deg, var(--bg-deep) 0%, var(--bg-deep-2) 100%);
    }
    .tarjeta {
        background: rgba(255,255,255,0.04);
        backdrop-filter: blur(6px);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 28px;
        padding: 44px 38px;
        width: 440px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.45);
        color: var(--text-light);
    }
    .eyebrow {
        display: inline-flex; gap: 6px;
        background: linear-gradient(90deg, var(--teal), #4de8e5);
        color: #0c2d2c; font-weight: 700; font-size: 11px;
        text-transform: uppercase; letter-spacing: 0.08em;
        padding: 6px 14px; border-radius: 999px; margin-bottom: 18px;
    }
    h1 { font-family: 'Baloo 2', sans-serif; font-weight: 800; font-size: 24px; margin: 0 0 20px; line-height: 1.3; }
    label { display: block; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: var(--yellow); margin-top: 16px; margin-bottom: 6px; }
    input, textarea {
        width: 100%; padding: 12px 14px; background: rgba(255,255,255,0.06);
        border: 1.5px solid rgba(255,255,255,0.12); border-radius: 12px;
        color: var(--text-light); font-family: 'Inter', sans-serif; font-size: 14px;
        resize: vertical;
    }
    input:focus, textarea:focus { outline: none; border-color: var(--yellow); }
    .buzzer {
        appearance: none; border: none; width: 100%; margin-top: 24px; padding: 15px;
        border-radius: 999px; font-family: 'Baloo 2', sans-serif; font-weight: 800; font-size: 16px;
        color: #08302f; background: linear-gradient(180deg, var(--teal), #04b3b0);
        box-shadow: 0 6px 0 #037b79; cursor: pointer;
    }
    .buzzer:active { transform: translateY(6px); box-shadow: none; }
    .exito {
        margin-top: 16px; background: rgba(8,217,214,0.12); border: 1px solid rgba(8,217,214,0.4);
        color: #8ff5f3; font-size: 13px; padding: 10px 14px; border-radius: 10px; text-align: center;
    }
    .volver { display: block; text-align: center; margin-top: 20px; color: var(--text-muted); font-size: 13px; text-decoration: none; }
    .volver:hover { text-decoration: underline; }
</style>
</head>
<body>
    <div class="tarjeta">
        <span class="eyebrow">💡 Ayúdanos a mejorar</span>
        <h1><?= htmlspecialchars($encuestaActual['pregunta_encuesta']) ?></h1>

        <form action="procesar_encuesta.php" method="POST">
            <?= \App\Utils\Csrf::campo() ?>
            <input type="hidden" name="id_encuesta" value="<?= (int) $encuestaActual['id_encuesta'] ?>">

            <label for="nombre_contacto">Tu nombre (opcional)</label>
            <input type="text" id="nombre_contacto" name="nombre_contacto" placeholder="Puedes dejarlo en blanco">

            <label for="respuesta_texto">Tu respuesta</label>
            <textarea id="respuesta_texto" name="respuesta_texto" rows="4" placeholder="Ej: Me gustaría ver un tema de Python o de bases de datos NoSQL" required></textarea>

            <button type="submit" class="buzzer">📨 Enviar respuesta</button>
        </form>

        <?php if (isset($_GET['enviado'])): ?>
            <p class="exito">✅ ¡Gracias! Tu respuesta fue registrada.</p>
        <?php endif; ?>

        <a class="volver" href="index.php">← Volver al inicio</a>
    </div>
</body>
</html>
