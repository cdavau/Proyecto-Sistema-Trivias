<?php

require_once __DIR__ . '/bootstrap.php';

use App\Avatares\AvatarService;
use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ADMINISTRADOR]);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: gestion_avatares.php');
    exit;
} \App\Utils\Csrf::validar();

$idAvatar = (int) ($_POST['id_avatar'] ?? 0);

$db = Database::obtenerInstancia();
$avatarService = new AvatarService($db, new Validador(), new ManejadorErroresArchivo());

try {
    $avatarService->actualizar($idAvatar, [
        'nombre' => $_POST['nombre'] ?? '',
        'tipo'   => $_POST['tipo'] ?? 'emoji',
        'valor'  => $_POST['valor'] ?? '',
    ]);
    header('Location: gestion_avatares.php?exito=1');
    exit;

} catch (AutenticacionException $e) {
    header('Location: gestion_avatares.php?error=' . urlencode($e->getMessage()));
    exit;
}
