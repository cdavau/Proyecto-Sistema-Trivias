<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Usuarios\UsuarioService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ADMINISTRADOR]);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: gestion_usuarios.php');
    exit;
} \App\Utils\Csrf::validar();

$db = Database::obtenerInstancia();
$usuarioService = new UsuarioService($db, new Validador(), new ManejadorErroresArchivo());

$idUsuario = (int) ($_POST['id_usuario'] ?? 0);
$nuevoEstado = $_POST['nuevo_estado'] ?? 'activo';

$usuarioService->actualizar($idUsuario, ['estado' => $nuevoEstado]);

header('Location: gestion_usuarios.php?exito=1');
exit;
