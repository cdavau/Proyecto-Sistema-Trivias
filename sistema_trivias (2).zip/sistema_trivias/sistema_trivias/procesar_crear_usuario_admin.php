<?php


require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Usuarios\UsuarioService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ADMINISTRADOR]);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: gestion_usuarios.php');
    exit;
} \App\Utils\Csrf::validar();

$nombre   = $_POST['nombre'] ?? '';
$apodo    = $_POST['apodo'] ?? '';
$cedula   = $_POST['cedula'] ?? '';
$correo   = $_POST['correo'] ?? '';
$password = $_POST['password'] ?? '';
$idRol    = (int) ($_POST['id_rol'] ?? Roles::JUGADOR);

$db             = Database::obtenerInstancia();
$usuarioService = new UsuarioService($db, new Validador(), new ManejadorErroresArchivo());

try {
    $usuarioService->crear($nombre, $apodo, $cedula, $correo, $password, $idRol);
    header('Location: gestion_usuarios.php?exito=1');
    exit;

} catch (AutenticacionException $e) {
    header('Location: gestion_usuarios.php?error=' . urlencode($e->getMessage()));
    exit;
}
