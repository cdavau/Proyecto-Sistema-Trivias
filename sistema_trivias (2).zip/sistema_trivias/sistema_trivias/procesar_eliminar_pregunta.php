<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Preguntas\PreguntaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ARMADOR, Roles::ADMINISTRADOR]);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: gestion_preguntas.php');
    exit;
} \App\Utils\Csrf::validar();

$db = Database::obtenerInstancia();
$preguntaService = new PreguntaService($db, new Validador(), new ManejadorErroresArchivo());

$idPregunta = (int) ($_POST['id_pregunta'] ?? 0);
$idTemaNivel = (int) ($_POST['id_tema_nivel'] ?? 0);
$destino = 'gestion_preguntas.php?id_tema_nivel=' . $idTemaNivel;

try {
    $preguntaService->eliminar($idPregunta);
    header('Location: ' . $destino . '&exito=eliminada');
    exit;

} catch (AutenticacionException $e) {
    header('Location: ' . $destino . '&error=' . urlencode($e->getMessage()));
    exit;
}
