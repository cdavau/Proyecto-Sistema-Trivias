-- =========================================================
-- MIGRACIÓN: catálogo de avatares administrable (con "activo")
-- Ejecutar solo si la base de datos YA existía antes de este cambio.
-- Es segura de correr varias veces (no duplica avatares).
-- =========================================================

USE sistema_trivias;

CREATE TABLE IF NOT EXISTS avatar (
    id_avatar INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(60) NOT NULL,
    tipo ENUM('emoji','imagen') NOT NULL DEFAULT 'emoji',
    valor VARCHAR(255) NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO avatar (nombre, tipo, valor, activo)
SELECT * FROM (SELECT 'Superhéroe', 'emoji', '🦸', TRUE) AS t
WHERE NOT EXISTS (SELECT 1 FROM avatar WHERE valor = '🦸');

INSERT INTO avatar (nombre, tipo, valor, activo)
SELECT * FROM (SELECT 'Mago', 'emoji', '🧙', TRUE) AS t
WHERE NOT EXISTS (SELECT 1 FROM avatar WHERE valor = '🧙');

INSERT INTO avatar (nombre, tipo, valor, activo)
SELECT * FROM (SELECT 'Robot', 'emoji', '🤖', TRUE) AS t
WHERE NOT EXISTS (SELECT 1 FROM avatar WHERE valor = '🤖');

INSERT INTO avatar (nombre, tipo, valor, activo)
SELECT * FROM (SELECT 'Gato', 'emoji', '🐱', TRUE) AS t
WHERE NOT EXISTS (SELECT 1 FROM avatar WHERE valor = '🐱');

INSERT INTO avatar (nombre, tipo, valor, activo)
SELECT * FROM (SELECT 'Zorro', 'emoji', '🦊', TRUE) AS t
WHERE NOT EXISTS (SELECT 1 FROM avatar WHERE valor = '🦊');

INSERT INTO avatar (nombre, tipo, valor, activo)
SELECT * FROM (SELECT 'Panda', 'emoji', '🐼', TRUE) AS t
WHERE NOT EXISTS (SELECT 1 FROM avatar WHERE valor = '🐼');

INSERT INTO avatar (nombre, tipo, valor, activo)
SELECT * FROM (SELECT 'Rana', 'emoji', '🐸', TRUE) AS t
WHERE NOT EXISTS (SELECT 1 FROM avatar WHERE valor = '🐸');

INSERT INTO avatar (nombre, tipo, valor, activo)
SELECT * FROM (SELECT 'León', 'emoji', '🦁', TRUE) AS t
WHERE NOT EXISTS (SELECT 1 FROM avatar WHERE valor = '🦁');

INSERT INTO avatar (nombre, tipo, valor, activo)
SELECT * FROM (SELECT 'Alien', 'emoji', '👽', TRUE) AS t
WHERE NOT EXISTS (SELECT 1 FROM avatar WHERE valor = '👽');

INSERT INTO avatar (nombre, tipo, valor, activo)
SELECT * FROM (SELECT 'Ninja', 'emoji', '🥷', TRUE) AS t
WHERE NOT EXISTS (SELECT 1 FROM avatar WHERE valor = '🥷');

INSERT INTO avatar (nombre, tipo, valor, activo)
SELECT * FROM (SELECT 'Programador', 'emoji', '🧑‍💻', TRUE) AS t
WHERE NOT EXISTS (SELECT 1 FROM avatar WHERE valor = '🧑‍💻');

INSERT INTO avatar (nombre, tipo, valor, activo)
SELECT * FROM (SELECT 'Joystick', 'emoji', '🕹️', TRUE) AS t
WHERE NOT EXISTS (SELECT 1 FROM avatar WHERE valor = '🕹️');
