<?php

require_once __DIR__ . '/config/entorno.php';
require_once __DIR__ . '/interfaces/ManejadorErroresInterface.php';
require_once __DIR__ . '/interfaces/ValidadorInterface.php';
require_once __DIR__ . '/interfaces/UsuarioInterface.php';
require_once __DIR__ . '/utils/ManejadorErroresArchivo.php';
require_once __DIR__ . '/utils/Validador.php';
require_once __DIR__ . '/utils/Roles.php';
require_once __DIR__ . '/exceptions/DatabaseException.php';
require_once __DIR__ . '/exceptions/AutenticacionException.php';
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/usuarios/UsuarioService.php';
require_once __DIR__ . '/utils/Csrf.php';

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Usuarios\UsuarioService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\Validador;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: registro.php');
    exit;
}

\App\Utils\Csrf::validar();

$nombre   = $_POST['nombre'] ?? '';
$apodo    = $_POST['apodo'] ?? '';
$cedula   = $_POST['cedula'] ?? '';
$correo   = $_POST['correo'] ?? '';
$password = $_POST['password'] ?? '';

$db             = Database::obtenerInstancia();
$usuarioService = new UsuarioService($db, new Validador(), new ManejadorErroresArchivo());

try {
    $usuarioService->crear($nombre, $apodo, $cedula, $correo, $password, Roles::JUGADOR);
    header('Location: login.php?registrado=1');
    exit;

} catch (AutenticacionException $e) {
    header('Location: registro.php?error=' . urlencode($e->getMessage()));
    exit;
}
