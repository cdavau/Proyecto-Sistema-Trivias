-- Administrador
INSERT IGNORE INTO usuario (nombre, apodo, cedula, correo, password_hash, id_rol, estado)
SELECT 'Administrador', 'admin', '8-888-8888', 'admin@trivias.com',
       '$2y$10$3RlZ/hGJfPKbhm1.RVQVUu0mw.PRIa5nGwk1dmBenk6ggycKlPLni',
       r.id_rol, 'activo'
FROM rol r
WHERE r.nombre_rol = 'administrador';

-- Jugador
INSERT IGNORE INTO usuario (nombre, apodo, cedula, correo, password_hash, id_rol, estado)
SELECT 'Usuario Prueba', 'jugador', '8-111-1111', 'user@trivias.com',
       '$2y$10$UkBUTNznyTdWD8A7qB5vceWLOmntTfe3kouTZe9/TcMoeRIO733r2',
       r.id_rol, 'activo'
FROM rol r
WHERE r.nombre_rol = 'jugador';

-- Armador
INSERT IGNORE INTO usuario (nombre, apodo, cedula, correo, password_hash, id_rol, estado)
SELECT 'Armador Prueba', 'armador', '8-222-2222', 'armador@trivias.com',
       '$2y$10$uhWXH0ar9Hw4WPfHgUf1z.RCG7tGHbhC19jssP0ZGRRgUuhdCtUbq',
       r.id_rol, 'activo'
FROM rol r
WHERE r.nombre_rol = 'armador';