<?php


require_once __DIR__ . '/config/entorno.php';

require_once __DIR__ . '/interfaces/ValidadorInterface.php';
require_once __DIR__ . '/utils/Validador.php';

use App\Utils\Validador;

header('Content-Type: text/plain; charset=utf-8');

$validador = new Validador();

$correo = $validador->validarCorreo('  DAVID.Cordoba@Estudiante.UTP.AC.PA  ');
echo "Correo sanitizado: " . ($correo ?? 'INVÁLIDO') . "\n\n";

$correoMalo = $validador->validarCorreo('esto-no-es-un-correo');
echo "Correo inválido probado: " . ($correoMalo ?? 'RECHAZADO CORRECTAMENTE') . "\n\n";

$passwordDebil = $validador->validarPassword('12345');
echo "Password débil (123456) válida: " . ($passwordDebil ? 'SÍ' : 'NO (correcto, debe rechazarse)') . "\n\n";

$passwordFuerte = $validador->validarPassword('Trivias2026');
echo "Password fuerte (Trivias2026) válida: " . ($passwordFuerte ? 'SÍ (correcto)' : 'NO') . "\n\n";

$textoSucio = '<script>alert("hack")</script> David';
$textoLimpio = $validador->sanitizarTexto($textoSucio);
echo "Texto original: {$textoSucio}\n";
echo "Texto sanitizado: {$textoLimpio}\n\n";

$entero = $validador->validarEntero('999', 1, 100);
echo "Entero 999 (rango 1-100): " . ($entero ?? 'RECHAZADO CORRECTAMENTE') . "\n\n";

echo "=== ERRORES ACUMULADOS ===\n";
foreach ($validador->obtenerErrores() as $error) {
    echo "- {$error}\n";
}
