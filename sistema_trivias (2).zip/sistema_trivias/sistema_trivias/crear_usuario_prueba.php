<?php

// Crea un usuario de prueba para el login (david@trivias.com / Trivias2026).
// Correr una sola vez.

require_once __DIR__ . '/config/entorno.php';

require_once __DIR__ . '/interfaces/ManejadorErroresInterface.php';
require_once __DIR__ . '/utils/ManejadorErroresArchivo.php';
require_once __DIR__ . '/exceptions/DatabaseException.php';
require_once __DIR__ . '/config/Database.php';

use App\Config\Database;

header('Content-Type: text/plain; charset=utf-8');

$db = Database::obtenerInstancia();
$pdo = $db->obtenerConexion();

$correo = 'david@trivias.com';
$passwordPlano = 'Trivias2026';
$passwordHash = password_hash($passwordPlano, PASSWORD_BCRYPT);

$check = $pdo->prepare('SELECT id_usuario FROM usuario WHERE correo = :correo');
$check->execute(['correo' => $correo]);

if ($check->fetch()) {
    echo "El usuario de prueba ya existe. No se creó de nuevo.\n";
    echo "Correo: {$correo}\n";
    echo "Password: {$passwordPlano}\n";
    exit;
}

$stmt = $pdo->prepare(
    'INSERT INTO usuario (nombre, apodo, cedula, correo, password_hash, id_rol, estado)
     VALUES (:nombre, :apodo, :cedula, :correo, :password_hash, 1, "activo")'
);
$stmt->execute([
    'nombre'        => 'David Córdoba',
    'apodo'         => 'davidc',
    'cedula'        => '8-123-4567',
    'correo'        => $correo,
    'password_hash' => $passwordHash,
]);

echo "✅ Usuario de prueba creado correctamente.\n\n";
echo "Correo:   {$correo}\n";
echo "Password: {$passwordPlano}\n";
