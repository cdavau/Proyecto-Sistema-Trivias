CREATE DATABASE IF NOT EXISTS sistema_trivias
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE sistema_trivias;

-- =========================================================
-- 1. ROL
-- =========================================================
CREATE TABLE rol (
    id_rol INT AUTO_INCREMENT PRIMARY KEY,
    nombre_rol VARCHAR(30) NOT NULL UNIQUE  -- jugador, armador, administrador
) ENGINE=InnoDB;

-- =========================================================
-- 2. USUARIO
-- =========================================================
CREATE TABLE usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apodo VARCHAR(50) NOT NULL UNIQUE,
    cedula VARCHAR(20) NOT NULL UNIQUE,
    correo VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    avatar VARCHAR(255) DEFAULT NULL,          
    id_rol INT NOT NULL,
    puntos_totales INT DEFAULT 0,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
    estado ENUM('activo','inactivo','bloqueado') DEFAULT 'activo',
    FOREIGN KEY (id_rol) REFERENCES rol(id_rol)
) ENGINE=InnoDB;

-- =========================================================
-- 2.1 AVATAR (catálogo administrable, con baja lógica vía "activo")
-- =========================================================
CREATE TABLE avatar (
    id_avatar INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(60) NOT NULL,
    tipo ENUM('emoji','imagen') NOT NULL DEFAULT 'emoji',
    valor VARCHAR(255) NOT NULL,        
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =========================================================
-- 3. INTENTO DE LOGIN (registro de anomalías, ip, fecha)
-- =========================================================
CREATE TABLE intento_login (
    id_intento INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT DEFAULT NULL,               
    correo_ingresado VARCHAR(150) NOT NULL,
    ip VARCHAR(45) NOT NULL,
    fecha_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
    exitoso BOOLEAN DEFAULT FALSE,
    numero_intento TINYINT NOT NULL,           -- 1, 2, 3
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;

-- =========================================================
-- 4. TEMA
-- =========================================================
CREATE TABLE tema (
    id_tema INT AUTO_INCREMENT PRIMARY KEY,
    nombre_tema VARCHAR(80) NOT NULL,          -- PHP, JavaScript, Laravel
    descripcion TEXT
) ENGINE=InnoDB;

-- =========================================================
-- 5. NIVEL DE CONOCIMIENTO
-- =========================================================
CREATE TABLE nivel_conocimiento (
    id_nivel INT AUTO_INCREMENT PRIMARY KEY,
    nombre_nivel VARCHAR(30) NOT NULL,         -- Novato/Básico, Intermedio, Avanzado/Experto
    orden TINYINT NOT NULL                     
) ENGINE=InnoDB;

-- =========================================================
-- 6. TEMA_NIVEL (ej: "PHP básico", "PHP avanzado - BD")
-- =========================================================
CREATE TABLE tema_nivel (
    id_tema_nivel INT AUTO_INCREMENT PRIMARY KEY,
    id_tema INT NOT NULL,
    id_nivel INT NOT NULL,
    nombre_especifico VARCHAR(120) NOT NULL,
    FOREIGN KEY (id_tema) REFERENCES tema(id_tema),
    FOREIGN KEY (id_nivel) REFERENCES nivel_conocimiento(id_nivel),
    UNIQUE KEY uq_tema_nivel (id_tema, id_nivel)
) ENGINE=InnoDB;

-- =========================================================
-- 7. USUARIO_PROGRESO (controla avance secuencial por nivel)
-- =========================================================
CREATE TABLE usuario_progreso (
    id_progreso INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_tema_nivel INT NOT NULL,
    estado ENUM('bloqueado','en_curso','aprobado') DEFAULT 'bloqueado',
    mejor_porcentaje TINYINT DEFAULT 0,        -- mejor % de aciertos logrado (requisito #8: barra de progreso)
    fecha_inicio DATETIME DEFAULT NULL,
    fecha_fin DATETIME DEFAULT NULL,
    tiempo_transcurrido INT DEFAULT NULL,      -- en segundos
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_tema_nivel) REFERENCES tema_nivel(id_tema_nivel),
    UNIQUE KEY uq_usuario_tema_nivel (id_usuario, id_tema_nivel)
) ENGINE=InnoDB;

-- =========================================================
-- 8. PREGUNTA
-- =========================================================
CREATE TABLE pregunta (
    id_pregunta INT AUTO_INCREMENT PRIMARY KEY,
    id_tema_nivel INT NOT NULL,
    enunciado TEXT NOT NULL,
    tipo_pregunta ENUM('opcion_multiple','verdadero_falso') NOT NULL,
    id_usuario_creador INT NOT NULL,           -- armador que la creó
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_tema_nivel) REFERENCES tema_nivel(id_tema_nivel),
    FOREIGN KEY (id_usuario_creador) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;

-- =========================================================
-- 9. OPCION_RESPUESTA
-- =========================================================
CREATE TABLE opcion_respuesta (
    id_opcion INT AUTO_INCREMENT PRIMARY KEY,
    id_pregunta INT NOT NULL,
    texto_opcion VARCHAR(255) NOT NULL,
    es_correcta BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (id_pregunta) REFERENCES pregunta(id_pregunta)
) ENGINE=InnoDB;

-- =========================================================
-- 10. PREMIO
-- =========================================================
CREATE TABLE premio (
    id_premio INT AUTO_INCREMENT PRIMARY KEY,
    nombre_premio VARCHAR(100) NOT NULL,
    imagen VARCHAR(255) NOT NULL,
    ponderacion_puntos INT NOT NULL,
    id_nivel INT DEFAULT NULL,
    id_tema INT DEFAULT NULL,
    FOREIGN KEY (id_nivel) REFERENCES nivel_conocimiento(id_nivel),
    FOREIGN KEY (id_tema) REFERENCES tema(id_tema)
) ENGINE=InnoDB;

-- =========================================================
-- 11. USUARIO_PREMIO (premios ganados)
-- =========================================================
CREATE TABLE usuario_premio (
    id_usuario_premio INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_premio INT NOT NULL,
    fecha_obtenido DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_premio) REFERENCES premio(id_premio)
) ENGINE=InnoDB;

-- =========================================================
-- 12. PARTIDA_TRIVIA (individual o multijugador)
-- =========================================================
CREATE TABLE partida_trivia (
    id_partida INT AUTO_INCREMENT PRIMARY KEY,
    id_tema_nivel INT NOT NULL,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    tipo ENUM('individual','multijugador') DEFAULT 'individual',
    FOREIGN KEY (id_tema_nivel) REFERENCES tema_nivel(id_tema_nivel)
) ENGINE=InnoDB;

-- =========================================================
-- 13. PARTIDA_JUGADOR
-- =========================================================
CREATE TABLE partida_jugador (
    id_partida_jugador INT AUTO_INCREMENT PRIMARY KEY,
    id_partida INT NOT NULL,
    id_usuario INT NOT NULL,
    puntos_obtenidos INT DEFAULT 0,
    tiempo_respuesta_promedio DECIMAL(6,2) DEFAULT NULL,
    posicion_final TINYINT DEFAULT NULL,
    firma VARCHAR(64) DEFAULT NULL,          -- sello de integridad (firma digital)
    FOREIGN KEY (id_partida) REFERENCES partida_trivia(id_partida),
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;

-- =========================================================
-- 14. RESPUESTA_USUARIO
-- =========================================================
CREATE TABLE respuesta_usuario (
    id_respuesta_usuario INT AUTO_INCREMENT PRIMARY KEY,
    id_partida_jugador INT NOT NULL,
    id_pregunta INT NOT NULL,
    id_opcion_seleccionada INT NOT NULL,
    es_correcta BOOLEAN DEFAULT FALSE,
    tiempo_respuesta DECIMAL(6,2) DEFAULT NULL, -- segundos
    FOREIGN KEY (id_partida_jugador) REFERENCES partida_jugador(id_partida_jugador),
    FOREIGN KEY (id_pregunta) REFERENCES pregunta(id_pregunta),
    FOREIGN KEY (id_opcion_seleccionada) REFERENCES opcion_respuesta(id_opcion)
) ENGINE=InnoDB;

-- =========================================================
-- 15. LIKE_TEMA (reacciones: interesante, aburrido, genial)
-- =========================================================
CREATE TABLE like_tema (
    id_like INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_tema INT NOT NULL,
    tipo_reaccion ENUM('interesante','aburrido','genial') NOT NULL,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_tema) REFERENCES tema(id_tema)
) ENGINE=InnoDB;

-- =========================================================
-- 16. ENCUESTA (página promocional)
-- =========================================================
CREATE TABLE encuesta (
    id_encuesta INT AUTO_INCREMENT PRIMARY KEY,
    pregunta_encuesta VARCHAR(255) NOT NULL,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =========================================================
-- 17. RESPUESTA_ENCUESTA
-- =========================================================
CREATE TABLE respuesta_encuesta (
    id_respuesta_encuesta INT AUTO_INCREMENT PRIMARY KEY,
    id_encuesta INT NOT NULL,
    nombre_contacto VARCHAR(100) DEFAULT NULL,  -- opcional, puede ser anónimo
    respuesta_texto TEXT NOT NULL,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_encuesta) REFERENCES encuesta(id_encuesta)
) ENGINE=InnoDB;

-- =========================================================
-- 18. MENSAJE
-- =========================================================
CREATE TABLE mensaje (
    id_mensaje INT AUTO_INCREMENT PRIMARY KEY,
    id_emisor INT NOT NULL,
    id_receptor INT DEFAULT NULL,               -- NULL = mensaje general/broadcast
    contenido TEXT NOT NULL,
    fecha_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
    leido BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (id_emisor) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_receptor) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;

-- =========================================================
-- DATOS INICIALES (seed)
-- =========================================================
INSERT INTO rol (nombre_rol) VALUES ('jugador'), ('armador'), ('administrador');

INSERT INTO nivel_conocimiento (nombre_nivel, orden) VALUES
('Novato', 1),
('Intermedio', 2),
('Avanzado', 3);

INSERT INTO tema (nombre_tema, descripcion) VALUES
('PHP', 'Fundamentos y buenas prácticas de PHP'),
('JavaScript', 'Programación en el navegador y lógica de scripting'),
('Laravel', 'Framework PHP para desarrollo web moderno');

-- Ejemplo de tema_nivel (PHP básico, PHP intermedio con BD, PHP avanzado, Laravel)
INSERT INTO tema_nivel (id_tema, id_nivel, nombre_especifico) VALUES
(1, 1, 'PHP Básico'),
(1, 2, 'PHP Intermedio (Bases de Datos)'),
(1, 3, 'PHP Avanzado'),
(2, 1, 'JavaScript Básico'),
(2, 2, 'JavaScript Intermedio'),
(2, 3, 'JavaScript Avanzado'),
(3, 2, 'Laravel Intermedio'),
(3, 3, 'Laravel Avanzado');

INSERT INTO avatar (nombre, tipo, valor, activo) VALUES
('Superhéroe', 'emoji', '🦸', TRUE),
('Mago', 'emoji', '🧙', TRUE),
('Robot', 'emoji', '🤖', TRUE),
('Gato', 'emoji', '🐱', TRUE),
('Zorro', 'emoji', '🦊', TRUE),
('Panda', 'emoji', '🐼', TRUE),
('Rana', 'emoji', '🐸', TRUE),
('León', 'emoji', '🦁', TRUE),
('Alien', 'emoji', '👽', TRUE),
('Ninja', 'emoji', '🥷', TRUE),
('Programador', 'emoji', '🧑‍💻', TRUE),
('Joystick', 'emoji', '🕹️', TRUE);

-- =========================================================
-- VISTA: Estadísticas de temas más jugados
-- =========================================================
CREATE VIEW vista_estadisticas_temas AS
SELECT
    t.id_tema,
    t.nombre_tema,
    COUNT(DISTINCT pt.id_partida) AS veces_jugado,
    ROUND(AVG(ru.es_correcta) * 100, 2) AS porcentaje_aciertos
FROM tema t
JOIN tema_nivel tn ON tn.id_tema = t.id_tema
JOIN partida_trivia pt ON pt.id_tema_nivel = tn.id_tema_nivel
JOIN partida_jugador pj ON pj.id_partida = pt.id_partida
JOIN respuesta_usuario ru ON ru.id_partida_jugador = pj.id_partida_jugador
GROUP BY t.id_tema, t.nombre_tema;

-- =========================================================
-- VISTA: Avance de usuarios (para reporte Excel)
-- =========================================================
CREATE VIEW vista_avance_usuarios AS
SELECT
    u.id_usuario,
    u.nombre,
    u.apodo,
    tn.nombre_especifico,
    up.estado,
    up.fecha_inicio,
    up.fecha_fin,
    up.tiempo_transcurrido
FROM usuario u
JOIN usuario_progreso up ON up.id_usuario = u.id_usuario
JOIN tema_nivel tn ON tn.id_tema_nivel = up.id_tema_nivel;
