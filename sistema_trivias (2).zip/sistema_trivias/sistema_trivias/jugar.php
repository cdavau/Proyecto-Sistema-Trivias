<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Juego\JuegoService;
use App\Temas\TemaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::iniciar();
if (!SesionUtil::estaAutenticado()) {
    header('Location: login.php');
    exit;
}

$usuarioSesion = SesionUtil::usuarioActual();
$db = Database::obtenerInstancia();
$juegoService = new JuegoService($db, new ManejadorErroresArchivo());
$temaService = new TemaService($db, new Validador(), new ManejadorErroresArchivo());

$niveles = $juegoService->obtenerNivelesConEstado((int) $usuarioSesion['id_usuario']);

$porTema = [];
foreach ($niveles as $n) {
    $porTema[$n['nombre_tema']][] = $n;
}

$reaccionesPorTema = [];
foreach ($porTema as $nombreTema => $nivelesTema) {
    $idTema = (int) $nivelesTema[0]['id_tema'];
    $reaccionesPorTema[$nombreTema] = [
        'id_tema' => $idTema,
        'conteo' => $temaService->obtenerConteoReaccionesPorTema($idTema),
        'mia' => $temaService->obtenerReaccionDeUsuario((int) $usuarioSesion['id_usuario'], $idTema),
    ];
}

$iconosTema = ['PHP' => '🐘', 'JavaScript' => '⚡', 'Laravel' => '🔺'];

$configuracionApp = require __DIR__ . '/config/config.php';

if (!empty($configuracionApp['url_base'])) {
    $urlBaseQr = rtrim($configuracionApp['url_base'], '/') . '/acceder_qr.php?id_tema_nivel=';
} else {
    $esquema = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $carpetaBase = rtrim(str_replace('\\', '/', dirname($_SERVER['PHP_SELF'])), '/');
    $urlBaseQr = $esquema . '://' . $_SERVER['HTTP_HOST'] . $carpetaBase . '/acceder_qr.php?id_tema_nivel=';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Jugar — Trivias UTP</title>
<link rel="stylesheet" href="assets/estilo.css">
<style>
    .contenedor { max-width: 900px; margin: 0 auto; padding: 44px 24px; }
    .tema-bloque { margin-bottom: 34px; }
    .tema-titulo { display: flex; align-items: center; gap: 10px; margin-bottom: 14px; }
    .tema-titulo .icono { font-size: 24px; }
    .grid-niveles { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; }

    .nivel-card {
        border-radius: 18px;
        padding: 20px;
        border: 1px solid rgba(255,255,255,0.1);
        position: relative;
    }
    .nivel-card.disponible { background: rgba(8,217,214,0.08); border-color: rgba(8,217,214,0.3); }
    .nivel-card.aprobado { background: rgba(255,210,63,0.08); border-color: rgba(255,210,63,0.35); }
    .nivel-card.bloqueado { background: rgba(255,255,255,0.03); opacity: 0.55; }

    .nivel-card h4 { font-family: 'Baloo 2', sans-serif; font-size: 16px; margin: 0 0 6px; }
    .nivel-card .estado { font-size: 12px; color: var(--text-muted); margin-bottom: 14px; }

    .btn-jugar {
        display: inline-block; text-decoration: none;
        padding: 9px 18px; border-radius: 999px; font-weight: 700; font-size: 13px;
        background: linear-gradient(180deg, var(--teal), #04b3b0); color: #08302f;
    }
    .btn-jugar.repasar { background: linear-gradient(180deg, var(--yellow), #ffb703); }
    .candado { font-size: 20px; }

    .barra-progreso { height: 6px; background: rgba(255,255,255,0.1); border-radius: 999px; overflow: hidden; margin-bottom: 8px; }
    .barra-progreso-fill { height: 100%; background: linear-gradient(90deg, var(--magenta), var(--yellow)); transition: width 0.3s ease; }
    .porcentaje-texto { font-size: 11px; color: var(--text-muted); margin-bottom: 10px; }

    .avance-otros { margin-top: 12px; font-size: 11.5px; }
    .avance-otros summary { cursor: pointer; color: var(--teal); font-weight: 600; list-style: none; }
    .avance-otros summary::-webkit-details-marker { display: none; }
    .avance-otros .fila-otro { display: flex; justify-content: space-between; align-items: center; padding: 5px 0; color: var(--text-muted); border-bottom: 1px solid rgba(255,255,255,0.06); }
    .avance-otros .fila-otro:last-child { border-bottom: none; }
    .avance-otros .mini-avatar { width: 20px; height: 20px; border-radius: 50%; background: rgba(255,255,255,0.08); display: inline-flex; align-items: center; justify-content: center; font-size: 11px; overflow: hidden; margin-right: 6px; vertical-align: middle; }
    .avance-otros .mini-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .avance-otros .sin-datos { color: var(--text-muted); font-size: 11px; padding: 6px 0; }


    .btn-qr {
        display: inline-block; margin-left: 8px;
        padding: 9px 14px; border-radius: 999px; font-weight: 700; font-size: 13px;
        background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.18);
        color: var(--text-light); cursor: pointer; font-family: inherit;
    }
    .btn-qr:hover { background: rgba(255,255,255,0.14); }

    #qrcode-render { display: flex; justify-content: center; margin: 18px 0 6px; }
    #qrcode-render img, #qrcode-render canvas { border-radius: 12px; background: #fff; padding: 10px; }
    .qr-nota { text-align: center; color: var(--text-muted); font-size: 12.5px; margin: 0; }

    .volver { display: inline-block; margin-bottom: 20px; color: var(--text-muted); text-decoration: none; font-size: 13px; }

    .calificar-tema { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-left: auto; }
    .calificar-tema form { display: inline-flex; }
    .btn-reaccion {
        appearance: none; cursor: pointer; font-family: inherit;
        display: inline-flex; align-items: center; gap: 5px;
        border-radius: 999px; padding: 6px 12px; font-size: 12px; font-weight: 700;
        border: 1px solid rgba(255,255,255,0.14); background: rgba(255,255,255,0.05); color: var(--text-muted);
    }
    .btn-reaccion:hover { background: rgba(255,255,255,0.1); color: var(--text-light); }
    .btn-reaccion.activo { background: rgba(255,210,63,0.18); border-color: rgba(255,210,63,0.5); color: var(--yellow); }
    .tema-titulo { flex-wrap: wrap; }
    .sugerir-tema-link { display: block; text-align: center; margin: 40px 0 10px; color: var(--text-muted); font-size: 13px; text-decoration: none; }
    .sugerir-tema-link:hover { text-decoration: underline; color: var(--teal); }
</style>
</head>
<body>
<div class="contenedor">
    <a href="dashboard.php" class="volver">← Volver a mi marcador</a>
    <span class="eyebrow">🎮 A jugar</span>
    <h1 style="margin: 14px 0 30px;">Elige un tema y nivel</h1>

    <?php if (($_GET['error'] ?? '') === 'nivel_bloqueado'): ?>
        <p class="mensaje-error">🔒 Ese nivel todavía está bloqueado. Aprueba el nivel anterior primero.</p>
    <?php elseif (($_GET['error'] ?? '') === 'sin_preguntas'): ?>
        <p class="mensaje-error">⚠️ Este nivel todavía no tiene preguntas cargadas.</p>
    <?php elseif (isset($_GET['error'])): ?>
        <p class="mensaje-error">⚠️ <?= htmlspecialchars($_GET['error']) ?></p>
    <?php endif; ?>
    <?php if (isset($_GET['reaccion_ok'])): ?>
        <p class="mensaje-exito">✅ ¡Gracias por calificar el tema!</p>
    <?php endif; ?>

    <?php foreach ($porTema as $nombreTema => $nivelesTema):
        $reaccion = $reaccionesPorTema[$nombreTema];
    ?>
        <div class="tema-bloque" id="tema-<?= $reaccion['id_tema'] ?>">
            <div class="tema-titulo">
                <span class="icono"><?= $iconosTema[$nombreTema] ?? '📘' ?></span>
                <h2 style="font-size: 20px;"><?= htmlspecialchars($nombreTema) ?></h2>

                <div class="calificar-tema">
                    <?php
                    $opcionesReaccion = [
                        'genial' => ['emoji' => '🤩', 'texto' => 'Genial'],
                        'interesante' => ['emoji' => '🤔', 'texto' => 'Interesante'],
                        'aburrido' => ['emoji' => '😴', 'texto' => 'Aburrido'],
                    ];
                    foreach ($opcionesReaccion as $tipo => $info):
                    ?>
                    <form action="procesar_reaccion_tema.php" method="POST">
                        <?= \App\Utils\Csrf::campo() ?>
                        <input type="hidden" name="id_tema" value="<?= $reaccion['id_tema'] ?>">
                        <input type="hidden" name="tipo_reaccion" value="<?= $tipo ?>">
                        <input type="hidden" name="volver_a" value="jugar.php">
                        <button type="submit" class="btn-reaccion <?= $reaccion['mia'] === $tipo ? 'activo' : '' ?>" title="Calificar como <?= $info['texto'] ?>">
                            <?= $info['emoji'] ?> <?= $reaccion['conteo'][$tipo] ?>
                        </button>
                    </form>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="grid-niveles">
                <?php foreach ($nivelesTema as $n): ?>
                    <div class="nivel-card <?= $n['estado'] ?>">
                        <h4><?= htmlspecialchars($n['nombre_especifico']) ?></h4>

                        <?php if ($n['mejor_porcentaje'] > 0): ?>
                            <div class="barra-progreso"><div class="barra-progreso-fill" style="width: <?= $n['mejor_porcentaje'] ?>%;"></div></div>
                            <div class="porcentaje-texto">Tu mejor resultado: <?= $n['mejor_porcentaje'] ?>%</div>
                        <?php endif; ?>

                        <div class="estado">
                            <?php if ($n['estado'] === 'aprobado'): ?>
                                ✅ Aprobado
                            <?php elseif ($n['estado'] === 'disponible'): ?>
                                🟢 Disponible
                            <?php else: ?>
                                🔒 Bloqueado — aprueba el nivel anterior
                            <?php endif; ?>
                        </div>
                        <?php if ($n['estado'] === 'aprobado'): ?>
                            <a href="iniciar_partida.php?id_tema_nivel=<?= $n['id_tema_nivel'] ?>" class="btn-jugar repasar">🔁 Repasar</a>
                            <button type="button" class="btn-qr"
                                onclick="mostrarQr('<?= htmlspecialchars($urlBaseQr . $n['id_tema_nivel'], ENT_QUOTES) ?>', '<?= htmlspecialchars($nombreTema . ' — ' . $n['nombre_especifico'], ENT_QUOTES) ?>')">📱 QR</button>
                        <?php elseif ($n['estado'] === 'disponible'): ?>
                            <a href="iniciar_partida.php?id_tema_nivel=<?= $n['id_tema_nivel'] ?>" class="btn-jugar">▶ Jugar</a>
                            <button type="button" class="btn-qr"
                                onclick="mostrarQr('<?= htmlspecialchars($urlBaseQr . $n['id_tema_nivel'], ENT_QUOTES) ?>', '<?= htmlspecialchars($nombreTema . ' — ' . $n['nombre_especifico'], ENT_QUOTES) ?>')">📱 QR</button>
                        <?php else: ?>
                            <span class="candado">🔒</span>
                        <?php endif; ?>

                        <?php $avanceOtros = $juegoService->obtenerAvanceDeOtros((int) $n['id_tema_nivel'], (int) $usuarioSesion['id_usuario']); ?>
                        <details class="avance-otros">
                            <summary>👥 Avance de otros jugadores</summary>
                            <?php if (empty($avanceOtros)): ?>
                                <p class="sin-datos">Todavía nadie más ha jugado este nivel.</p>
                            <?php else: ?>
                                <?php foreach ($avanceOtros as $otro): ?>
                                    <div class="fila-otro">
                                        <span>
                                            <span class="mini-avatar">
                                                <?php if (!empty($otro['avatar']) && str_starts_with($otro['avatar'], 'uploads/')): ?>
                                                    <img src="<?= htmlspecialchars($otro['avatar']) ?>" alt="">
                                                <?php else: ?>
                                                    <?= $otro['avatar'] ?: '👤' ?>
                                                <?php endif; ?>
                                            </span>
                                            @<?= htmlspecialchars($otro['apodo']) ?>
                                        </span>
                                        <span><?= (int) $otro['mejor_porcentaje'] ?>%<?= $otro['estado'] === 'aprobado' ? ' ✅' : '' ?></span>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </details>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>

    <a href="promocional.php" class="sugerir-tema-link">💡 ¿Te gustaría ver otro tema o tecnología? Sugiérelo aquí →</a>
</div>

<div class="modal-overlay" id="modal-qr">
    <div class="modal-caja">
        <button type="button" class="modal-cerrar" onclick="cerrarModalQr()">✕</button>
        <span class="eyebrow">📱 Acceso por QR</span>
        <h3 id="qr-titulo-nivel" style="margin: 12px 0 4px;"></h3>
        <p class="qr-nota">Escanéalo con el celular para entrar directo a este nivel.</p>
        <div id="qrcode-render"></div>
        <p class="qr-nota" id="qr-url-texto" style="word-break: break-all;"></p>
        <p id="qr-aviso-local" style="display:none; background: rgba(255,46,99,0.12); border: 1px solid rgba(255,46,99,0.4); color: #ffb3c6; font-size: 12.5px; padding: 10px 12px; border-radius: 10px; margin-top: 12px;">
            ⚠️ Esta URL usa <strong>localhost/127.0.0.1</strong>, que el celular no puede abrir (para él, "localhost" es él mismo).
            Define <code>'url_base'</code> en <code>config/config.php</code> con la IP de esta PC en tu red WiFi
            (ej: <code>http://192.168.1.34/sistema_trivias</code>), asegúrate de que WAMP esté "Put Online" y que el celular esté en la misma red.
        </p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
<script>
    var qrActual = null;

    function mostrarQr(url, tituloNivel) {
        document.getElementById('qr-titulo-nivel').textContent = tituloNivel;
        document.getElementById('qr-url-texto').textContent = url;

        var contenedor = document.getElementById('qrcode-render');
        contenedor.innerHTML = '';
        qrActual = new QRCode(contenedor, {
            text: url,
            width: 200,
            height: 200
        });

        var esLocal = /^https?:\/\/(localhost|127\.0\.0\.1)([:/]|$)/i.test(url);
        document.getElementById('qr-aviso-local').style.display = esLocal ? 'block' : 'none';

        document.getElementById('modal-qr').classList.add('abierto');
    }

    function cerrarModalQr() {
        document.getElementById('modal-qr').classList.remove('abierto');
    }

    document.querySelectorAll('.modal-overlay').forEach(function (overlay) {
        overlay.addEventListener('click', function (evento) {
            if (evento.target === overlay) {
                overlay.classList.remove('abierto');
            }
        });
    });
</script>
</body>
</html>
