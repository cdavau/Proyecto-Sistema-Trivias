<?php

/**
 * acceder_qr.php
 *
 * Punto de entrada público al que apunta el código QR generado en
 * jugar.php para cada nivel (requisito #10: acceso a preguntas por QR).
 *

 */

require_once __DIR__ . '/bootstrap.php';

use App\Utils\SesionUtil;

SesionUtil::iniciar();

$idTemaNivel = (int) ($_GET['id_tema_nivel'] ?? 0);

if ($idTemaNivel <= 0) {
    header('Location: index.php');
    exit;
}

if (!SesionUtil::estaAutenticado()) {
    $_SESSION['qr_destino_tema_nivel'] = $idTemaNivel;
    header('Location: login.php?desde_qr=1');
    exit;
}

header('Location: iniciar_partida.php?id_tema_nivel=' . $idTemaNivel);
exit;
