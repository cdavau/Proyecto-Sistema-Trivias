<?php

require_once __DIR__ . '/bootstrap.php';

use App\Avatares\AvatarService;
use App\Config\Database;
use App\Usuarios\UsuarioService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::iniciar();
if (!SesionUtil::estaAutenticado()) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: avatar.php');
    exit;
}   \App\Utils\Csrf::validar();

$usuarioSesion = SesionUtil::usuarioActual();
$idUsuario = (int) $usuarioSesion['id_usuario'];

$db = Database::obtenerInstancia();
$usuarioService = new UsuarioService($db, new Validador(), new ManejadorErroresArchivo());
$avatarService = new AvatarService($db, new Validador(), new ManejadorErroresArchivo());
if (!empty($_POST['avatar_emoji'])) {
    $valorElegido = $_POST['avatar_emoji'];
    $activos = array_column($avatarService->listarActivos(), 'valor');

    if (!in_array($valorElegido, $activos, true)) {
        header('Location: avatar.php?error=' . urlencode('Ese avatar ya no está disponible. Elige otro.'));
        exit;
    }

    $usuarioService->actualizar($idUsuario, ['avatar' => $valorElegido]);
    header('Location: avatar.php');
    exit;
}

if (!empty($_FILES['foto_avatar']) && $_FILES['foto_avatar']['error'] === UPLOAD_ERR_OK) {
    $archivo = $_FILES['foto_avatar'];

    $tiposPermitidos = ['image/jpeg', 'image/png', 'image/webp'];
    $tamañoMaximo = 2 * 1024 * 1024; 

    $tipoReal = mime_content_type($archivo['tmp_name']);

    if (!in_array($tipoReal, $tiposPermitidos, true)) {
        header('Location: avatar.php?error=' . urlencode('Solo se permiten imágenes JPG, PNG o WEBP.'));
        exit;
    }

    if ($archivo['size'] > $tamañoMaximo) {
        header('Location: avatar.php?error=' . urlencode('La imagen no debe superar 2 MB.'));
        exit;
    }

    $extension = match ($tipoReal) {
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    };

    $nombreArchivo = 'avatar_' . $idUsuario . '_' . time() . '.' . $extension;
    $rutaDestino = __DIR__ . '/uploads/avatars/' . $nombreArchivo;

    if (move_uploaded_file($archivo['tmp_name'], $rutaDestino)) {
        $usuarioService->actualizar($idUsuario, ['avatar' => 'uploads/avatars/' . $nombreArchivo]);
        header('Location: avatar.php');
        exit;
    }

    header('Location: avatar.php?error=' . urlencode('No se pudo guardar la imagen.'));
    exit;
}

header('Location: avatar.php?error=' . urlencode('No se recibió ningún avatar.'));
exit;
