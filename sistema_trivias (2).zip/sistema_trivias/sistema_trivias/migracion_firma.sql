ALTER TABLE partida_jugador
    ADD COLUMN firma VARCHAR(64) DEFAULT NULL COMMENT 'Firma HMAC-SHA256 de integridad';