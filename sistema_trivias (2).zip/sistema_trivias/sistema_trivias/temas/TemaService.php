<?php

namespace App\Temas;

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Interfaces\ManejadorErroresInterface;
use App\Interfaces\TemaInterface;
use App\Interfaces\ValidadorInterface;
use PDO;
use PDOException;

/**
 * TemaService
 *
 * CRUD del módulo de Temas (PHP, JavaScript, Laravel) y sus niveles
 * asociados (Novato/Intermedio/Avanzado por tema), según el alcance:
 * "Temas en PHP, JavaScript, Laravel. Cada tema con niveles de
 * conocimiento. No debe pasar a un nivel avanzado si no ha pasado
 * el nivel básico."
 */
class TemaService implements TemaInterface
{
    private PDO $conexion;

    public function __construct(
        private Database $database,
        private ValidadorInterface $validador,
        private ManejadorErroresInterface $manejadorErrores
    ) {
        $this->conexion = $this->database->obtenerConexion();
    }

    public function crearTema(string $nombreTema, string $descripcion): int
    {
        $nombreValido = $this->validador->validarTextoObligatorio($nombreTema, 'nombre_tema', 2, 80);
        $descripcionValida = $this->validador->sanitizarTexto($descripcion);

        if (!$nombreValido) {
            throw new AutenticacionException(implode(' ', $this->validador->obtenerErrores()));
        }

        try {
            $stmt = $this->conexion->prepare(
                'INSERT INTO tema (nombre_tema, descripcion) VALUES (:nombre, :descripcion)'
            );
            $stmt->execute(['nombre' => $nombreValido, 'descripcion' => $descripcionValida]);

            return (int) $this->conexion->lastInsertId();

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'TemaService::crearTema');
            throw new AutenticacionException('No se pudo crear el tema.');
        }
    }

    public function listarTemas(): array
    {
        $stmt = $this->conexion->query('SELECT id_tema, nombre_tema, descripcion FROM tema ORDER BY nombre_tema');
        return $stmt->fetchAll();
    }

    public function obtenerTemaPorId(int $idTema): ?array
    {
        $stmt = $this->conexion->prepare('SELECT id_tema, nombre_tema, descripcion FROM tema WHERE id_tema = :id');
        $stmt->execute(['id' => $idTema]);
        $tema = $stmt->fetch();

        return $tema ?: null;
    }

    public function actualizarTema(int $idTema, array $datos): bool
    {
        $sets = [];
        $parametros = ['id' => $idTema];

        if (isset($datos['nombre_tema'])) {
            $nombreValido = $this->validador->validarTextoObligatorio($datos['nombre_tema'], 'nombre_tema', 2, 80);
            if (!$nombreValido) {
                throw new AutenticacionException(implode(' ', $this->validador->obtenerErrores()));
            }
            $sets[] = 'nombre_tema = :nombre_tema';
            $parametros['nombre_tema'] = $nombreValido;
        }

        if (isset($datos['descripcion'])) {
            $sets[] = 'descripcion = :descripcion';
            $parametros['descripcion'] = $this->validador->sanitizarTexto($datos['descripcion']);
        }

        if (empty($sets)) {
            return false;
        }

        $sql = 'UPDATE tema SET ' . implode(', ', $sets) . ' WHERE id_tema = :id';
        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute($parametros);
    }

    public function eliminarTema(int $idTema): bool
    {
        try {
            $stmt = $this->conexion->prepare('DELETE FROM tema WHERE id_tema = :id');
            return $stmt->execute(['id' => $idTema]);

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'TemaService::eliminarTema');
            throw new AutenticacionException(
                'No se pudo eliminar el tema (probablemente tiene niveles o preguntas asociadas).'
            );
        }
    }

    public function crearTemaNivel(int $idTema, int $idNivel, string $nombreEspecifico): int
    {
        $nombreValido = $this->validador->validarTextoObligatorio($nombreEspecifico, 'nombre_especifico', 3, 120);

        if (!$nombreValido) {
            throw new AutenticacionException(implode(' ', $this->validador->obtenerErrores()));
        }

        try {
            $stmt = $this->conexion->prepare(
                'INSERT INTO tema_nivel (id_tema, id_nivel, nombre_especifico)
                 VALUES (:id_tema, :id_nivel, :nombre_especifico)'
            );
            $stmt->execute([
                'id_tema' => $idTema,
                'id_nivel' => $idNivel,
                'nombre_especifico' => $nombreValido,
            ]);

            return (int) $this->conexion->lastInsertId();

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'TemaService::crearTemaNivel');
            throw new AutenticacionException('No se pudo crear el nivel del tema (¿ya existe esa combinación?).');
        }
    }

    public function listarTemaNivel(): array
    {
        $stmt = $this->conexion->query(
            'SELECT tn.id_tema_nivel, tn.nombre_especifico, tn.id_tema, tn.id_nivel,
                    t.nombre_tema, n.nombre_nivel, n.orden
             FROM tema_nivel tn
             JOIN tema t ON t.id_tema = tn.id_tema
             JOIN nivel_conocimiento n ON n.id_nivel = tn.id_nivel
             ORDER BY t.nombre_tema, n.orden'
        );

        return $stmt->fetchAll();
    }

    public function eliminarTemaNivel(int $idTemaNivel): bool
    {
        try {
            $stmt = $this->conexion->prepare('DELETE FROM tema_nivel WHERE id_tema_nivel = :id');
            return $stmt->execute(['id' => $idTemaNivel]);

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'TemaService::eliminarTemaNivel');
            throw new AutenticacionException(
                'No se pudo eliminar el nivel (probablemente tiene preguntas asociadas).'
            );
        }
    }

    public function registrarReaccionTema(int $idUsuario, int $idTema, string $tipoReaccion): bool
    {
        $tiposValidos = ['interesante', 'aburrido', 'genial'];
        if (!in_array($tipoReaccion, $tiposValidos, true)) {
            throw new AutenticacionException('Tipo de reacción inválido.');
        }

        try {
            $this->conexion->beginTransaction();

            $stmt = $this->conexion->prepare(
                'DELETE FROM like_tema WHERE id_usuario = :id_usuario AND id_tema = :id_tema'
            );
            $stmt->execute(['id_usuario' => $idUsuario, 'id_tema' => $idTema]);

            $stmt = $this->conexion->prepare(
                'INSERT INTO like_tema (id_usuario, id_tema, tipo_reaccion) VALUES (:id_usuario, :id_tema, :tipo)'
            );
            $resultado = $stmt->execute([
                'id_usuario' => $idUsuario,
                'id_tema' => $idTema,
                'tipo' => $tipoReaccion,
            ]);

            $this->conexion->commit();
            return $resultado;

        } catch (PDOException $e) {
            $this->conexion->rollBack();
            $this->manejadorErrores->registrarError($e->getMessage(), 'TemaService::registrarReaccionTema');
            throw new AutenticacionException('No se pudo registrar tu calificación.');
        }
    }

    public function obtenerConteoReaccionesPorTema(int $idTema): array
    {
        $stmt = $this->conexion->prepare(
            "SELECT tipo_reaccion, COUNT(*) AS total
             FROM like_tema
             WHERE id_tema = :id_tema
             GROUP BY tipo_reaccion"
        );
        $stmt->execute(['id_tema' => $idTema]);

        $conteo = ['interesante' => 0, 'aburrido' => 0, 'genial' => 0];
        foreach ($stmt->fetchAll() as $fila) {
            $conteo[$fila['tipo_reaccion']] = (int) $fila['total'];
        }

        return $conteo;
    }

    public function obtenerReaccionDeUsuario(int $idUsuario, int $idTema): ?string
    {
        $stmt = $this->conexion->prepare(
            'SELECT tipo_reaccion FROM like_tema WHERE id_usuario = :id_usuario AND id_tema = :id_tema LIMIT 1'
        );
        $stmt->execute(['id_usuario' => $idUsuario, 'id_tema' => $idTema]);
        $fila = $stmt->fetch();

        return $fila ? $fila['tipo_reaccion'] : null;
    }
}
