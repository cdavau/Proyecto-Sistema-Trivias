<?php
?>
<aside class="sidebar">
    <span class="logo">🎮 Trivias UTP</span>
    <nav>
        <a href="panel.php" class="<?= $paginaActiva === 'panel' ? 'activo' : '' ?>">🏠 Panel</a>
        <a href="gestion_temas.php" class="<?= $paginaActiva === 'temas' ? 'activo' : '' ?>">📚 Temas</a>
        <a href="gestion_preguntas.php" class="<?= $paginaActiva === 'preguntas' ? 'activo' : '' ?>">❓ Preguntas</a>
        <a href="gestion_premios.php" class="<?= $paginaActiva === 'premios' ? 'activo' : '' ?>">🏆 Premios</a>
        <a href="reporte_jugadores.php" class="<?= $paginaActiva === 'reporte' ? 'activo' : '' ?>">📊 Reporte</a>
        <?php if ((int) $usuarioSesion['id_rol'] === \App\Utils\Roles::ADMINISTRADOR): ?>
        <a href="gestion_usuarios.php" class="<?= $paginaActiva === 'usuarios' ? 'activo' : '' ?>">👥 Usuarios</a>
        <a href="gestion_avatares.php" class="<?= $paginaActiva === 'avatares' ? 'activo' : '' ?>">🎭 Avatares</a>
        <?php endif; ?>
        <a href="dashboard.php">🎯 Mi marcador</a>
        <a href="logout.php" class="salir">🚪 Cerrar sesión</a>
    </nav>
</aside>
