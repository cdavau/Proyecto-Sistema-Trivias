<?php

namespace App\Exceptions;

use Exception;

class AutenticacionException extends Exception
{
}
