<?php

namespace App\Exceptions;

use Exception;

/**
 * DatabaseException
 *
 * Excepción personalizada para separar los errores de base de datos
 * de otros errores del sistema (facilita el control de errores por tipo).
 */
class DatabaseException extends Exception
{
}
