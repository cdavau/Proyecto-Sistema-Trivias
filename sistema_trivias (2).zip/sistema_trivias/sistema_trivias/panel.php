<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Premios\PremioService;
use App\Preguntas\PreguntaService;
use App\Temas\TemaService;
use App\Usuarios\UsuarioService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ARMADOR, Roles::ADMINISTRADOR]);
$usuarioSesion = SesionUtil::usuarioActual();

$db = Database::obtenerInstancia();
$validador = new Validador();
$manejador = new ManejadorErroresArchivo();

$temaService = new TemaService($db, $validador, $manejador);
$premioService = new PremioService($db, $validador, $manejador);
$usuarioService = new UsuarioService($db, $validador, $manejador);

$totalTemas = count($temaService->listarTemas());
$totalNiveles = count($temaService->listarTemaNivel());
$totalPremios = count($premioService->listar());
$totalUsuarios = count($usuarioService->listar());

$paginaActiva = 'panel';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Panel de Administración — Trivias UTP</title>
<link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="contenido">
        <div class="encabezado">
            <div>
                <span class="eyebrow">🛠️ Panel de gestión</span>
                <h1 style="margin-top:10px;">Hola, <?= htmlspecialchars($usuarioSesion['nombre']) ?> 👋</h1>
            </div>
        </div>

        <div class="grid-cards">
            <div class="tarjeta">
                <div class="icono">📚</div>
                <h3><?= $totalTemas ?> temas</h3>
                <p><?= $totalNiveles ?> niveles configurados</p>
            </div>
            <div class="tarjeta">
                <div class="icono">🏆</div>
                <h3><?= $totalPremios ?> premios</h3>
                <p>Disponibles para ganar</p>
            </div>
            <div class="tarjeta">
                <div class="icono">👥</div>
                <h3><?= $totalUsuarios ?> usuarios</h3>
                <p>Registrados en el sistema</p>
            </div>
        </div>

        <h2 style="font-size:18px; margin-bottom:14px;">Ir a un módulo</h2>
        <div class="grid-cards">
            <a href="gestion_temas.php" class="card-link tarjeta">
                <div class="icono">📚</div>
                <h3>Temas y niveles</h3>
                <p>Crear y administrar PHP, JavaScript, Laravel y sus niveles.</p>
            </a>
            <a href="gestion_preguntas.php" class="card-link tarjeta">
                <div class="icono">❓</div>
                <h3>Preguntas</h3>
                <p>Crear preguntas de opción múltiple o verdadero/falso.</p>
            </a>
            <a href="gestion_premios.php" class="card-link tarjeta">
                <div class="icono">🏆</div>
                <h3>Premios</h3>
                <p>Crear premios con imagen y ponderación de puntos.</p>
            </a>
            <a href="reporte_jugadores.php" class="card-link tarjeta">
                <div class="icono">📊</div>
                <h3>Reporte de jugadores</h3>
                <p>Tiempos, estadísticas y exportación a Excel.</p>
            </a>
            <?php if ((int) $usuarioSesion['id_rol'] === Roles::ADMINISTRADOR): ?>
            <a href="gestion_usuarios.php" class="card-link tarjeta">
                <div class="icono">👥</div>
                <h3>Usuarios</h3>
                <p>Ver, activar/desactivar y cambiar roles de usuarios.</p>
            </a>
            <?php endif; ?>
        </div>
    </main>
</div>
</body>
</html>
