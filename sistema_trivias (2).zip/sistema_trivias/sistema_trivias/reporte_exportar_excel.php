<?php
require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Reportes\ReporteService;
use App\Utils\Roles;
use App\Utils\SesionUtil;

SesionUtil::requerirRol([Roles::ARMADOR, Roles::ADMINISTRADOR]);

$db = Database::obtenerInstancia();
$reporteService = new ReporteService($db);

$jugadores = $reporteService->obtenerReportePorJugador();
$totales = $reporteService->obtenerTotalesGenerales();
$distribucionNivel = $reporteService->obtenerDistribucionPorNivel();

function xmlSeguro(?string $texto): string
{
    return htmlspecialchars((string) $texto, ENT_XML1 | ENT_QUOTES, 'UTF-8');
}

function celdaTexto(?string $valor): string
{
    return '<Cell><Data ss:Type="String">' . xmlSeguro($valor ?? '') . '</Data></Cell>';
}

function celdaNumero($valor): string
{
    if ($valor === null || $valor === '') {
        return '<Cell></Cell>';
    }
    return '<Cell><Data ss:Type="Number">' . xmlSeguro((string) $valor) . '</Data></Cell>';
}

function filaEncabezado(array $columnas): string
{
    $html = '<Row ss:StyleID="Encabezado">';
    foreach ($columnas as $col) {
        $html .= celdaTexto($col);
    }
    return $html . '</Row>' . "\n";
}

$fechaGeneracion = date('d/m/Y H:i');

header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="reporte_jugadores_' . date('Y-m-d') . '.xls"');
header('Cache-Control: max-age=0');

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<?mso-application progid="Excel.Sheet"?>' . "\n";
echo '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"' . "\n";
echo ' xmlns:o="urn:schemas-microsoft-com:office:office"' . "\n";
echo ' xmlns:x="urn:schemas-microsoft-com:office:excel"' . "\n";
echo ' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' . "\n";

echo '<Styles>' . "\n";
echo '<Style ss:ID="Titulo"><Font ss:Bold="1" ss:Size="14"/></Style>' . "\n";
echo '<Style ss:ID="Encabezado"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#201A5C" ss:Pattern="Solid"/></Style>' . "\n";
echo '<Style ss:ID="Subtitulo"><Font ss:Bold="1" ss:Size="11"/></Style>' . "\n";
echo '</Styles>' . "\n";

// hoja 1: resumen general
echo '<Worksheet ss:Name="Resumen">' . "\n";
echo '<Table>' . "\n";
echo '<Row><Cell ss:StyleID="Titulo"><Data ss:Type="String">Reporte de jugadores — Trivias UTP</Data></Cell></Row>' . "\n";
echo '<Row><Cell><Data ss:Type="String">Generado: ' . xmlSeguro($fechaGeneracion) . '</Data></Cell></Row>' . "\n";
echo '<Row></Row>' . "\n";

echo '<Row><Cell ss:StyleID="Subtitulo"><Data ss:Type="String">Totales generales</Data></Cell></Row>' . "\n";
echo '<Row>' . celdaTexto('Jugadores registrados') . celdaNumero($totales['total_jugadores']) . '</Row>' . "\n";
echo '<Row>' . celdaTexto('Partidas jugadas en total') . celdaNumero($totales['total_partidas']) . '</Row>' . "\n";
echo '<Row>' . celdaTexto('Tiempo promedio de respuesta (s)') . celdaNumero($totales['tiempo_promedio_global']) . '</Row>' . "\n";
echo '<Row>' . celdaTexto('% de aciertos promedio del sistema') . celdaNumero($totales['porcentaje_aciertos_global']) . '</Row>' . "\n";
echo '<Row></Row>' . "\n";

echo '<Row><Cell ss:StyleID="Subtitulo"><Data ss:Type="String">Distribución de aprobados por nivel</Data></Cell></Row>' . "\n";
echo filaEncabezado(['Nivel', 'Total intentos', 'Total aprobados', '% aprobación']);
foreach ($distribucionNivel as $nivel) {
    $total = (int) $nivel['total_intentos'];
    $aprobados = (int) $nivel['total_aprobados'];
    $porcentaje = $total > 0 ? round(($aprobados / $total) * 100, 2) : 0;
    echo '<Row>'
        . celdaTexto($nivel['nombre_nivel'])
        . celdaNumero($total)
        . celdaNumero($aprobados)
        . celdaNumero($porcentaje)
        . '</Row>' . "\n";
}
echo '</Table>' . "\n";
echo '</Worksheet>' . "\n";

// hoja 2: detalle por jugador
echo '<Worksheet ss:Name="Detalle por jugador">' . "\n";
echo '<Table>' . "\n";
echo filaEncabezado([
    'ID', 'Nombre', 'Apodo', 'Correo', 'Estado',
    'Partidas jugadas', 'Tiempo promedio (s)', 'Total respuestas',
    'Respuestas correctas', '% Aciertos', 'Puntos totales',
]);

foreach ($jugadores as $j) {
    echo '<Row>'
        . celdaNumero($j['id_usuario'])
        . celdaTexto($j['nombre'])
        . celdaTexto($j['apodo'])
        . celdaTexto($j['correo'])
        . celdaTexto($j['estado'])
        . celdaNumero($j['partidas_jugadas'])
        . celdaNumero($j['tiempo_promedio_seg'])
        . celdaNumero($j['total_respuestas'])
        . celdaNumero($j['total_correctas'])
        . celdaNumero($j['porcentaje_aciertos'])
        . celdaNumero($j['puntos_totales'])
        . '</Row>' . "\n";
}

echo '</Table>' . "\n";
echo '</Worksheet>' . "\n";
echo '</Workbook>';
