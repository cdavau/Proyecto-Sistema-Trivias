<?php

namespace App\Utils;

use App\Interfaces\ValidadorInterface;
class Validador implements ValidadorInterface
{
    private array $errores = [];

    public function sanitizarTexto(string $valor): string
    {
        $valor = trim($valor);
        $valor = strip_tags($valor);
        $valor = htmlspecialchars($valor, ENT_QUOTES, 'UTF-8');

        return $valor;
    }

    public function validarCorreo(string $correo): ?string
    {
        $correo = trim(strtolower($correo));
        $correo = filter_var($correo, FILTER_SANITIZE_EMAIL);

        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            $this->errores[] = 'El correo electrónico no tiene un formato válido.';
            return null;
        }

        return $correo;
    }

   public function validarPassword(string $password): bool
    {
        $patron = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,12}$/';

        if (!preg_match($patron, $password)) {
            $this->errores[] = 'La contraseña debe tener entre 8 y 12 caracteres, incluyendo mayúscula, minúscula y número.';
            return false;
        }

        return true;
    }

    public function validarEntero(mixed $valor, int $min = 0, int $max = PHP_INT_MAX): ?int
    {
        $opciones = [
            'options' => [
                'min_range' => $min,
                'max_range' => $max,
            ],
        ];

        $resultado = filter_var($valor, FILTER_VALIDATE_INT, $opciones);

        if ($resultado === false) {
            $this->errores[] = "El valor '{$valor}' no es un número entero válido entre {$min} y {$max}.";
            return null;
        }

        return $resultado;
    }

    public function validarCedula(string $cedula): ?string
    {
        $limpio = strtoupper(trim($cedula));
        $limpio = $this->sanitizarTexto($limpio);

        $patron = '/^[A-Z0-9]+(-[A-Z0-9]+){1,3}$/';

        if (mb_strlen($limpio) < 5 || mb_strlen($limpio) > 20 || !preg_match($patron, $limpio)) {
            $this->errores[] = 'La cédula debe tener un formato válido, por ejemplo 8-123-4567.';
            return null;
        }

        return $limpio;
    }

    public function validarTextoObligatorio(string $valor, string $campo, int $min = 1, int $max = 255): ?string
    {
        $limpio = $this->sanitizarTexto($valor);
        $longitud = mb_strlen($limpio);

        if ($longitud < $min || $longitud > $max) {
            $this->errores[] = "El campo '{$campo}' debe tener entre {$min} y {$max} caracteres.";
            return null;
        }

        return $limpio;
    }
    public function validarEnLista(string $valor, array $opcionesValidas, string $campo): ?string
    {
        $valor = $this->sanitizarTexto($valor);

        if (!in_array($valor, $opcionesValidas, true)) {
            $this->errores[] = "El campo '{$campo}' contiene un valor no permitido.";
            return null;
        }

        return $valor;
    }

    public function obtenerErrores(): array
    {
        return $this->errores;
    }
    public function limpiarErrores(): void
    {
        $this->errores = [];
    }
}
