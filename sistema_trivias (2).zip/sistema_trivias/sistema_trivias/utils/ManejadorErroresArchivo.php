<?php

namespace App\Utils;

use App\Interfaces\ManejadorErroresInterface;

/**
 * ManejadorErroresArchivo
 *
 * Implementación concreta de ManejadorErroresInterface.
 * Registra los errores en un archivo de log (logs/errores.log).
 */
class ManejadorErroresArchivo implements ManejadorErroresInterface
{
    private string $rutaLog;

    public function __construct(string $rutaLog = __DIR__ . '/../logs/errores.log')
    {
        $this->rutaLog = $rutaLog;

        $directorio = dirname($this->rutaLog);
        if (!is_dir($directorio)) {
            mkdir($directorio, 0755, true);
        }
    }

    public function registrarError(string $mensaje, string $contexto = '', array $datosExtra = []): void
    {
        $fecha = date('Y-m-d H:i:s');
        $extra = !empty($datosExtra) ? ' | Extra: ' . json_encode($datosExtra, JSON_UNESCAPED_UNICODE) : '';

        $lineaLog = sprintf(
            "[%s] [%s] %s%s%s",
            $fecha,
            $contexto ?: 'GENERAL',
            $mensaje,
            $extra,
            PHP_EOL
        );

        error_log($lineaLog, 3, $this->rutaLog);
    }

    public function mensajeParaUsuario(string $mensajeInterno): string
    {
        // Nunca se expone el mensaje técnico real al usuario (recomendación OWASP)
        return 'Ha ocurrido un error inesperado. Por favor intenta nuevamente más tarde.';
    }
}
