<?php

namespace App\Utils;

/**
 * SelloIntegridad
 *
 * Calcula y verifica una "firma digital" (HMAC-SHA256) sobre los datos
 * de un registro crítico. Sirve para proteger los datos en reposo:
 * si alguien modifica el registro directamente en la base de datos,
 * la firma deja de coincidir y la manipulación queda en evidencia.
 */
class SelloIntegridad
{
    private static function clave(): string
    {
        $config = require __DIR__ . '/../config/config.php';
        return $config['clave_integridad'] ?? 'clave_por_defecto_insegura';
    }

    public static function calcular(array $datos): string
    {
        $cadena = implode('|', $datos);
        return hash_hmac('sha256', $cadena, self::clave());
    }

    public static function verificar(array $datos, string $firma): bool
    {
        return hash_equals(self::calcular($datos), $firma);
    }
}