<?php

namespace App\Utils;

/**
 * SesionUtil
 *
 * Maneja el inicio/cierre de sesión del usuario autenticado y el
 * control de acceso por rol (jugador, armador, administrador).
 */
class SesionUtil
{
    public static function iniciar(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public static function iniciarSesionUsuario(array $usuario): void
    {
        self::iniciar();
        $_SESSION['usuario'] = $usuario;
    }

    public static function estaAutenticado(): bool
    {
        self::iniciar();
        return isset($_SESSION['usuario']);
    }

    public static function usuarioActual(): ?array
    {
        self::iniciar();
        return $_SESSION['usuario'] ?? null;
    }

    public static function cerrarSesion(): void
    {
        self::iniciar();
        $_SESSION = [];
        session_destroy();
    }

    /**
     * Corta la ejecución si el usuario no está autenticado, o si su rol
     * no está dentro de los roles permitidos para esa página.
     *
     * Uso: SesionUtil::requerirRol([Roles::ADMINISTRADOR]);
     */
    public static function requerirRol(array $rolesPermitidos): void
    {
        self::iniciar();

        if (!self::estaAutenticado()) {
            header('Location: login.php');
            exit;
        }

        $idRolActual = $_SESSION['usuario']['id_rol'] ?? null;

        if (!in_array($idRolActual, $rolesPermitidos, true)) {
            http_response_code(403);
            echo 'No tienes permisos para acceder a esta página.';
            exit;
        }
    }
}
