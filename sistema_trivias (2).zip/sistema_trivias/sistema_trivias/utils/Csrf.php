<?php

namespace App\Utils;

/**
 * Csrf
 *
 * Genera y valida tokens anti-CSRF para proteger los formularios que
 * envían datos por POST. Impide que una petición forjada desde otro
 * origen o desde una herramienta externa (como Postman) sea aceptada,
 * ya que no incluiría el token válido guardado en la sesión.
 */
class Csrf
{
    private const CLAVE = 'csrf_token';
    private static function asegurarSesion(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }
    public static function token(): string
    {
        self::asegurarSesion();

        if (empty($_SESSION[self::CLAVE])) {
            $_SESSION[self::CLAVE] = bin2hex(random_bytes(32));
        }

        return $_SESSION[self::CLAVE];
    }

    public static function campo(): string
    {
        $token = htmlspecialchars(self::token(), ENT_QUOTES, 'UTF-8');
        return '<input type="hidden" name="' . self::CLAVE . '" value="' . $token . '">';
    }

    public static function validar(): void
    {
        self::asegurarSesion();

        $enviado  = $_POST[self::CLAVE] ?? '';
        $esperado = $_SESSION[self::CLAVE] ?? '';

        if (empty($esperado) || !hash_equals($esperado, $enviado)) {
            http_response_code(403);
            exit('Solicitud no válida (token CSRF incorrecto o ausente).');
        }
    }
}