<?php

namespace App\Utils;


class Roles
{
    public const JUGADOR = 1;
    public const ARMADOR = 2;
    public const ADMINISTRADOR = 3;

    public static function nombre(int $idRol): string
    {
        return match ($idRol) {
            self::JUGADOR => 'jugador',
            self::ARMADOR => 'armador',
            self::ADMINISTRADOR => 'administrador',
            default => 'desconocido',
        };
    }
}
