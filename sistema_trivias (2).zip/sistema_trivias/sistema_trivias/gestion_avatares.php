<?php

require_once __DIR__ . '/bootstrap.php';

use App\Avatares\AvatarService;
use App\Config\Database;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ADMINISTRADOR]);
$usuarioSesion = SesionUtil::usuarioActual();

$db = Database::obtenerInstancia();
$avatarService = new AvatarService($db, new Validador(), new ManejadorErroresArchivo());
$avatares = $avatarService->listar();

$paginaActiva = 'avatares';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestión de Avatares — Trivias UTP</title>
<link rel="stylesheet" href="assets/estilo.css">
<style>
    .avatar-preview { font-size: 22px; }
    .avatar-preview img { width: 28px; height: 28px; border-radius: 50%; object-fit: cover; vertical-align: middle; }
</style>
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="contenido">
        <div class="encabezado">
            <div>
                <span class="eyebrow">🎭 Gestión</span>
                <h1 style="margin-top:10px;">Avatares</h1>
            </div>
            <button type="button" class="btn-abrir-modal" onclick="abrirModalCrear()">➕ Nuevo avatar</button>
        </div>

        <?php if (isset($_GET['exito'])): ?>
            <p class="mensaje-exito">✅ Cambio aplicado correctamente.</p>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <p class="mensaje-error">⚠️ <?= htmlspecialchars($_GET['error']) ?></p>
        <?php endif; ?>

        <div class="tarjeta">
            <h3 style="margin-bottom:6px;">Catálogo de avatares (<?= count($avatares) ?>)</h3>
            <p style="color: var(--text-muted); font-size: 13px; margin-bottom: 14px;">
                Desactivar un avatar lo quita de la lista de selección de los jugadores, pero
                no borra el historial de quienes ya lo tienen puesto.
            </p>
            <table id="tabla-avatares" class="display" style="width:100%">
                <thead>
                <tr><th>ID</th><th>Vista previa</th><th>Nombre</th><th>Tipo</th><th>Valor</th><th>Estado</th><th>Acciones</th></tr>
                </thead>
                <tbody>
                <?php foreach ($avatares as $a): ?>
                <tr>
                    <td>#<?= $a['id_avatar'] ?></td>
                    <td class="avatar-preview">
                        <?php if ($a['tipo'] === 'imagen'): ?>
                            <img src="<?= htmlspecialchars($a['valor']) ?>" alt="">
                        <?php else: ?>
                            <?= $a['valor'] ?>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($a['nombre']) ?></td>
                    <td><?= htmlspecialchars($a['tipo']) ?></td>
                    <td><?= htmlspecialchars($a['valor']) ?></td>
                    <td><span class="badge <?= $a['activo'] ? 'activo' : 'inactivo' ?>"><?= $a['activo'] ? 'Activo' : 'Inactivo' ?></span></td>
                    <td>
                        <button type="button" class="accion-btn editar"
                            onclick='abrirModalEditar(<?= json_encode([
                                "id_avatar" => $a["id_avatar"],
                                "nombre" => $a["nombre"],
                                "tipo" => $a["tipo"],
                                "valor" => $a["valor"],
                            ], JSON_UNESCAPED_UNICODE) ?>)'>Editar</button>
                        <form action="procesar_toggle_avatar.php" method="POST" style="display:inline;">
                            <input type="hidden" name="id_avatar" value="<?= $a['id_avatar'] ?>">
                            <input type="hidden" name="nuevo_estado" value="<?= $a['activo'] ? '0' : '1' ?>">
                            <button type="submit" class="accion-link <?= $a['activo'] ? 'borrar' : 'editar' ?>" style="background:none;border:none;cursor:pointer;padding:0;font-family:inherit;">
                                <?= $a['activo'] ? 'Desactivar' : 'Activar' ?>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<div class="modal-overlay" id="modal-crear">
    <div class="modal-caja">
        <button type="button" class="modal-cerrar" onclick="cerrarModal('modal-crear')">✕</button>
        <span class="eyebrow">➕ Nuevo</span>
        <h3 style="margin: 12px 0 18px;">Crear avatar</h3>
        <form action="procesar_crear_avatar.php" method="POST">
            <?= \App\Utils\Csrf::campo() ?>
            <label for="c-nombre">Nombre</label>
            <input type="text" id="c-nombre" name="nombre" placeholder="Ej: Dragón" required minlength="2">

            <label for="c-tipo">Tipo</label>
            <select id="c-tipo" name="tipo" required>
                <option value="emoji">Emoji</option>
                <option value="imagen">Imagen (URL o ruta)</option>
            </select>

            <label for="c-valor">Valor (emoji o ruta de imagen)</label>
            <input type="text" id="c-valor" name="valor" placeholder="🐉 o uploads/avatares/dragon.png" required>

            <div class="modal-acciones">
                <button type="submit" class="buzzer" style="flex:1;">Crear avatar</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-overlay" id="modal-editar">
    <div class="modal-caja">
        <button type="button" class="modal-cerrar" onclick="cerrarModal('modal-editar')">✕</button>
        <span class="eyebrow">✏️ Editar</span>
        <h3 style="margin: 12px 0 18px;">Editar avatar</h3>
        <form action="procesar_editar_avatar.php" method="POST">
            <?= \App\Utils\Csrf::campo() ?>
            <input type="hidden" id="e-id" name="id_avatar">

            <label for="e-nombre">Nombre</label>
            <input type="text" id="e-nombre" name="nombre" required minlength="2">

            <label for="e-tipo">Tipo</label>
            <select id="e-tipo" name="tipo" required>
                <option value="emoji">Emoji</option>
                <option value="imagen">Imagen (URL o ruta)</option>
            </select>

            <label for="e-valor">Valor (emoji o ruta de imagen)</label>
            <input type="text" id="e-valor" name="valor" required>

            <div class="modal-acciones">
                <button type="submit" class="buzzer teal" style="flex:1;">Guardar cambios</button>
            </div>
        </form>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script>
    $(function () {
        $('#tabla-avatares').DataTable({
            language: {
                search: 'Buscar:',
                lengthMenu: 'Mostrar _MENU_ avatares',
                info: 'Mostrando _START_ a _END_ de _TOTAL_ avatares',
                infoEmpty: 'No hay avatares para mostrar',
                infoFiltered: '(filtrado de _MAX_ avatares en total)',
                zeroRecords: 'Ningún avatar coincide con la búsqueda',
                paginate: { previous: 'Anterior', next: 'Siguiente' }
            }
        });
    });

    function abrirModalCrear() {
        document.getElementById('modal-crear').classList.add('abierto');
    }

    function abrirModalEditar(avatar) {
        document.getElementById('e-id').value = avatar.id_avatar;
        document.getElementById('e-nombre').value = avatar.nombre;
        document.getElementById('e-tipo').value = avatar.tipo;
        document.getElementById('e-valor').value = avatar.valor;
        document.getElementById('modal-editar').classList.add('abierto');
    }

    function cerrarModal(id) {
        document.getElementById(id).classList.remove('abierto');
    }

    document.querySelectorAll('.modal-overlay').forEach(function (overlay) {
        overlay.addEventListener('click', function (evento) {
            if (evento.target === overlay) {
                overlay.classList.remove('abierto');
            }
        });
    });
</script>
</body>
</html>
