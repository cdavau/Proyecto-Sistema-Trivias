<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Premios\PremioService;
use App\Temas\TemaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ARMADOR, Roles::ADMINISTRADOR]);
$usuarioSesion = SesionUtil::usuarioActual();

$db = Database::obtenerInstancia();
$premioService = new PremioService($db, new Validador(), new ManejadorErroresArchivo());
$temaService = new TemaService($db, new Validador(), new ManejadorErroresArchivo());

$premios = $premioService->listar();
$temas = $temaService->listarTemas();

$paginaActiva = 'premios';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestión de Premios — Trivias UTP</title>
<link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="contenido">
        <div class="encabezado">
            <div>
                <span class="eyebrow">🏆 Gestión</span>
                <h1 style="margin-top:10px;">Premios</h1>
            </div>
        </div>

        <?php if (isset($_GET['error'])): ?>
            <p class="mensaje-error">⚠️ <?= htmlspecialchars($_GET['error']) ?></p>
        <?php endif; ?>
        <?php if (isset($_GET['exito'])): ?>
            <p class="mensaje-exito">✅ Premio creado correctamente.</p>
        <?php endif; ?>

        <div class="tarjeta" style="margin-bottom: 24px;">
            <h3 style="margin-bottom:12px;">➕ Nuevo premio</h3>
            <form action="procesar_crear_premio.php" method="POST">
                <?= \App\Utils\Csrf::campo() ?>
                <label for="nombre_premio">Nombre del premio</label>
                <input type="text" id="nombre_premio" name="nombre_premio" placeholder="Ej: Medalla PHP Avanzado" required>

                <label for="imagen">URL o ruta de la imagen</label>
                <input type="text" id="imagen" name="imagen" placeholder="imagenes/premios/medalla.png" required>

                <label for="ponderacion_puntos">Puntos que otorga</label>
                <input type="number" id="ponderacion_puntos" name="ponderacion_puntos" min="1" value="100" required>

                <label for="id_nivel">Nivel asociado</label>
                <select id="id_nivel" name="id_nivel">
                    <option value="">Ninguno</option>
                    <option value="1">Novato</option>
                    <option value="2">Intermedio</option>
                    <option value="3">Avanzado</option>
                </select>

                <label for="id_tema">Tema asociado</label>
                <select id="id_tema" name="id_tema">
                    <option value="">Ninguno</option>
                    <?php foreach ($temas as $t): ?>
                        <option value="<?= $t['id_tema'] ?>"><?= htmlspecialchars($t['nombre_tema']) ?></option>
                    <?php endforeach; ?>
                </select>

                <button type="submit" class="buzzer">Crear premio</button>
            </form>
        </div>

        <div class="tarjeta">
            <h3 style="margin-bottom:6px;">Premios existentes (<?= count($premios) ?>)</h3>
            <table id="tabla-premios" class="display" style="width:100%">
                <thead><tr><th>ID</th><th>Nombre</th><th>Puntos</th><th>Nivel</th><th>Tema</th></tr></thead>
                <tbody>
                <?php foreach ($premios as $p): ?>
                <tr>
                    <td>#<?= $p['id_premio'] ?></td>
                    <td><?= htmlspecialchars($p['nombre_premio']) ?></td>
                    <td><?= (int) $p['ponderacion_puntos'] ?></td>
                    <td><?= htmlspecialchars($p['nombre_nivel'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($p['nombre_tema'] ?? '—') ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script>
    $(function () {
        $('#tabla-premios').DataTable({
            language: {
                search: 'Buscar:',
                lengthMenu: 'Mostrar _MENU_ premios',
                info: 'Mostrando _START_ a _END_ de _TOTAL_ premios',
                infoEmpty: 'No hay premios para mostrar',
                infoFiltered: '(filtrado de _MAX_ premios en total)',
                zeroRecords: 'Ningún premio coincide con la búsqueda',
                paginate: { previous: 'Anterior', next: 'Siguiente' }
            }
        });
    });
</script>
</body>
</html>
