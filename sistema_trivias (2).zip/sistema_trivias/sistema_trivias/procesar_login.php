<?php

/**
 * procesar_login.php
 *
 * Recibe el POST del formulario login.php, autentica con AuthService,
 * y si es correcto, inicia sesión y redirige al dashboard.
 */

require_once __DIR__ . '/config/entorno.php';
require_once __DIR__ . '/interfaces/ManejadorErroresInterface.php';
require_once __DIR__ . '/interfaces/ValidadorInterface.php';
require_once __DIR__ . '/interfaces/AutenticacionInterface.php';
require_once __DIR__ . '/utils/ManejadorErroresArchivo.php';
require_once __DIR__ . '/utils/Validador.php';
require_once __DIR__ . '/utils/SesionUtil.php';
require_once __DIR__ . '/exceptions/DatabaseException.php';
require_once __DIR__ . '/exceptions/AutenticacionException.php';
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/auth/AuthService.php';
require_once __DIR__ . '/utils/Csrf.php';

use App\Auth\AuthService;
use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\SesionUtil;
use App\Utils\Validador;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

\App\Utils\Csrf::validar(); 



$correo   = $_POST['correo'] ?? '';
$password = $_POST['password'] ?? '';
$ip       = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

$db          = Database::obtenerInstancia();
$authService = new AuthService($db, new Validador(), new ManejadorErroresArchivo());

try {
    $usuario = $authService->autenticar($correo, $password, $ip);
    SesionUtil::iniciarSesionUsuario($usuario);

    if (!empty($_SESSION['qr_destino_tema_nivel'])) {
        $idTemaNivelQr = (int) $_SESSION['qr_destino_tema_nivel'];
        unset($_SESSION['qr_destino_tema_nivel']);
        header('Location: iniciar_partida.php?id_tema_nivel=' . $idTemaNivelQr);
        exit;
    }

    header('Location: dashboard.php');
    exit;

} catch (AutenticacionException $e) {
    header('Location: login.php?error=' . urlencode($e->getMessage()));
    exit;
}
