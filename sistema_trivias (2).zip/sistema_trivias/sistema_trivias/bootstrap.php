<?php

/**
 * bootstrap.php
 *
 * Carga todas las clases del sistema en el orden correcto.
 * Cualquier página nueva solo necesita: require_once __DIR__ . '/bootstrap.php';
 */

// Control global de errores (requisito #12) — ver config/entorno.php
require_once __DIR__ . '/config/entorno.php';

// Interfaces primero
require_once __DIR__ . '/interfaces/ManejadorErroresInterface.php';
require_once __DIR__ . '/interfaces/ValidadorInterface.php';
require_once __DIR__ . '/interfaces/AutenticacionInterface.php';
require_once __DIR__ . '/interfaces/UsuarioInterface.php';
require_once __DIR__ . '/interfaces/TemaInterface.php';
require_once __DIR__ . '/interfaces/PreguntaInterface.php';
require_once __DIR__ . '/interfaces/PremioInterface.php';
require_once __DIR__ . '/interfaces/EncuestaInterface.php';
require_once __DIR__ . '/interfaces/JuegoInterface.php';
require_once __DIR__ . '/interfaces/AvatarInterface.php';
require_once __DIR__ . '/interfaces/ReporteInterface.php';

// Excepciones
require_once __DIR__ . '/exceptions/DatabaseException.php';
require_once __DIR__ . '/exceptions/AutenticacionException.php';

// Utilidades
require_once __DIR__ . '/utils/ManejadorErroresArchivo.php';
require_once __DIR__ . '/utils/Validador.php';
require_once __DIR__ . '/utils/Roles.php';
require_once __DIR__ . '/utils/SesionUtil.php';
require_once __DIR__ . '/utils/Csrf.php';
require_once __DIR__ . '/utils/SelloIntegridad.php'; 

// Conexión
require_once __DIR__ . '/config/Database.php';

// Servicios
require_once __DIR__ . '/auth/AuthService.php';
require_once __DIR__ . '/usuarios/UsuarioService.php';
require_once __DIR__ . '/temas/TemaService.php';
require_once __DIR__ . '/preguntas/PreguntaService.php';
require_once __DIR__ . '/premios/PremioService.php';
require_once __DIR__ . '/encuestas/EncuestaService.php';
require_once __DIR__ . '/juego/JuegoService.php';
require_once __DIR__ . '/juego/RankingService.php';
require_once __DIR__ . '/avatares/AvatarService.php';
require_once __DIR__ . '/reportes/ReporteService.php';
