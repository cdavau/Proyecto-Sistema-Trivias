<?php

require_once __DIR__ . '/config/entorno.php';
require_once __DIR__ . '/utils/SesionUtil.php';

use App\Utils\SesionUtil;

SesionUtil::cerrarSesion();
header('Location: login.php');
exit;
