<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Encuestas\EncuestaService;
use App\Exceptions\AutenticacionException;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Validador;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: promocional.php');
    exit; 
} \App\Utils\Csrf::validar();

$idEncuesta = (int) ($_POST['id_encuesta'] ?? 0);
$nombreContacto = $_POST['nombre_contacto'] ?? null;
$respuestaTexto = $_POST['respuesta_texto'] ?? '';

$db = Database::obtenerInstancia();
$encuestaService = new EncuestaService($db, new Validador(), new ManejadorErroresArchivo());

try {
    $encuestaService->registrarRespuesta($idEncuesta, $nombreContacto ?: null, $respuestaTexto);
    header('Location: promocional.php?enviado=1');
    exit;

} catch (AutenticacionException $e) {
    header('Location: promocional.php?error=' . urlencode($e->getMessage()));
    exit;
}
