<?php require_once __DIR__ . '/utils/Csrf.php'; \App\Utils\Csrf::token(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trivias UTP — Crear Cuenta</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@600;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
    :root {
        --bg-deep: #15123c;
        --bg-deep-2: #201a5c;
        --magenta: #ff2e63;
        --yellow: #ffd23f;
        --teal: #08d9d6;
        --text-light: #f5f4ff;
        --text-muted: #a9a3d6;
    }

    * { box-sizing: border-box; }

    body {
        margin: 0;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: 'Inter', sans-serif;
        background:
            radial-gradient(circle at 85% 15%, rgba(8,217,214,0.22), transparent 40%),
            radial-gradient(circle at 10% 85%, rgba(255,46,99,0.22), transparent 40%),
            linear-gradient(160deg, var(--bg-deep) 0%, var(--bg-deep-2) 100%);
        overflow: hidden;
        position: relative;
        padding: 20px;
    }

    .decor {
        position: absolute;
        font-size: 42px;
        opacity: 0.12;
        color: var(--text-light);
        user-select: none;
        pointer-events: none;
    }
    .decor.d1 { top: 10%; right: 10%; transform: rotate(10deg); }
    .decor.d2 { bottom: 8%; right: 14%; font-size: 56px; transform: rotate(-10deg); }
    .decor.d3 { top: 14%; left: 10%; font-size: 46px; transform: rotate(-14deg); }
    .decor.d4 { bottom: 14%; left: 8%; font-size: 34px; transform: rotate(8deg); }

    .tarjeta {
        position: relative;
        background: rgba(255,255,255,0.04);
        backdrop-filter: blur(6px);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 28px;
        padding: 44px 38px 38px;
        width: 400px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.45);
    }

    .eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: linear-gradient(90deg, var(--teal), #4de8e5);
        color: #0c2d2c;
        font-family: 'Inter', sans-serif;
        font-weight: 700;
        font-size: 11px;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        padding: 6px 14px;
        border-radius: 999px;
        margin-bottom: 18px;
    }

    h1 {
        font-family: 'Baloo 2', sans-serif;
        font-weight: 800;
        font-size: 28px;
        color: var(--text-light);
        margin: 0 0 6px;
        line-height: 1.15;
    }

    .subtitulo {
        color: var(--text-muted);
        font-size: 14px;
        margin: 0 0 24px;
    }

    label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--yellow);
        margin-top: 16px;
        margin-bottom: 6px;
    }

    input {
        width: 100%;
        padding: 12px 14px;
        background: rgba(255,255,255,0.06);
        border: 1.5px solid rgba(255,255,255,0.12);
        border-radius: 12px;
        color: var(--text-light);
        font-family: 'Inter', sans-serif;
        font-size: 14px;
        transition: border-color 0.2s ease, background 0.2s ease;
    }

    input::placeholder { color: rgba(245,244,255,0.35); }

    input:focus {
        outline: none;
        border-color: var(--yellow);
        background: rgba(255,255,255,0.09);
    }

    .ayuda {
        font-size: 11.5px;
        color: var(--text-muted);
        margin-top: 5px;
    }

    .buzzer-wrap {
        display: flex;
        justify-content: center;
        margin-top: 28px;
    }

    .buzzer {
        appearance: none;
        border: none;
        width: 100%;
        padding: 16px;
        border-radius: 999px;
        font-family: 'Baloo 2', sans-serif;
        font-weight: 800;
        font-size: 17px;
        letter-spacing: 0.02em;
        color: #08302f;
        background: linear-gradient(180deg, var(--teal) 0%, #04b3b0 100%);
        box-shadow:
            0 6px 0 #037b79,
            0 12px 24px rgba(8, 217, 214, 0.35);
        cursor: pointer;
        transition: transform 0.08s ease, box-shadow 0.08s ease;
    }

    .buzzer:hover { filter: brightness(1.05); }

    .buzzer:active {
        transform: translateY(6px);
        box-shadow:
            0 0 0 #037b79,
            0 4px 10px rgba(8, 217, 214, 0.35);
    }

    @media (prefers-reduced-motion: reduce) {
        .buzzer { transition: none; }
    }

    .error {
        margin-top: 18px;
        background: rgba(255,46,99,0.12);
        border: 1px solid rgba(255,46,99,0.4);
        color: #ffb3c6;
        font-size: 13px;
        padding: 10px 14px;
        border-radius: 10px;
        text-align: center;
    }

    .pie {
        text-align: center;
        margin-top: 22px;
        font-size: 13px;
        color: var(--text-muted);
    }

    .pie a {
        color: var(--yellow);
        text-decoration: none;
        font-weight: 600;
    }

    .pie a:hover { text-decoration: underline; }
</style>
</head>
<body>
    <span class="decor d1">🏆</span>
    <span class="decor d2">❓</span>
    <span class="decor d3">🎯</span>
    <span class="decor d4">⚡</span>

    <div class="tarjeta">
        <span class="eyebrow">📝 Nuevo Jugador</span>
        <h1>Únete a la<br>partida</h1>
        <p class="subtitulo">Crea tu cuenta y empieza a subir de nivel en PHP, JavaScript y Laravel.</p>

        <form action="procesar_registro.php" method="POST">
            <?= \App\Utils\Csrf::campo() ?>
            <label for="nombre">Nombre completo</label>
            <input type="text" id="nombre" name="nombre" required minlength="3">

            <label for="apodo">Apodo (nickname)</label>
            <input type="text" id="apodo" name="apodo" required minlength="3">

            <label for="cedula">Cédula</label>
            <input type="text" id="cedula" name="cedula" placeholder="8-123-4567" required minlength="5" maxlength="20">

            <label for="correo">Correo</label>
            <input type="email" id="correo" name="correo" required>

            <label for="password">Contraseña</label>
            <input type="password" id="password" name="password" placeholder="••••••••" required minlength="8">
            <p class="ayuda">Mínimo 8 caracteres, máximo 12, con mayúscula, minúscula y número.</p>

            <div class="buzzer-wrap">
                <button type="submit" class="buzzer">🎮 CREAR CUENTA</button>
            </div>
        </form>

        <?php if (isset($_GET['error'])): ?>
            <p class="error">⚠️ <?= htmlspecialchars($_GET['error']) ?></p>
        <?php endif; ?>

        <p class="pie">¿Ya tienes cuenta? <a href="login.php">Inicia sesión →</a></p>
    </div>
</body>
</html>
