-- =========================================================
-- MIGRACIÓN: barra de progreso persistente (requisito #8)
-- Ejecutar solo si la base de datos YA existía antes de este cambio.
-- =========================================================

USE sistema_trivias;

ALTER TABLE usuario_progreso
    ADD COLUMN mejor_porcentaje TINYINT DEFAULT 0 AFTER estado;
