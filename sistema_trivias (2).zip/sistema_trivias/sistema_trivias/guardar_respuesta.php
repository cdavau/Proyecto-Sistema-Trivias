<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Juego\JuegoService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\SesionUtil;

SesionUtil::iniciar();
if (!SesionUtil::estaAutenticado() || !isset($_SESSION['partida_actual'])) {
    header('Location: jugar.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: responder_pregunta.php');
    exit;
} \App\Utils\Csrf::validar();


$idPregunta = (int) ($_POST['id_pregunta'] ?? 0);
$idOpcion = (int) ($_POST['id_opcion'] ?? 0);

$db = Database::obtenerInstancia();
$juegoService = new JuegoService($db, new ManejadorErroresArchivo());

$idPartidaJugador = $_SESSION['partida_actual']['id_partida_jugador'];

$tiempoInicio = $_SESSION['partida_actual']['tiempo_inicio_pregunta'] ?? microtime(true);
$tiempoRespuesta = round(microtime(true) - $tiempoInicio, 2);

$esCorrecta = $juegoService->registrarRespuesta($idPartidaJugador, $idPregunta, $idOpcion, $tiempoRespuesta);

if ($esCorrecta) {
    $_SESSION['partida_actual']['total_correctas']++;
}

$_SESSION['partida_actual']['indice']++;
$_SESSION['ultima_respuesta_correcta'] = $esCorrecta;

header('Location: responder_pregunta.php');
exit;
