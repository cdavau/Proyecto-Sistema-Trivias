<?php

// Carga preguntas de ejemplo en todos los niveles de tema_nivel, para que
// dejen de mostrar "Este nivel todavía no tiene preguntas cargadas".
// Usa PreguntaService::crear(), así que pasa por toda la validación normal.
// Se puede correr varias veces: si un nivel ya tiene preguntas, lo salta.
// Necesita que ya exista un usuario armador o administrador (crear_admin_prueba.php).

ini_set('display_errors', '1');
error_reporting(E_ALL);

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Preguntas\PreguntaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Validador;

header('Content-Type: text/plain; charset=utf-8');

$db = Database::obtenerInstancia();
$pdo = $db->obtenerConexion();
$stmt = $pdo->prepare(
    "SELECT id_usuario FROM usuario
     WHERE id_rol IN (2, 3)
     ORDER BY id_usuario ASC
     LIMIT 1"
);
$stmt->execute();
$creador = $stmt->fetch();

if (!$creador) {
    echo "❌ No hay ningún usuario armador o administrador todavía.\n";
    echo "Corre primero crear_admin_prueba.php y vuelve a intentar.\n";
    exit;
}

$idUsuarioCreador = (int) $creador['id_usuario'];

$preguntaService = new PreguntaService($db, new Validador(), new ManejadorErroresArchivo());
$banco = [

    'PHP Básico' => [
        ['enunciado' => '¿Con qué símbolo se inicia una variable en PHP?', 'tipo' => 'opcion_multiple',
            'opciones' => ['$', '#', '&', '@'], 'correcta' => 0],
        ['enunciado' => '¿Qué función se usa para imprimir texto en pantalla en PHP?', 'tipo' => 'opcion_multiple',
            'opciones' => ['echo', 'print_r()', 'console.log()', 'System.out.println()'], 'correcta' => 0],
        ['enunciado' => '¿Cuál operador se usa para comparar valor Y tipo en PHP?', 'tipo' => 'opcion_multiple',
            'opciones' => ['===', '==', '=', '<>'], 'correcta' => 0],
        ['enunciado' => '¿Qué extensión de archivo usan los scripts de PHP?', 'tipo' => 'opcion_multiple',
            'opciones' => ['.php', '.pht', '.phtml', '.pp'], 'correcta' => 0],
        ['enunciado' => 'En PHP, un arreglo asociativo puede usar texto como clave (índice).', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 0],
        ['enunciado' => 'PHP es un lenguaje que se ejecuta únicamente en el navegador del cliente.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 1],
    ],

    'PHP Intermedio (Bases de Datos)' => [
        ['enunciado' => '¿Qué extensión de PHP se recomienda para conectarse a bases de datos de forma moderna y segura?', 'tipo' => 'opcion_multiple',
            'opciones' => ['PDO', 'mysql_connect', 'ODBC clásico', 'cURL'], 'correcta' => 0],
        ['enunciado' => '¿Qué técnica evita la inyección SQL al construir consultas con datos del usuario?', 'tipo' => 'opcion_multiple',
            'opciones' => ['Prepared statements (consultas preparadas)', 'Concatenar el texto directamente', 'Usar mayúsculas en el SQL', 'Aumentar el timeout'], 'correcta' => 0],
        ['enunciado' => '¿Qué método de PDOStatement ejecuta una consulta preparada con sus parámetros?', 'tipo' => 'opcion_multiple',
            'opciones' => ['execute()', 'run()', 'send()', 'commit()'], 'correcta' => 0],
        ['enunciado' => '¿Qué función de PHP sirve para generar un hash seguro de una contraseña?', 'tipo' => 'opcion_multiple',
            'opciones' => ['password_hash()', 'md5()', 'base64_encode()', 'sha1()'], 'correcta' => 0],
        ['enunciado' => 'Con PDO, desactivar ATTR_EMULATE_PREPARES hace que las consultas preparadas se ejecuten de verdad en el motor de la base de datos.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 0],
        ['enunciado' => 'Guardar contraseñas en texto plano en la base de datos es una buena práctica de seguridad.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 1],
    ],

    'PHP Avanzado' => [
        ['enunciado' => '¿Qué principio de SOLID indica que una clase debe depender de abstracciones y no de implementaciones concretas?', 'tipo' => 'opcion_multiple',
            'opciones' => ['Inversión de dependencias (DIP)', 'Responsabilidad única (SRP)', 'Sustitución de Liskov (LSP)', 'Segregación de interfaces (ISP)'], 'correcta' => 0],
        ['enunciado' => '¿Qué patrón de diseño garantiza que una clase tenga una única instancia compartida en todo el sistema?', 'tipo' => 'opcion_multiple',
            'opciones' => ['Singleton', 'Factory', 'Observer', 'Decorator'], 'correcta' => 0],
        ['enunciado' => 'En PHP, ¿qué palabra clave se usa para declarar que una clase implementa un contrato (interfaz)?', 'tipo' => 'opcion_multiple',
            'opciones' => ['implements', 'extends', 'uses', 'inherits'], 'correcta' => 0],
        ['enunciado' => '¿Qué mecanismo permite que una clase reciba sus dependencias desde afuera en lugar de crearlas ella misma?', 'tipo' => 'opcion_multiple',
            'opciones' => ['Inyección de dependencias', 'Herencia múltiple', 'Variables globales', 'Recursividad'], 'correcta' => 0],
        ['enunciado' => 'Una interfaz en PHP puede contener implementación de métodos, igual que una clase abstracta.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 1],
        ['enunciado' => 'Aplicar el principio de responsabilidad única (SRP) ayuda a que una clase sea más fácil de mantener y probar.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 0],
    ],

    'JavaScript Básico' => [
        ['enunciado' => '¿Qué palabra clave declara una variable cuyo valor no se puede reasignar en JavaScript?', 'tipo' => 'opcion_multiple',
            'opciones' => ['const', 'var', 'let', 'static'], 'correcta' => 0],
        ['enunciado' => '¿Cuál de estos es un tipo de dato primitivo en JavaScript?', 'tipo' => 'opcion_multiple',
            'opciones' => ['boolean', 'array', 'object', 'function'], 'correcta' => 0],
        ['enunciado' => '¿Qué operador se usa para comparar igualdad estricta (valor y tipo) en JavaScript?', 'tipo' => 'opcion_multiple',
            'opciones' => ['===', '==', '=', '!='], 'correcta' => 0],
        ['enunciado' => '¿Qué método muestra un mensaje en la consola del navegador?', 'tipo' => 'opcion_multiple',
            'opciones' => ['console.log()', 'echo()', 'print()', 'alert.show()'], 'correcta' => 0],
        ['enunciado' => 'En JavaScript, "let" permite reasignar el valor de una variable después de declararla.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 0],
        ['enunciado' => 'JavaScript solo puede ejecutarse dentro de un navegador web.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 1],
    ],

    'JavaScript Intermedio' => [
        ['enunciado' => '¿Qué método del DOM selecciona el primer elemento que coincide con un selector CSS?', 'tipo' => 'opcion_multiple',
            'opciones' => ['document.querySelector()', 'document.getAll()', 'document.find()', 'document.select()'], 'correcta' => 0],
        ['enunciado' => '¿Qué método de array crea un nuevo arreglo transformando cada elemento?', 'tipo' => 'opcion_multiple',
            'opciones' => ['map()', 'forEach()', 'filter()', 'reduce()'], 'correcta' => 0],
        ['enunciado' => '¿Qué evento se dispara cuando el usuario hace clic sobre un elemento?', 'tipo' => 'opcion_multiple',
            'opciones' => ['click', 'change', 'submit', 'load'], 'correcta' => 0],
        ['enunciado' => '¿Qué método de array devuelve solo los elementos que cumplen una condición?', 'tipo' => 'opcion_multiple',
            'opciones' => ['filter()', 'map()', 'push()', 'sort()'], 'correcta' => 0],
        ['enunciado' => 'addEventListener() permite asociar más de un manejador de eventos al mismo elemento.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 0],
        ['enunciado' => 'JSON.parse() convierte un objeto de JavaScript en un texto JSON.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 1],
    ],

    'JavaScript Avanzado' => [
        ['enunciado' => '¿Qué es un "closure" en JavaScript?', 'tipo' => 'opcion_multiple',
            'opciones' => ['Una función que recuerda el ámbito en el que fue creada', 'Un tipo de bucle infinito', 'Un método para cerrar el navegador', 'Una forma de declarar constantes'], 'correcta' => 0],
        ['enunciado' => '¿Qué palabra clave se usa junto con "async" para esperar el resultado de una promesa?', 'tipo' => 'opcion_multiple',
            'opciones' => ['await', 'yield', 'defer', 'resolve'], 'correcta' => 0],
        ['enunciado' => '¿Qué método de Promise se ejecuta cuando todas las promesas de un arreglo se resuelven?', 'tipo' => 'opcion_multiple',
            'opciones' => ['Promise.all()', 'Promise.any()', 'Promise.race()', 'Promise.settle()'], 'correcta' => 0],
        ['enunciado' => '¿Qué operador permite acceder de forma segura a una propiedad que podría no existir, sin lanzar error?', 'tipo' => 'opcion_multiple',
            'opciones' => ['?. (optional chaining)', '!! (doble negación)', '?? (nullish coalescing) usado solo', '&& encadenado'], 'correcta' => 0],
        ['enunciado' => 'Una promesa (Promise) en JavaScript puede estar en más de un estado final a la vez.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 1],
        ['enunciado' => 'El "event loop" es el mecanismo que permite que JavaScript maneje operaciones asíncronas sin bloquear el hilo principal.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 0],
    ],

    'Laravel Intermedio' => [
        ['enunciado' => '¿En qué archivo se definen típicamente las rutas web de una aplicación Laravel?', 'tipo' => 'opcion_multiple',
            'opciones' => ['routes/web.php', 'app/routes.php', 'config/routes.php', 'public/routes.php'], 'correcta' => 0],
        ['enunciado' => '¿Qué comando de Artisan crea un nuevo controlador?', 'tipo' => 'opcion_multiple',
            'opciones' => ['php artisan make:controller', 'php artisan new:controller', 'php artisan create controller', 'php artisan controller:make'], 'correcta' => 0],
        ['enunciado' => '¿Qué componente de Laravel se usa para crear y versionar cambios en la estructura de la base de datos?', 'tipo' => 'opcion_multiple',
            'opciones' => ['Migraciones', 'Seeders', 'Facades', 'Middlewares'], 'correcta' => 0],
        ['enunciado' => '¿Qué motor de plantillas usa Laravel por defecto para las vistas?', 'tipo' => 'opcion_multiple',
            'opciones' => ['Blade', 'Twig', 'Smarty', 'Handlebars'], 'correcta' => 0],
        ['enunciado' => 'En Laravel, un controlador puede recibir un Request inyectado directamente como parámetro de su método.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 0],
        ['enunciado' => 'Las migraciones de Laravel solo permiten crear tablas, nunca modificarlas después.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 1],
    ],

    'Laravel Avanzado' => [
        ['enunciado' => '¿Qué método de Eloquent define una relación "uno a muchos"?', 'tipo' => 'opcion_multiple',
            'opciones' => ['hasMany()', 'belongsTo()', 'hasOne()', 'belongsToMany()'], 'correcta' => 0],
        ['enunciado' => '¿Qué componente de Laravel intercepta las peticiones HTTP antes o después de llegar al controlador?', 'tipo' => 'opcion_multiple',
            'opciones' => ['Middleware', 'Service Provider', 'Facade', 'Observer'], 'correcta' => 0],
        ['enunciado' => '¿Dónde se registran normalmente los "bindings" del contenedor de servicios de Laravel?', 'tipo' => 'opcion_multiple',
            'opciones' => ['En un Service Provider', 'En el archivo .env', 'En routes/web.php', 'En un Middleware'], 'correcta' => 0],
        ['enunciado' => '¿Qué técnica de Eloquent evita el problema de N+1 consultas al cargar relaciones?', 'tipo' => 'opcion_multiple',
            'opciones' => ['Eager loading (with())', 'Lazy loading únicamente', 'Caché de vistas', 'Colas (queues)'], 'correcta' => 0],
        ['enunciado' => 'Un Service Provider en Laravel puede registrar bindings en el contenedor y ejecutar lógica en el arranque (boot) de la app.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 0],
        ['enunciado' => 'Las políticas (Policies) de Laravel se usan para centralizar reglas de autorización sobre un modelo.', 'tipo' => 'verdadero_falso',
            'opciones' => ['Verdadero', 'Falso'], 'correcta' => 0],
    ],
];

// insertar, saltando los niveles que ya tengan preguntas
$stmtIdTemaNivel = $pdo->prepare('SELECT id_tema_nivel FROM tema_nivel WHERE nombre_especifico = :nombre');
$stmtContarPreguntas = $pdo->prepare('SELECT COUNT(*) AS total FROM pregunta WHERE id_tema_nivel = :id_tema_nivel');

$resumen = [];

foreach ($banco as $nombreEspecifico => $preguntas) {

    $stmtIdTemaNivel->execute(['nombre' => $nombreEspecifico]);
    $filaTemaNivel = $stmtIdTemaNivel->fetch();

    if (!$filaTemaNivel) {
        $resumen[] = "⚠️  No existe el nivel '{$nombreEspecifico}' en tema_nivel — se omite.";
        continue;
    }

    $idTemaNivel = (int) $filaTemaNivel['id_tema_nivel'];

    $stmtContarPreguntas->execute(['id_tema_nivel' => $idTemaNivel]);
    $totalExistente = (int) $stmtContarPreguntas->fetch()['total'];

    if ($totalExistente > 0) {
        $resumen[] = "↷ '{$nombreEspecifico}' ya tiene {$totalExistente} pregunta(s) — se omite.";
        continue;
    }

    $creadas = 0;
    foreach ($preguntas as $p) {
        $opciones = [];
        foreach ($p['opciones'] as $indice => $texto) {
            $opciones[] = [
                'texto' => $texto,
                'es_correcta' => $indice === $p['correcta'],
            ];
        }

        $preguntaService->crear($idTemaNivel, $p['enunciado'], $p['tipo'], $idUsuarioCreador, $opciones);
        $creadas++;
    }

    $resumen[] = "✅ '{$nombreEspecifico}': {$creadas} preguntas creadas.";
}

echo "=== Resultado de la siembra de preguntas ===\n\n";
echo implode("\n", $resumen);
echo "\n\nListo. Recarga jugar.php para ver los niveles con preguntas disponibles.\n";
