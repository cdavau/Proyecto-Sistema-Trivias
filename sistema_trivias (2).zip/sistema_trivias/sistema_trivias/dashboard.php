<?php
require_once __DIR__ . '/config/entorno.php';
require_once __DIR__ . '/utils/SesionUtil.php';
require_once __DIR__ . '/utils/Roles.php';
require_once __DIR__ . '/interfaces/ManejadorErroresInterface.php';
require_once __DIR__ . '/interfaces/ValidadorInterface.php';
require_once __DIR__ . '/interfaces/UsuarioInterface.php';
require_once __DIR__ . '/utils/ManejadorErroresArchivo.php';
require_once __DIR__ . '/utils/Validador.php';
require_once __DIR__ . '/exceptions/DatabaseException.php';
require_once __DIR__ . '/exceptions/AutenticacionException.php';
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/usuarios/UsuarioService.php';

use App\Config\Database;
use App\Usuarios\UsuarioService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::iniciar();

if (!SesionUtil::estaAutenticado()) {
    header('Location: login.php');
    exit;
}

$sesion = SesionUtil::usuarioActual();

$db             = Database::obtenerInstancia();
$usuarioService = new UsuarioService($db, new Validador(), new ManejadorErroresArchivo());
$usuario        = $usuarioService->obtenerPorId((int) $sesion['id_usuario']);

$nombreRol = Roles::nombre((int) $usuario['id_rol']);
$puntos    = (int) $usuario['puntos_totales'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Marcador — Sistema de Trivias</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@600;800&family=Inter:wght@400;500;600;700&family=Space+Mono:wght@700&display=swap" rel="stylesheet">
<style>
    :root {
        --bg-deep: #15123c;
        --bg-deep-2: #201a5c;
        --magenta: #ff2e63;
        --yellow: #ffd23f;
        --teal: #08d9d6;
        --text-light: #f5f4ff;
        --text-muted: #a9a3d6;
    }

    * { box-sizing: border-box; }

    body {
        margin: 0;
        min-height: 100vh;
        font-family: 'Inter', sans-serif;
        background:
            radial-gradient(circle at 20% 10%, rgba(255,210,63,0.15), transparent 40%),
            radial-gradient(circle at 80% 90%, rgba(255,46,99,0.2), transparent 40%),
            linear-gradient(160deg, var(--bg-deep) 0%, var(--bg-deep-2) 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }

    .marcador {
        background: rgba(255,255,255,0.04);
        backdrop-filter: blur(6px);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 28px;
        padding: 40px;
        width: 440px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.45);
    }

    .eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: linear-gradient(90deg, var(--magenta), #ff6b9d);
        color: #fff;
        font-weight: 700;
        font-size: 11px;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        padding: 6px 14px;
        border-radius: 999px;
        margin-bottom: 16px;
    }

    h1 {
        font-family: 'Baloo 2', sans-serif;
        font-weight: 800;
        font-size: 26px;
        color: var(--text-light);
        margin: 0 0 24px;
    }

    .fila {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 0;
        border-bottom: 1px solid rgba(255,255,255,0.08);
    }
    .fila:last-of-type { border-bottom: none; }

    .fila .etiqueta {
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-muted);
    }

    .fila .valor {
        font-family: 'Inter', sans-serif;
        font-weight: 700;
        font-size: 15px;
        color: var(--text-light);
    }

    .badge-rol {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 999px;
        background: var(--teal);
        color: #08302f;
        font-weight: 700;
        font-size: 12px;
        text-transform: capitalize;
    }

    .puntos-caja {
        margin-top: 20px;
        text-align: center;
        background: rgba(0,0,0,0.35);
        border: 1px solid rgba(255,210,63,0.3);
        border-radius: 16px;
        padding: 20px;
    }

    .puntos-caja .etiqueta {
        font-size: 11px;
        color: var(--yellow);
        text-transform: uppercase;
        letter-spacing: 0.1em;
        margin-bottom: 6px;
    }

    .puntos-caja .numero {
        font-family: 'Space Mono', monospace;
        font-weight: 700;
        font-size: 48px;
        color: var(--yellow);
        text-shadow: 0 0 20px rgba(255,210,63,0.5);
    }

    .avatar-marcador {
        width: 64px; height: 64px; border-radius: 50%; margin: 0 auto 14px;
        background: rgba(255,255,255,0.08); display: flex; align-items: center; justify-content: center;
        font-size: 30px; overflow: hidden; border: 2px solid rgba(255,255,255,0.15);
    }
    .avatar-marcador img { width: 100%; height: 100%; object-fit: cover; }

    .salir {
        display: block;
        text-align: center;
        margin-top: 26px;
        color: var(--magenta);
        text-decoration: none;
        font-weight: 600;
        font-size: 14px;
    }
    .salir:hover { text-decoration: underline; }
</style>
</head>
<body>
    <div class="marcador">
        <span class="eyebrow">🏆 Tu Marcador</span>

        <div class="avatar-marcador">
            <?php if (!empty($usuario['avatar']) && str_starts_with($usuario['avatar'], 'uploads/')): ?>
                <img src="<?= htmlspecialchars($usuario['avatar']) ?>" alt="Avatar">
            <?php else: ?>
                <?= $usuario['avatar'] ?: '👤' ?>
            <?php endif; ?>
        </div>

        <h1>¡Bienvenido, <?= htmlspecialchars($usuario['nombre']) ?>! 👋</h1>

        <div class="fila">
            <span class="etiqueta">Apodo</span>
            <span class="valor">@<?= htmlspecialchars($usuario['apodo']) ?></span>
        </div>
        <div class="fila">
            <span class="etiqueta">Rol</span>
            <span class="badge-rol"><?= htmlspecialchars($nombreRol) ?></span>
        </div>
        <div class="fila">
            <span class="etiqueta">ID Jugador</span>
            <span class="valor">#<?= (int) $usuario['id_usuario'] ?></span>
        </div>

        <div class="puntos-caja">
            <div class="etiqueta">Puntos totales</div>
            <div class="numero"><?= str_pad((string) $puntos, 3, '0', STR_PAD_LEFT) ?></div>
        </div>

        <a href="jugar.php" style="display:block; text-align:center; margin-top:18px; background: linear-gradient(180deg, var(--teal), #04b3b0); color:#08302f; text-decoration:none; padding:14px; border-radius:999px; font-family:'Baloo 2',sans-serif; font-weight:800; font-size:16px; box-shadow: 0 5px 0 #037b79;">
            🎮 Ir a jugar
        </a>

        <div style="display:flex; gap:10px; margin-top:12px;">
            <a href="avatar.php" style="flex:1; text-align:center; background: rgba(255,255,255,0.08); color: var(--text-light); text-decoration:none; padding:11px; border-radius:999px; font-weight:600; font-size:13px;">
                🎭 Mi avatar
            </a>
            <a href="ranking.php" style="flex:1; text-align:center; background: rgba(255,255,255,0.08); color: var(--text-light); text-decoration:none; padding:11px; border-radius:999px; font-weight:600; font-size:13px;">
                📊 Ranking
            </a>
        </div>

        <a class="salir" href="logout.php">🚪 Cerrar sesión</a>

        <?php if ((int) $usuario['id_rol'] !== \App\Utils\Roles::JUGADOR): ?>
            <a href="panel.php" style="display:block; text-align:center; margin-top:12px; color: var(--teal); text-decoration:none; font-weight:600; font-size:14px;">
                🛠️ Ir al panel de administración
            </a>
        <?php endif; ?>
    </div>
</body>
</html>
