-- =========================================================
-- MIGRACIÓN: agregar campo "cédula" a usuario
-- Ejecutar solo si la base de datos YA existía antes de este cambio
-- (si vas a crear la BD desde cero, usa sistema_trivias_bd.sql, que
-- ya incluye esta columna, y no necesitas correr este archivo).
-- =========================================================

USE sistema_trivias;

ALTER TABLE usuario
    ADD COLUMN cedula VARCHAR(20) NOT NULL DEFAULT '' AFTER apodo;

UPDATE usuario SET cedula = CONCAT('PENDIENTE-', id_usuario) WHERE cedula = '';

ALTER TABLE usuario
    ADD CONSTRAINT uq_usuario_cedula UNIQUE (cedula);
