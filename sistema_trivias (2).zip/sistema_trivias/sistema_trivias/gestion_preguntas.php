<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Preguntas\PreguntaService;
use App\Temas\TemaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ARMADOR, Roles::ADMINISTRADOR]);
$usuarioSesion = SesionUtil::usuarioActual();

$db = Database::obtenerInstancia();
$temaService = new TemaService($db, new Validador(), new ManejadorErroresArchivo());
$preguntaService = new PreguntaService($db, new Validador(), new ManejadorErroresArchivo());

$nivelesTema = $temaService->listarTemaNivel();

$idTemaNivelSeleccionado = (int) ($_GET['id_tema_nivel'] ?? ($nivelesTema[0]['id_tema_nivel'] ?? 0));
$preguntas = $idTemaNivelSeleccionado ? $preguntaService->listarPorTemaNivel($idTemaNivelSeleccionado) : [];

$paginaActiva = 'preguntas';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestión de Preguntas — Trivias UTP</title>
<link rel="stylesheet" href="assets/estilo.css">
<style>
    .campo-opciones { display: none; }
    .campo-opciones.visible { display: block; }
</style>
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="contenido">
        <div class="encabezado">
            <div>
                <span class="eyebrow">❓ Gestión</span>
                <h1 style="margin-top:10px;">Preguntas</h1>
            </div>
        </div>

        <?php if (isset($_GET['error'])): ?>
            <p class="mensaje-error">⚠️ <?= htmlspecialchars($_GET['error']) ?></p>
        <?php endif; ?>
        <?php if (isset($_GET['exito'])): ?>
            <p class="mensaje-exito">✅ <?= $_GET['exito'] === 'eliminada' ? 'Pregunta eliminada correctamente.' : 'Pregunta creada correctamente.' ?></p>
        <?php endif; ?>

        <div class="tarjeta" style="margin-bottom: 24px;">
            <h3 style="margin-bottom:12px;">➕ Nueva pregunta</h3>
            <form action="procesar_crear_pregunta.php" method="POST" id="form-pregunta">
                <?= \App\Utils\Csrf::campo() ?>
                <input type="hidden" name="id_usuario_creador" value="<?= (int) $usuarioSesion['id_usuario'] ?>">

                <label for="id_tema_nivel">Tema y nivel</label>
                <select id="id_tema_nivel" name="id_tema_nivel" required>
                    <?php foreach ($nivelesTema as $n): ?>
                        <option value="<?= $n['id_tema_nivel'] ?>" <?= $n['id_tema_nivel'] == $idTemaNivelSeleccionado ? 'selected' : '' ?>>
                            <?= htmlspecialchars($n['nombre_especifico']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="tipo_pregunta">Tipo de pregunta</label>
                <select id="tipo_pregunta" name="tipo_pregunta" onchange="mostrarCampos()">
                    <option value="opcion_multiple">Opción múltiple</option>
                    <option value="verdadero_falso">Verdadero / Falso</option>
                </select>

                <label for="enunciado">Enunciado</label>
                <textarea id="enunciado" name="enunciado" rows="2" placeholder="Ej: ¿Qué función convierte un string en entero en PHP?" required></textarea>

                <!-- Opción múltiple: 4 opciones de texto -->
                <div id="campos-multiple" class="campo-opciones visible">
                    <label>Opciones (marca la correcta)</label>
                    <?php for ($i = 0; $i < 4; $i++): ?>
                    <div style="display:flex; gap:8px; align-items:center; margin-bottom:6px;">
                        <input type="radio" name="opcion_correcta" value="<?= $i ?>" <?= $i === 0 ? 'checked' : '' ?>>
                        <input type="text" name="opcion_texto[]" placeholder="Opción <?= $i + 1 ?>" style="margin:0;">
                    </div>
                    <?php endfor; ?>
                </div>

                <!-- Verdadero/Falso -->
                <div id="campos-vf" class="campo-opciones">
                    <label>Respuesta correcta</label>
                    <select name="respuesta_vf">
                        <option value="verdadero">Verdadero</option>
                        <option value="falso">Falso</option>
                    </select>
                </div>

                <button type="submit" class="buzzer">Crear pregunta</button>
            </form>
        </div>

        <div class="tarjeta">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 10px;">
                <h3>Preguntas de este nivel</h3>
                <form method="GET" style="margin:0;">
                    <?= \App\Utils\Csrf::campo() ?>
                    <select name="id_tema_nivel" onchange="this.form.submit()" style="width:auto;">
                        <?php foreach ($nivelesTema as $n): ?>
                            <option value="<?= $n['id_tema_nivel'] ?>" <?= $n['id_tema_nivel'] == $idTemaNivelSeleccionado ? 'selected' : '' ?>>
                                <?= htmlspecialchars($n['nombre_especifico']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>

            <?php if (empty($preguntas)): ?>
                <p style="color: var(--text-muted); font-size: 13px;">Todavía no hay preguntas para este nivel.</p>
            <?php endif; ?>

            <?php foreach ($preguntas as $p): ?>
                <div style="border-bottom: 1px solid rgba(255,255,255,0.08); padding: 14px 0;">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px;">
                        <div>
                            <strong><?= htmlspecialchars($p['enunciado']) ?></strong>
                            <span style="color: var(--text-muted); font-size: 12px;"> (<?= $p['tipo_pregunta'] === 'opcion_multiple' ? 'Opción múltiple' : 'Verdadero/Falso' ?>)</span>
                        </div>
                        <form action="procesar_eliminar_pregunta.php" method="POST" onsubmit="return confirm('¿Eliminar esta pregunta? Esta acción no se puede deshacer.');" style="margin:0; flex-shrink:0;">
                            <?= \App\Utils\Csrf::campo() ?>
                            <input type="hidden" name="id_pregunta" value="<?= (int) $p['id_pregunta'] ?>">
                            <input type="hidden" name="id_tema_nivel" value="<?= (int) $idTemaNivelSeleccionado ?>">
                            <button type="submit" class="buzzer eliminar">🗑️ Eliminar</button>
                        </form>
                    </div>
                    <ul style="margin: 8px 0 0; padding-left: 18px; font-size: 13px; color: var(--text-muted);">
                        <?php foreach ($p['opciones'] as $o): ?>
                            <li><?= htmlspecialchars($o['texto_opcion']) ?> <?php if ($o['es_correcta']): ?><span class="badge correcta">correcta</span><?php endif; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endforeach; ?>
        </div>
    </main>
</div>

<script>
function mostrarCampos() {
    const tipo = document.getElementById('tipo_pregunta').value;
    document.getElementById('campos-multiple').classList.toggle('visible', tipo === 'opcion_multiple');
    document.getElementById('campos-vf').classList.toggle('visible', tipo === 'verdadero_falso');
}
</script>
</body>
</html>
