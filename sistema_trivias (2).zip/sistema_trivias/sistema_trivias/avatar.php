<?php

require_once __DIR__ . '/bootstrap.php';

use App\Avatares\AvatarService;
use App\Config\Database;
use App\Usuarios\UsuarioService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::iniciar();
if (!SesionUtil::estaAutenticado()) {
    header('Location: login.php');
    exit;
}

$usuarioSesion = SesionUtil::usuarioActual();
$db = Database::obtenerInstancia();
$usuarioService = new UsuarioService($db, new Validador(), new ManejadorErroresArchivo());
$avatarService = new AvatarService($db, new Validador(), new ManejadorErroresArchivo());
$usuario = $usuarioService->obtenerPorId((int) $usuarioSesion['id_usuario']);

// Solo se ofrecen los avatares que el administrador dejó "activos" en el catálogo.
$avataresPreestablecidos = $avatarService->listarActivos();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mi Avatar — Trivias UTP</title>
<link rel="stylesheet" href="assets/estilo.css">
<style>
    body { display: flex; align-items: center; justify-content: center; padding: 20px; }
    .tarjeta-avatar {
        background: rgba(255,255,255,0.04);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 24px;
        padding: 36px;
        width: 440px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.4);
    }
    .avatar-actual {
        width: 90px; height: 90px; border-radius: 50%; margin: 0 auto 18px;
        background: rgba(255,255,255,0.08); display: flex; align-items: center; justify-content: center;
        font-size: 42px; overflow: hidden; border: 2px solid rgba(255,255,255,0.15);
    }
    .avatar-actual img { width: 100%; height: 100%; object-fit: cover; }

    .grid-emojis {
        display: grid; grid-template-columns: repeat(6, 1fr); gap: 8px;
        margin: 16px 0 22px;
    }
    .grid-emojis button {
        appearance: none; border: 1.5px solid rgba(255,255,255,0.12);
        background: rgba(255,255,255,0.05); border-radius: 12px;
        font-size: 24px; padding: 10px 0; cursor: pointer;
    }
    .grid-emojis button:hover { border-color: var(--teal); background: rgba(8,217,214,0.1); }
    .grid-emojis button.seleccionado { border-color: var(--yellow); background: rgba(255,210,63,0.15); }

    .separador { text-align: center; color: var(--text-muted); font-size: 12px; margin: 18px 0; text-transform: uppercase; letter-spacing: 0.05em; }

    .volver { display: block; text-align: center; margin-top: 20px; color: var(--text-muted); font-size: 13px; text-decoration: none; }
</style>
</head>
<body>
    <div class="tarjeta-avatar">
        <span class="eyebrow">🎭 Personalizar</span>
        <h1 style="margin: 14px 0 6px; font-size: 22px;">Elige tu avatar</h1>
        <p style="color: var(--text-muted); font-size: 13px; margin-bottom: 20px;">Este es el avatar que verán los demás jugadores en el ranking.</p>

        <div class="avatar-actual">
            <?php if (!empty($usuario['avatar']) && str_starts_with($usuario['avatar'], 'uploads/')): ?>
                <img src="<?= htmlspecialchars($usuario['avatar']) ?>" alt="Avatar actual">
            <?php else: ?>
                <?= $usuario['avatar'] ?: '👤' ?>
            <?php endif; ?>
        </div>

  
        <form action="procesar_avatar.php" method="POST" id="form-emoji">
            <?= \App\Utils\Csrf::campo() ?>
            <div class="grid-emojis">
                <?php foreach ($avataresPreestablecidos as $av): ?>
                    <?php $valorAvatar = $av['tipo'] === 'imagen' ? $av['valor'] : $av['valor']; ?>
                    <button type="submit" name="avatar_emoji" value="<?= htmlspecialchars($valorAvatar) ?>"
                        title="<?= htmlspecialchars($av['nombre']) ?>"
                        class="<?= $usuario['avatar'] === $valorAvatar ? 'seleccionado' : '' ?>">
                        <?php if ($av['tipo'] === 'imagen'): ?>
                            <img src="<?= htmlspecialchars($av['valor']) ?>" alt="<?= htmlspecialchars($av['nombre']) ?>" style="width:26px;height:26px;border-radius:50%;object-fit:cover;">
                        <?php else: ?>
                            <?= $av['valor'] ?>
                        <?php endif; ?>
                    </button>
                <?php endforeach; ?>
                <?php if (empty($avataresPreestablecidos)): ?>
                    <p style="grid-column: 1 / -1; color: var(--text-muted); font-size: 12.5px;">
                        El administrador aún no ha activado avatares preestablecidos.
                    </p>
                <?php endif; ?>
            </div>
        </form>

        <div class="separador">— o sube tu propia foto —</div>

        <form action="procesar_avatar.php" method="POST" enctype="multipart/form-data">
            <?= \App\Utils\Csrf::campo() ?>
            <input type="file" name="foto_avatar" accept="image/png, image/jpeg, image/webp" required>
            <button type="submit" class="buzzer teal" style="width:100%;">📤 Subir foto</button>
        </form>

        <?php if (isset($_GET['error'])): ?>
            <p class="mensaje-error" style="margin-top:16px;">⚠️ <?= htmlspecialchars($_GET['error']) ?></p>
        <?php endif; ?>

        <a href="dashboard.php" class="volver">← Volver a mi marcador</a>
    </div>
</body>
</html>
