<?php



require_once __DIR__ . '/config/entorno.php';

require_once __DIR__ . '/interfaces/ManejadorErroresInterface.php';
require_once __DIR__ . '/interfaces/ValidadorInterface.php';
require_once __DIR__ . '/interfaces/AutenticacionInterface.php';
require_once __DIR__ . '/utils/ManejadorErroresArchivo.php';
require_once __DIR__ . '/utils/Validador.php';
require_once __DIR__ . '/exceptions/DatabaseException.php';
require_once __DIR__ . '/exceptions/AutenticacionException.php';
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/auth/AuthService.php';

use App\Auth\AuthService;
use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Validador;

header('Content-Type: text/utf-8; charset=utf-8');
header('Content-Type: text/plain; charset=utf-8');

$correoPrueba   = 'david@trivias.com';
$passwordPrueba = 'Trivias2026'; 

$db          = Database::obtenerInstancia();
$validador   = new Validador();
$manejador   = new ManejadorErroresArchivo();
$authService = new AuthService($db, $validador, $manejador);

$ipSimulada = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

try {
    $usuario = $authService->autenticar($correoPrueba, $passwordPrueba, $ipSimulada);

    echo "✅ LOGIN EXITOSO\n\n";
    echo "ID Usuario: {$usuario['id_usuario']}\n";
    echo "Nombre:     {$usuario['nombre']}\n";
    echo "Apodo:      {$usuario['apodo']}\n";
    echo "Rol:        {$usuario['id_rol']}\n";

} catch (AutenticacionException $e) {
    echo "❌ LOGIN FALLIDO\n\n";
    echo "Motivo: " . $e->getMessage() . "\n";
}

echo "\n--- Revisa la tabla 'intento_login' en phpMyAdmin para ver el registro con IP y fecha ---\n";
