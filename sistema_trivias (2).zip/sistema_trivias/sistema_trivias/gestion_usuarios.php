<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Usuarios\UsuarioService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ADMINISTRADOR]);
$usuarioSesion = SesionUtil::usuarioActual();

$db = Database::obtenerInstancia();
$usuarioService = new UsuarioService($db, new Validador(), new ManejadorErroresArchivo());
$usuarios = $usuarioService->listar();

$paginaActiva = 'usuarios';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestión de Usuarios — Trivias UTP</title>
<link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="contenido">
        <div class="encabezado">
            <div>
                <span class="eyebrow">👥 Gestión</span>
                <h1 style="margin-top:10px;">Usuarios</h1>
            </div>
            <button type="button" class="btn-abrir-modal" onclick="abrirModalCrear()">➕ Nuevo usuario</button>
        </div>

        <?php if (isset($_GET['exito'])): ?>
            <p class="mensaje-exito">✅ Cambio aplicado correctamente.</p>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <p class="mensaje-error">⚠️ <?= htmlspecialchars($_GET['error']) ?></p>
        <?php endif; ?>

        <div class="tarjeta">
            <h3 style="margin-bottom:6px;">Todos los usuarios (<?= count($usuarios) ?>)</h3>
            <table id="tabla-usuarios" class="display" style="width:100%">
                <thead>
                <tr><th>ID</th><th>Nombre</th><th>Apodo</th><th>Cédula</th><th>Correo</th><th>Rol</th><th>Estado</th><th>Puntos</th><th>Acciones</th></tr>
                </thead>
                <tbody>
                <?php foreach ($usuarios as $u): ?>
                <tr>
                    <td>#<?= $u['id_usuario'] ?></td>
                    <td><?= htmlspecialchars($u['nombre']) ?></td>
                    <td>@<?= htmlspecialchars($u['apodo']) ?></td>
                    <td><?= htmlspecialchars($u['cedula']) ?></td>
                    <td><?= htmlspecialchars($u['correo']) ?></td>
                    <td><?= htmlspecialchars($u['nombre_rol']) ?></td>
                    <td><span class="badge <?= $u['estado'] === 'activo' ? 'activo' : 'inactivo' ?>"><?= htmlspecialchars($u['estado']) ?></span></td>
                    <td><?= (int) $u['puntos_totales'] ?></td>
                    <td>
                        <button type="button" class="accion-btn editar"
                            onclick='abrirModalEditar(<?= json_encode([
                                "id_usuario" => $u["id_usuario"],
                                "nombre" => $u["nombre"],
                                "apodo" => $u["apodo"],
                                "cedula" => $u["cedula"],
                                "correo" => $u["correo"],
                                "id_rol" => (int) $u["id_rol"],
                                "estado" => $u["estado"],
                            ], JSON_UNESCAPED_UNICODE) ?>)'>Editar</button>
                        <form action="procesar_toggle_usuario.php" method="POST" style="display:inline;">
                            <input type="hidden" name="id_usuario" value="<?= $u['id_usuario'] ?>">
                            <input type="hidden" name="nuevo_estado" value="<?= $u['estado'] === 'activo' ? 'inactivo' : 'activo' ?>">
                            <button type="submit" class="accion-link <?= $u['estado'] === 'activo' ? 'borrar' : 'editar' ?>" style="background:none;border:none;cursor:pointer;padding:0;font-family:inherit;">
                                <?= $u['estado'] === 'activo' ? 'Desactivar' : 'Activar' ?>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<div class="modal-overlay" id="modal-crear">
    <div class="modal-caja">
        <button type="button" class="modal-cerrar" onclick="cerrarModal('modal-crear')">✕</button>
        <span class="eyebrow">➕ Nuevo</span>
        <h3 style="margin: 12px 0 18px;">Crear usuario</h3>
        <form action="procesar_crear_usuario_admin.php" method="POST">
            <?= \App\Utils\Csrf::campo() ?>
            <label for="c-nombre">Nombre completo</label>
            <input type="text" id="c-nombre" name="nombre" required minlength="3">

            <label for="c-apodo">Apodo</label>
            <input type="text" id="c-apodo" name="apodo" required minlength="3">

            <label for="c-cedula">Cédula</label>
            <input type="text" id="c-cedula" name="cedula" placeholder="8-123-4567" required>

            <label for="c-correo">Correo</label>
            <input type="email" id="c-correo" name="correo" required>

            <label for="c-password">Contraseña</label>
            <input type="password" id="c-password" name="password" required minlength="8"
                placeholder="Mín. 8 car., mayúscula, minúscula y número">

            <label for="c-rol">Rol</label>
            <select id="c-rol" name="id_rol" required>
                <option value="1">Jugador</option>
                <option value="2">Armador</option>
                <option value="3">Administrador</option>
            </select>

            <div class="modal-acciones">
                <button type="submit" class="buzzer" style="flex:1;">Crear usuario</button>
            </div>
        </form>
    </div>
</div>
<div class="modal-overlay" id="modal-editar">
    <div class="modal-caja">
        <button type="button" class="modal-cerrar" onclick="cerrarModal('modal-editar')">✕</button>
        <span class="eyebrow">✏️ Editar</span>
        <h3 style="margin: 12px 0 18px;">Editar usuario</h3>
        <form action="procesar_editar_usuario.php" method="POST">
            <?= \App\Utils\Csrf::campo() ?>
            <input type="hidden" id="e-id" name="id_usuario">

            <label for="e-nombre">Nombre completo</label>
            <input type="text" id="e-nombre" name="nombre" required minlength="3">

            <label for="e-apodo">Apodo</label>
            <input type="text" id="e-apodo" name="apodo" required minlength="3">

            <label for="e-cedula">Cédula</label>
            <input type="text" id="e-cedula" name="cedula" required>

            <label for="e-correo">Correo</label>
            <input type="email" id="e-correo" name="correo" required>

            <label for="e-password">Nueva contraseña (opcional)</label>
            <input type="password" id="e-password" name="password" minlength="8"
                placeholder="Dejar vacío para no cambiarla">

            <label for="e-rol">Rol</label>
            <select id="e-rol" name="id_rol" required>
                <option value="1">Jugador</option>
                <option value="2">Armador</option>
                <option value="3">Administrador</option>
            </select>

            <label for="e-estado">Estado</label>
            <select id="e-estado" name="estado" required>
                <option value="activo">Activo</option>
                <option value="inactivo">Inactivo</option>
                <option value="bloqueado">Bloqueado</option>
            </select>

            <div class="modal-acciones">
                <button type="submit" class="buzzer teal" style="flex:1;">Guardar cambios</button>
            </div>
        </form>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script>
    $(function () {
        $('#tabla-usuarios').DataTable({
            language: {
                search: 'Buscar:',
                lengthMenu: 'Mostrar _MENU_ usuarios',
                info: 'Mostrando _START_ a _END_ de _TOTAL_ usuarios',
                infoEmpty: 'No hay usuarios para mostrar',
                infoFiltered: '(filtrado de _MAX_ usuarios en total)',
                zeroRecords: 'Ningún usuario coincide con la búsqueda',
                paginate: { previous: 'Anterior', next: 'Siguiente' }
            },
            order: [[0, 'desc']]
        });
    });

    function abrirModalCrear() {
        document.getElementById('modal-crear').classList.add('abierto');
    }

    function abrirModalEditar(usuario) {
        document.getElementById('e-id').value = usuario.id_usuario;
        document.getElementById('e-nombre').value = usuario.nombre;
        document.getElementById('e-apodo').value = usuario.apodo;
        document.getElementById('e-cedula').value = usuario.cedula;
        document.getElementById('e-correo').value = usuario.correo;
        document.getElementById('e-password').value = '';
        document.getElementById('e-rol').value = usuario.id_rol;
        document.getElementById('e-estado').value = usuario.estado;
        document.getElementById('modal-editar').classList.add('abierto');
    }

    function cerrarModal(id) {
        document.getElementById(id).classList.remove('abierto');
    }

    document.querySelectorAll('.modal-overlay').forEach(function (overlay) {
        overlay.addEventListener('click', function (evento) {
            if (evento.target === overlay) {
                overlay.classList.remove('abierto');
            }
        });
    });
</script>
</body>
</html>
