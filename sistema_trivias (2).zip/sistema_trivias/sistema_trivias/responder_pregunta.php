<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Preguntas\PreguntaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::iniciar();
if (!SesionUtil::estaAutenticado() || !isset($_SESSION['partida_actual'])) {
    header('Location: jugar.php');
    exit;
}

$partida = $_SESSION['partida_actual'];
$indice = $partida['indice'];
$totalPreguntas = count($partida['ids_preguntas']);

if ($indice >= $totalPreguntas) {
    header('Location: resultado_partida.php');
    exit;
}

$idPreguntaActual = $partida['ids_preguntas'][$indice];

$_SESSION['partida_actual']['tiempo_inicio_pregunta'] = microtime(true);

$db = Database::obtenerInstancia();
$preguntaService = new PreguntaService($db, new Validador(), new ManejadorErroresArchivo());
$pregunta = $preguntaService->obtenerPorId($idPreguntaActual);

$opciones = $pregunta['opciones'];
shuffle($opciones);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pregunta <?= $indice + 1 ?> de <?= $totalPreguntas ?> — Trivias UTP</title>
<link rel="stylesheet" href="assets/estilo.css">
<style>
    body { display: flex; align-items: center; justify-content: center; padding: 20px; }
    .tarjeta-pregunta {
        background: rgba(255,255,255,0.04);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 24px;
        padding: 36px;
        width: 480px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.4);
    }
    .progreso { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .barra { flex: 1; height: 8px; background: rgba(255,255,255,0.1); border-radius: 999px; margin: 0 14px; overflow: hidden; }
    .barra-fill { height: 100%; background: linear-gradient(90deg, var(--magenta), var(--yellow)); }
    .contador { font-size: 12px; color: var(--text-muted); white-space: nowrap; }

    .enunciado { font-family: 'Baloo 2', sans-serif; font-size: 21px; margin-bottom: 24px; line-height: 1.35; }

    .opcion {
        display: block;
        width: 100%;
        text-align: left;
        padding: 14px 16px;
        margin-bottom: 10px;
        border-radius: 12px;
        border: 1.5px solid rgba(255,255,255,0.12);
        background: rgba(255,255,255,0.05);
        color: var(--text-light);
        font-family: 'Inter', sans-serif;
        font-size: 14px;
        cursor: pointer;
    }
    .opcion:hover { border-color: var(--teal); background: rgba(8,217,214,0.08); }
</style>
</head>
<body>
    <div class="tarjeta-pregunta">
        <div class="progreso">
            <span class="contador">❓ <?= $indice + 1 ?>/<?= $totalPreguntas ?></span>
            <div class="barra"><div class="barra-fill" style="width: <?= (($indice) / $totalPreguntas) * 100 ?>%;"></div></div>
        </div>

        <div class="enunciado"><?= htmlspecialchars($pregunta['enunciado']) ?></div>

        <?php foreach ($opciones as $opcion): ?>
            <form action="guardar_respuesta.php" method="POST">
                <?= \App\Utils\Csrf::campo() ?>
                <input type="hidden" name="id_pregunta" value="<?= $pregunta['id_pregunta'] ?>">
                <input type="hidden" name="id_opcion" value="<?= $opcion['id_opcion'] ?>">
                <button type="submit" class="opcion"><?= htmlspecialchars($opcion['texto_opcion']) ?></button>
            </form>
        <?php endforeach; ?>
    </div>
</body>
</html>
