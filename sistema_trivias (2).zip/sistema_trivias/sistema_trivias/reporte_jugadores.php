<?php

/**
 * reporte_jugadores.php
 * Muestra:
 *   - Tarjetas de totales/promedios generales del sistema.
 *   - Distribución de aprobados por nivel de conocimiento.
 *   - Tabla detallada por jugador (partidas, tiempo promedio,
 *     % de aciertos, puntos), con jQuery DataTable.
 *   - Botón para exportar exactamente esta tabla a Excel.
 */

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Reportes\ReporteService;
use App\Utils\Roles;
use App\Utils\SesionUtil;

SesionUtil::requerirRol([Roles::ARMADOR, Roles::ADMINISTRADOR]);
$usuarioSesion = SesionUtil::usuarioActual();

$db = Database::obtenerInstancia();
$reporteService = new ReporteService($db);

$jugadores = $reporteService->obtenerReportePorJugador();
$totales = $reporteService->obtenerTotalesGenerales();
$distribucionNivel = $reporteService->obtenerDistribucionPorNivel();

$paginaActiva = 'reporte';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reporte de Jugadores — Trivias UTP</title>
<link rel="stylesheet" href="assets/estilo.css">
<style>
    .barra-nivel { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; }
    .barra-nivel .etiqueta-nivel { width: 100px; font-size: 13px; font-weight: 700; flex-shrink: 0; }
    .barra-nivel .pista { flex: 1; background: rgba(255,255,255,0.06); border-radius: 999px; height: 14px; overflow: hidden; }
    .barra-nivel .relleno { height: 100%; border-radius: 999px; background: linear-gradient(90deg, var(--teal), #04b3b0); }
    .barra-nivel .cifra { width: 130px; text-align: right; font-size: 12px; color: var(--text-muted); flex-shrink: 0; }
    .tarjeta h3.metrica { font-size: 26px; font-family: 'Space Mono', monospace; }
    .toolbar-reporte { display: flex; justify-content: flex-end; margin-bottom: 14px; }
    .btn-excel {
        display: inline-flex; align-items: center; gap: 8px; text-decoration: none;
        padding: 11px 20px; border-radius: 999px; font-family: 'Baloo 2', sans-serif;
        font-weight: 800; font-size: 14px; color: #08302f;
        background: linear-gradient(180deg, var(--teal), #04b3b0); box-shadow: 0 5px 0 #037b79;
    }
    .btn-excel:active { transform: translateY(4px); box-shadow: none; }
</style>
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="contenido">
        <div class="encabezado">
            <div>
                <span class="eyebrow">📊 Reporte</span>
                <h1 style="margin-top:10px;">Jugadores y estadísticas</h1>
            </div>
        </div>

        <div class="grid-cards">
            <div class="tarjeta">
                <div class="icono">👥</div>
                <h3 class="metrica"><?= $totales['total_jugadores'] ?></h3>
                <p>Jugadores registrados</p>
            </div>
            <div class="tarjeta">
                <div class="icono">🎮</div>
                <h3 class="metrica"><?= $totales['total_partidas'] ?></h3>
                <p>Partidas jugadas en total</p>
            </div>
            <div class="tarjeta">
                <div class="icono">⏱️</div>
                <h3 class="metrica"><?= $totales['tiempo_promedio_global'] !== null ? number_format($totales['tiempo_promedio_global'], 2) . 's' : '—' ?></h3>
                <p>Tiempo promedio de respuesta</p>
            </div>
            <div class="tarjeta">
                <div class="icono">✅</div>
                <h3 class="metrica"><?= number_format($totales['porcentaje_aciertos_global'], 2) ?>%</h3>
                <p>Aciertos promedio del sistema</p>
            </div>
        </div>

        <div class="tarjeta" style="margin-bottom: 24px;">
            <h3 style="margin-bottom:16px;">Distribución de aprobados por nivel</h3>
            <?php foreach ($distribucionNivel as $nivel):
                $total = (int) $nivel['total_intentos'];
                $aprobados = (int) $nivel['total_aprobados'];
                $porcentaje = $total > 0 ? round(($aprobados / $total) * 100) : 0;
            ?>
            <div class="barra-nivel">
                <span class="etiqueta-nivel"><?= htmlspecialchars($nivel['nombre_nivel']) ?></span>
                <span class="pista"><span class="relleno" style="width:<?= $porcentaje ?>%;"></span></span>
                <span class="cifra"><?= $aprobados ?> aprobados de <?= $total ?> intentos (<?= $porcentaje ?>%)</span>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="tarjeta">
            <div class="toolbar-reporte">
                <a href="reporte_exportar_excel.php" class="btn-excel">📥 Exportar a Excel</a>
            </div>
            <h3 style="margin-bottom:6px;">Detalle por jugador (<?= count($jugadores) ?>)</h3>
            <table id="tabla-reporte" class="display" style="width:100%">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apodo</th>
                    <th>Correo</th>
                    <th>Estado</th>
                    <th>Partidas</th>
                    <th>Tiempo prom. (s)</th>
                    <th>% Aciertos</th>
                    <th>Puntos</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($jugadores as $j): ?>
                <tr>
                    <td>#<?= $j['id_usuario'] ?></td>
                    <td><?= htmlspecialchars($j['nombre']) ?></td>
                    <td><?= htmlspecialchars($j['apodo']) ?></td>
                    <td><?= htmlspecialchars($j['correo']) ?></td>
                    <td><span class="badge <?= $j['estado'] === 'activo' ? 'activo' : 'inactivo' ?>"><?= htmlspecialchars($j['estado']) ?></span></td>
                    <td><?= (int) $j['partidas_jugadas'] ?></td>
                    <td><?= $j['tiempo_promedio_seg'] !== null ? number_format((float) $j['tiempo_promedio_seg'], 2) : '—' ?></td>
                    <td><?= number_format((float) $j['porcentaje_aciertos'], 2) ?>%</td>
                    <td><?= (int) $j['puntos_totales'] ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script>
    $(function () {
        $('#tabla-reporte').DataTable({
            order: [[8, 'desc']],
            language: {
                search: 'Buscar:',
                lengthMenu: 'Mostrar _MENU_ jugadores',
                info: 'Mostrando _START_ a _END_ de _TOTAL_ jugadores',
                infoEmpty: 'No hay jugadores para mostrar',
                infoFiltered: '(filtrado de _MAX_ jugadores en total)',
                zeroRecords: 'Ningún jugador coincide con la búsqueda',
                paginate: { previous: 'Anterior', next: 'Siguiente' }
            }
        });
    });
</script>
</body>
</html>
