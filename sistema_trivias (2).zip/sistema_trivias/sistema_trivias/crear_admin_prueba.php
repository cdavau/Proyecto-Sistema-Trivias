<?php

// Crea un usuario administrador de prueba (correo admin@trivias.com / Admin2026).
// Correr una sola vez.

ini_set('display_errors', '1');
error_reporting(E_ALL);

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;

header('Content-Type: text/plain; charset=utf-8');

$db = Database::obtenerInstancia();
$pdo = $db->obtenerConexion();

$correo = 'admin@trivias.com';
$passwordPlano = 'Admin2026';
$passwordHash = password_hash($passwordPlano, PASSWORD_BCRYPT);

$check = $pdo->prepare('SELECT id_usuario FROM usuario WHERE correo = :correo');
$check->execute(['correo' => $correo]);

if ($check->fetch()) {
    echo "El usuario administrador ya existe.\n";
    echo "Correo: {$correo}\nPassword: {$passwordPlano}\n";
    exit;
}

$stmt = $pdo->prepare(
    'INSERT INTO usuario (nombre, apodo, cedula, correo, password_hash, id_rol, estado)
     VALUES (:nombre, :apodo, :cedula, :correo, :password_hash, 3, "activo")'
);
$stmt->execute([
    'nombre'        => 'Administrador Trivias',
    'apodo'         => 'admin',
    'cedula'        => '8-999-9999',
    'correo'        => $correo,
    'password_hash' => $passwordHash,
]);

echo "✅ Usuario administrador creado.\n\n";
echo "Correo:   {$correo}\n";
echo "Password: {$passwordPlano}\n";
