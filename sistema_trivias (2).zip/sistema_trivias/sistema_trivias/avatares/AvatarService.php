<?php

namespace App\Avatares;

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Interfaces\AvatarInterface;
use App\Interfaces\ManejadorErroresInterface;
use App\Interfaces\ValidadorInterface;
use PDO;
use PDOException;


class AvatarService implements AvatarInterface
{
    private PDO $conexion;

    public function __construct(
        private Database $database,
        private ValidadorInterface $validador,
        private ManejadorErroresInterface $manejadorErrores
    ) {
        $this->conexion = $this->database->obtenerConexion();
    }

    public function crear(string $nombre, string $tipo, string $valor): int
    {
        $nombreValido = $this->validador->validarTextoObligatorio($nombre, 'nombre', 2, 60);
        $tipoValido   = $this->validador->validarEnLista($tipo, ['emoji', 'imagen'], 'tipo');
        $valorValido  = trim($valor);

        if (!$nombreValido || !$tipoValido || $valorValido === '') {
            throw new AutenticacionException(implode(' ', $this->validador->obtenerErrores()) ?: 'Datos de avatar inválidos.');
        }

        try {
            $stmt = $this->conexion->prepare(
                'INSERT INTO avatar (nombre, tipo, valor, activo) VALUES (:nombre, :tipo, :valor, TRUE)'
            );
            $stmt->execute([
                'nombre' => $nombreValido,
                'tipo' => $tipoValido,
                'valor' => $valorValido,
            ]);

            return (int) $this->conexion->lastInsertId();

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'AvatarService::crear');
            throw new AutenticacionException('No se pudo crear el avatar.');
        }
    }

    public function listar(): array
    {
        $stmt = $this->conexion->query('SELECT * FROM avatar ORDER BY activo DESC, id_avatar ASC');
        return $stmt->fetchAll();
    }

    public function listarActivos(): array
    {
        $stmt = $this->conexion->query('SELECT * FROM avatar WHERE activo = TRUE ORDER BY id_avatar ASC');
        return $stmt->fetchAll();
    }

    public function obtenerPorId(int $idAvatar): ?array
    {
        $stmt = $this->conexion->prepare('SELECT * FROM avatar WHERE id_avatar = :id LIMIT 1');
        $stmt->execute(['id' => $idAvatar]);
        $avatar = $stmt->fetch();

        return $avatar ?: null;
    }

    public function actualizar(int $idAvatar, array $datos): bool
    {
        $camposPermitidos = ['nombre', 'tipo', 'valor', 'activo'];
        $sets = [];
        $parametros = ['id' => $idAvatar];

        foreach ($datos as $campo => $valor) {
            if (!in_array($campo, $camposPermitidos, true)) {
                continue;
            }

            if ($campo === 'nombre') {
                $valor = $this->validador->validarTextoObligatorio($valor, 'nombre', 2, 60);
                if (!$valor) {
                    throw new AutenticacionException('Nombre de avatar inválido.');
                }
            } elseif ($campo === 'tipo') {
                $valor = $this->validador->validarEnLista($valor, ['emoji', 'imagen'], 'tipo');
                if (!$valor) {
                    throw new AutenticacionException('Tipo de avatar inválido.');
                }
            } elseif ($campo === 'valor') {
                $valor = trim($valor);
                if ($valor === '') {
                    throw new AutenticacionException('El valor del avatar no puede estar vacío.');
                }
            } elseif ($campo === 'activo') {
                $valor = (bool) $valor;
            }

            $sets[] = "{$campo} = :{$campo}";
            $parametros[$campo] = $valor;
        }

        if (empty($sets)) {
            return false;
        }

        try {
            $sql = 'UPDATE avatar SET ' . implode(', ', $sets) . ' WHERE id_avatar = :id';
            $stmt = $this->conexion->prepare($sql);
            return $stmt->execute($parametros);

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'AvatarService::actualizar');
            throw new AutenticacionException('No se pudo actualizar el avatar.');
        }
    }

    public function desactivar(int $idAvatar): bool
    {
        try {
            $stmt = $this->conexion->prepare('UPDATE avatar SET activo = FALSE WHERE id_avatar = :id');
            return $stmt->execute(['id' => $idAvatar]);

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'AvatarService::desactivar');
            throw new AutenticacionException('No se pudo desactivar el avatar.');
        }
    }

    public function activar(int $idAvatar): bool
    {
        try {
            $stmt = $this->conexion->prepare('UPDATE avatar SET activo = TRUE WHERE id_avatar = :id');
            return $stmt->execute(['id' => $idAvatar]);

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'AvatarService::activar');
            throw new AutenticacionException('No se pudo activar el avatar.');
        }
    }
}
