<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Juego\JuegoService;
use App\Premios\PremioService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::iniciar();
if (!SesionUtil::estaAutenticado() || !isset($_SESSION['partida_actual'])) {
    header('Location: jugar.php');
    exit;
}

$partida = $_SESSION['partida_actual'];
$usuarioSesion = SesionUtil::usuarioActual();

$db = Database::obtenerInstancia();
$premioService = new PremioService($db, new Validador(), new ManejadorErroresArchivo());
$juegoService = new JuegoService($db, new ManejadorErroresArchivo(), $premioService);

$resultado = $juegoService->finalizarPartida(
    $partida['id_partida_jugador'],
    (int) $usuarioSesion['id_usuario'],
    $partida['id_tema_nivel'],
    count($partida['ids_preguntas']),
    $partida['total_correctas']
);

unset($_SESSION['partida_actual']);
function resultadoVisual(int $porcentaje): array
{
    if ($porcentaje === 100) {
        return ['emoji' => '🏆', 'titulo' => '¡Puntaje perfecto!', 'clase' => 'anim-trofeo'];
    }
    if ($porcentaje >= 80) {
        return ['emoji' => '🥇', 'titulo' => '¡Excelente resultado!', 'clase' => 'anim-medalla'];
    }
    if ($porcentaje >= 70) {
        return ['emoji' => '🎉', 'titulo' => '¡Nivel aprobado!', 'clase' => 'anim-fiesta'];
    }
    if ($porcentaje >= 40) {
        return ['emoji' => '💪', 'titulo' => 'Casi lo logras', 'clase' => 'anim-animo'];
    }
    return ['emoji' => '😢', 'titulo' => 'Sigue practicando', 'clase' => 'anim-triste'];
}

$visual = resultadoVisual((int) $resultado['porcentaje']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Resultado — Trivias UTP</title>
<link rel="stylesheet" href="assets/estilo.css">
<style>
    body { display: flex; align-items: center; justify-content: center; padding: 20px; }
    .tarjeta-resultado {
        background: rgba(255,255,255,0.04);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 24px;
        padding: 40px;
        width: 420px;
        text-align: center;
        box-shadow: 0 20px 60px rgba(0,0,0,0.4);
    }
    .emoji-grande { font-size: 60px; margin-bottom: 10px; display: inline-block; }

    @keyframes rebotar-trofeo {
        0%, 100% { transform: translateY(0) scale(1); }
        30% { transform: translateY(-18px) scale(1.08); }
        50% { transform: translateY(0) scale(1); }
        65% { transform: translateY(-8px) scale(1.03); }
    }
    @keyframes girar-medalla {
        0% { transform: rotate(0deg) scale(1); }
        50% { transform: rotate(8deg) scale(1.12); }
        100% { transform: rotate(0deg) scale(1); }
    }
    @keyframes saltar-fiesta {
        0%, 100% { transform: translateY(0) rotate(0deg); }
        25% { transform: translateY(-10px) rotate(-6deg); }
        75% { transform: translateY(-10px) rotate(6deg); }
    }
    @keyframes animar-esfuerzo {
        0%, 100% { transform: translateX(0) rotate(0deg); }
        25% { transform: translateX(-4px) rotate(-4deg); }
        75% { transform: translateX(4px) rotate(4deg); }
    }
    @keyframes gotear-tristeza {
        0%, 100% { transform: translateY(0); opacity: 1; }
        50% { transform: translateY(6px); opacity: 0.75; }
    }
    .anim-trofeo { animation: rebotar-trofeo 1.4s ease-in-out infinite; }
    .anim-medalla { animation: girar-medalla 1.6s ease-in-out infinite; }
    .anim-fiesta { animation: saltar-fiesta 1s ease-in-out infinite; }
    .anim-animo { animation: animar-esfuerzo 0.7s ease-in-out infinite; }
    .anim-triste { animation: gotear-tristeza 1.8s ease-in-out infinite; }
    .titulo-resultado { font-family: 'Baloo 2', sans-serif; font-size: 24px; margin-bottom: 6px; }
    .subtitulo-resultado { color: var(--text-muted); font-size: 14px; margin-bottom: 26px; }

    .stats { display: flex; justify-content: space-around; margin-bottom: 26px; }
    .stat .numero { font-family: 'Space Mono', monospace; font-size: 28px; font-weight: 700; color: var(--yellow); }
    .stat .etiqueta { font-size: 11px; text-transform: uppercase; color: var(--text-muted); }

    .botones a {
        display: inline-block; text-decoration: none; padding: 12px 22px; border-radius: 999px;
        font-family: 'Baloo 2', sans-serif; font-weight: 800; font-size: 14px; margin: 4px;
    }
    .btn-jugar-otra { background: linear-gradient(180deg, var(--teal), #04b3b0); color: #08302f; }
    .btn-marcador { background: rgba(255,255,255,0.08); color: var(--text-light); }

    .premios-obtenidos {
        margin-bottom: 24px; padding: 16px; border-radius: 16px;
        background: rgba(255,210,63,0.1); border: 1px solid rgba(255,210,63,0.35);
    }
    .premios-obtenidos h4 { font-size: 13px; color: var(--yellow); margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.04em; }
    .lista-premios { display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; }
    .premio-chip {
        display: flex; align-items: center; gap: 6px; background: rgba(255,255,255,0.06);
        border-radius: 999px; padding: 6px 12px; font-size: 12.5px;
    }
    .premio-chip img { width: 20px; height: 20px; border-radius: 50%; object-fit: cover; }
</style>
</head>
<body>
    <div class="tarjeta-resultado">
        <div class="emoji-grande <?= $visual['clase'] ?>"><?= $visual['emoji'] ?></div>
        <div class="titulo-resultado"><?= $visual['titulo'] ?></div>
        <?php if ($resultado['aprobado']): ?>
            <div class="subtitulo-resultado">Desbloqueaste el siguiente nivel de este tema (<?= $resultado['total_correctas'] ?>/<?= $resultado['total_preguntas'] ?> correctas).</div>
        <?php else: ?>
            <div class="subtitulo-resultado">Necesitas 70% o más para aprobar. ¡Inténtalo de nuevo!</div>
        <?php endif; ?>

        <div class="stats">
            <div class="stat">
                <div class="numero"><?= $resultado['total_correctas'] ?>/<?= $resultado['total_preguntas'] ?></div>
                <div class="etiqueta">Correctas</div>
            </div>
            <div class="stat">
                <div class="numero"><?= $resultado['porcentaje'] ?>%</div>
                <div class="etiqueta">Puntaje</div>
            </div>
            <div class="stat">
                <div class="numero">+<?= $resultado['puntos_ganados'] ?></div>
                <div class="etiqueta">Puntos</div>
            </div>
        </div>

        <?php if (!empty($resultado['premios_obtenidos'])): ?>
        <div class="premios-obtenidos">
            <h4>🎁 ¡Nuevos premios!</h4>
            <div class="lista-premios">
                <?php foreach ($resultado['premios_obtenidos'] as $premio): ?>
                    <span class="premio-chip">
                        <?php if (str_starts_with($premio['imagen'], 'http') || str_starts_with($premio['imagen'], 'uploads/')): ?>
                            <img src="<?= htmlspecialchars($premio['imagen']) ?>" alt="">
                        <?php else: ?>
                            🏅
                        <?php endif; ?>
                        <?= htmlspecialchars($premio['nombre_premio']) ?> (+<?= (int) $premio['ponderacion_puntos'] ?> pts)
                    </span>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="botones">
            <a href="jugar.php" class="btn-jugar-otra">🎮 Jugar otro nivel</a>
            <a href="dashboard.php" class="btn-marcador">Ver marcador</a>
        </div>
    </div>
</body>
</html>
