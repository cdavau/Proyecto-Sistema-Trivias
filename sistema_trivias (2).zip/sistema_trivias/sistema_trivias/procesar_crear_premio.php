<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Premios\PremioService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ARMADOR, Roles::ADMINISTRADOR]);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: gestion_premios.php');
    exit;
} \App\Utils\Csrf::validar();   

$db = Database::obtenerInstancia();
$premioService = new PremioService($db, new Validador(), new ManejadorErroresArchivo());

$idNivel = !empty($_POST['id_nivel']) ? (int) $_POST['id_nivel'] : null;
$idTema  = !empty($_POST['id_tema']) ? (int) $_POST['id_tema'] : null;

try {
    $premioService->crear(
        $_POST['nombre_premio'] ?? '',
        $_POST['imagen'] ?? '',
        (int) ($_POST['ponderacion_puntos'] ?? 0),
        $idNivel,
        $idTema
    );
    header('Location: gestion_premios.php?exito=1');
    exit;

} catch (AutenticacionException $e) {
    header('Location: gestion_premios.php?error=' . urlencode($e->getMessage()));
    exit;
}
