<?php

namespace App\Juego;

use App\Config\Database;
use App\Interfaces\JuegoInterface;
use App\Interfaces\ManejadorErroresInterface;
use App\Interfaces\PremioInterface;
use PDO;

/**
 * JuegoService
 *
 * Núcleo de la mecánica de juego:
 * - Respeta la regla del alcance: "No debe pasar a un nivel avanzado
 *   si no ha pasado el nivel básico".
 * - Registra cada respuesta del jugador.
 * - Al finalizar, calcula si aprueba el nivel,
 *   actualiza el progreso, suma puntos al usuario y otorga los
 *   premios del catálogo que correspondan al tema/nivel aprobado.
 */
class JuegoService implements JuegoInterface
{
    private const PORCENTAJE_APROBACION = 70;
    private const PUNTOS_POR_RESPUESTA_CORRECTA = 10;

    private PDO $conexion;

    public function __construct(
        private Database $database,
        private ManejadorErroresInterface $manejadorErrores,
        private ?PremioInterface $premioService = null
    ) {
        $this->conexion = $this->database->obtenerConexion();
    }

    public function obtenerNivelesConEstado(int $idUsuario): array
    {
        $stmt = $this->conexion->prepare(
            'SELECT tn.id_tema_nivel, tn.nombre_especifico, tn.id_tema, tn.id_nivel,
                    t.nombre_tema, n.nombre_nivel, n.orden,
                    up.estado AS estado_progreso, up.mejor_porcentaje
             FROM tema_nivel tn
             JOIN tema t ON t.id_tema = tn.id_tema
             JOIN nivel_conocimiento n ON n.id_nivel = tn.id_nivel
             LEFT JOIN usuario_progreso up ON up.id_tema_nivel = tn.id_tema_nivel AND up.id_usuario = :id_usuario
             ORDER BY t.nombre_tema, n.orden'
        );
        $stmt->execute(['id_usuario' => $idUsuario]);
        $niveles = $stmt->fetchAll();

        foreach ($niveles as &$nivel) {
            $nivel['mejor_porcentaje'] = (int) ($nivel['mejor_porcentaje'] ?? 0);

            if ($nivel['estado_progreso'] === 'aprobado') {
                $nivel['estado'] = 'aprobado';
            } elseif ((int) $nivel['orden'] === 1) {
                $nivel['estado'] = 'disponible';
            } else {
                $nivel['estado'] = $this->nivelDesbloqueado($idUsuario, (int) $nivel['id_tema_nivel'])
                    ? 'disponible'
                    : 'bloqueado';
            }
        }

        return $niveles;
    }

    public function obtenerAvanceDeOtros(int $idTemaNivel, int $idUsuarioExcluir, int $limite = 5): array
    {
        $stmt = $this->conexion->prepare(
            'SELECT u.nombre, u.apodo, u.avatar, up.mejor_porcentaje, up.estado
             FROM usuario_progreso up
             JOIN usuario u ON u.id_usuario = up.id_usuario
             WHERE up.id_tema_nivel = :id_tema_nivel
               AND up.id_usuario != :id_usuario
               AND up.mejor_porcentaje > 0
             ORDER BY up.mejor_porcentaje DESC
             LIMIT :limite'
        );
        $stmt->bindValue(':id_tema_nivel', $idTemaNivel, PDO::PARAM_INT);
        $stmt->bindValue(':id_usuario', $idUsuarioExcluir, PDO::PARAM_INT);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function nivelDesbloqueado(int $idUsuario, int $idTemaNivel): bool
    {
        $stmt = $this->conexion->prepare(
            'SELECT tn.id_tema, n.orden
             FROM tema_nivel tn
             JOIN nivel_conocimiento n ON n.id_nivel = tn.id_nivel
             WHERE tn.id_tema_nivel = :id'
        );
        $stmt->execute(['id' => $idTemaNivel]);
        $actual = $stmt->fetch();

        if (!$actual) {
            return false;
        }
        if ((int) $actual['orden'] === 1) {
            return true;
        }
        $stmt = $this->conexion->prepare(
            'SELECT tn.id_tema_nivel
             FROM tema_nivel tn
             JOIN nivel_conocimiento n ON n.id_nivel = tn.id_nivel
             WHERE tn.id_tema = :id_tema AND n.orden = :orden_anterior'
        );
        $stmt->execute([
            'id_tema' => $actual['id_tema'],
            'orden_anterior' => (int) $actual['orden'] - 1,
        ]);
        $anterior = $stmt->fetch();

        if (!$anterior) {
            return true; 
        }
        $stmt = $this->conexion->prepare(
            'SELECT estado FROM usuario_progreso
             WHERE id_usuario = :id_usuario AND id_tema_nivel = :id_tema_nivel'
        );
        $stmt->execute([
            'id_usuario' => $idUsuario,
            'id_tema_nivel' => $anterior['id_tema_nivel'],
        ]);
        $progreso = $stmt->fetch();

        return $progreso && $progreso['estado'] === 'aprobado';
    }

    public function iniciarPartida(int $idUsuario, int $idTemaNivel): int
    {
        $this->conexion->beginTransaction();

        try {
            $stmt = $this->conexion->prepare(
                'INSERT INTO partida_trivia (id_tema_nivel, tipo) VALUES (:id_tema_nivel, "individual")'
            );
            $stmt->execute(['id_tema_nivel' => $idTemaNivel]);
            $idPartida = (int) $this->conexion->lastInsertId();

            $stmt = $this->conexion->prepare(
                'INSERT INTO partida_jugador (id_partida, id_usuario, puntos_obtenidos)
                 VALUES (:id_partida, :id_usuario, 0)'
            );
            $stmt->execute(['id_partida' => $idPartida, 'id_usuario' => $idUsuario]);
            $idPartidaJugador = (int) $this->conexion->lastInsertId();
            $stmt = $this->conexion->prepare(
                'INSERT INTO usuario_progreso (id_usuario, id_tema_nivel, estado, fecha_inicio)
                 VALUES (:id_usuario, :id_tema_nivel, "en_curso", NOW())
                 ON DUPLICATE KEY UPDATE fecha_inicio = IF(estado = "bloqueado", NOW(), fecha_inicio)'
            );
            $stmt->execute(['id_usuario' => $idUsuario, 'id_tema_nivel' => $idTemaNivel]);

            $this->conexion->commit();
            return $idPartidaJugador;

        } catch (\PDOException $e) {
            $this->conexion->rollBack();
            $this->manejadorErrores->registrarError($e->getMessage(), 'JuegoService::iniciarPartida');
            throw $e;
        }
    }

    public function registrarRespuesta(int $idPartidaJugador, int $idPregunta, int $idOpcionSeleccionada, ?float $tiempoRespuesta = null): bool
    {
        $stmt = $this->conexion->prepare(
            'SELECT es_correcta FROM opcion_respuesta WHERE id_opcion = :id_opcion AND id_pregunta = :id_pregunta'
        );
        $stmt->execute(['id_opcion' => $idOpcionSeleccionada, 'id_pregunta' => $idPregunta]);
        $opcion = $stmt->fetch();
        $esCorrecta = $opcion && (bool) $opcion['es_correcta'];

        $stmt = $this->conexion->prepare(
            'INSERT INTO respuesta_usuario (id_partida_jugador, id_pregunta, id_opcion_seleccionada, es_correcta, tiempo_respuesta)
             VALUES (:id_partida_jugador, :id_pregunta, :id_opcion, :es_correcta, :tiempo_respuesta)'
        );
        $stmt->execute([
            'id_partida_jugador' => $idPartidaJugador,
            'id_pregunta' => $idPregunta,
            'id_opcion' => $idOpcionSeleccionada,
            'es_correcta' => $esCorrecta ? 1 : 0,
            'tiempo_respuesta' => $tiempoRespuesta,
        ]);

        if ($esCorrecta) {
            $stmt = $this->conexion->prepare(
                'UPDATE partida_jugador SET puntos_obtenidos = puntos_obtenidos + :puntos WHERE id_partida_jugador = :id'
            );
            $stmt->execute(['puntos' => self::PUNTOS_POR_RESPUESTA_CORRECTA, 'id' => $idPartidaJugador]);
        }

        return $esCorrecta;
    }

    public function finalizarPartida(int $idPartidaJugador, int $idUsuario, int $idTemaNivel, int $totalPreguntas, int $totalCorrectas): array
    {
        $porcentaje = $totalPreguntas > 0 ? round(($totalCorrectas / $totalPreguntas) * 100) : 0;
        $aprobado = $porcentaje >= self::PORCENTAJE_APROBACION;
        $puntosGanados = $totalCorrectas * self::PUNTOS_POR_RESPUESTA_CORRECTA;

        $this->conexion->beginTransaction();

        try {
            $stmt = $this->conexion->prepare(
                'UPDATE usuario_progreso
                 SET estado = :estado, fecha_fin = NOW(),
                     mejor_porcentaje = GREATEST(mejor_porcentaje, :porcentaje),
                     tiempo_transcurrido = TIMESTAMPDIFF(SECOND, fecha_inicio, NOW())
                 WHERE id_usuario = :id_usuario AND id_tema_nivel = :id_tema_nivel'
            );
            $stmt->execute([
                'estado' => $aprobado ? 'aprobado' : 'en_curso',
                'porcentaje' => $porcentaje,
                'id_usuario' => $idUsuario,
                'id_tema_nivel' => $idTemaNivel,
            ]);

            $stmt = $this->conexion->prepare(
                'UPDATE usuario SET puntos_totales = puntos_totales + :puntos WHERE id_usuario = :id_usuario'
            );
            $stmt->execute(['puntos' => $puntosGanados, 'id_usuario' => $idUsuario]);

            $stmt = $this->conexion->prepare(
                'SELECT AVG(tiempo_respuesta) AS promedio
                 FROM respuesta_usuario
                 WHERE id_partida_jugador = :id AND tiempo_respuesta IS NOT NULL'
            );
            $stmt->execute(['id' => $idPartidaJugador]);
            $promedio = $stmt->fetchColumn();

           // Sello de integridad (firma digital) de los datos críticos:
            // jugador + puntos obtenidos en esta partida.
            $firma = \App\Utils\SelloIntegridad::calcular([
                $idPartidaJugador,
                $idUsuario,
                $puntosGanados,
            ]);

            $stmt = $this->conexion->prepare(
                'UPDATE partida_jugador
                 SET posicion_final = 1, tiempo_respuesta_promedio = :promedio, firma = :firma
                 WHERE id_partida_jugador = :id'
            );
            $stmt->execute([
                'promedio' => $promedio,
                'firma'    => $firma,
                'id'       => $idPartidaJugador,
            ]);

            $this->conexion->commit();

        } catch (\PDOException $e) {
            $this->conexion->rollBack();
            $this->manejadorErrores->registrarError($e->getMessage(), 'JuegoService::finalizarPartida');
            throw $e;
        }

        $premiosObtenidos = [];

        if ($aprobado && $this->premioService !== null) {
            $stmt = $this->conexion->prepare(
                'SELECT id_tema, id_nivel FROM tema_nivel WHERE id_tema_nivel = :id'
            );
            $stmt->execute(['id' => $idTemaNivel]);
            $temaNivel = $stmt->fetch();

            if ($temaNivel) {
                $premiosObtenidos = $this->premioService->otorgarPremiosPorNivelAprobado(
                    $idUsuario,
                    (int) $temaNivel['id_tema'],
                    (int) $temaNivel['id_nivel']
                );
            }
        }

        return [
            'aprobado' => $aprobado,
            'porcentaje' => $porcentaje,
            'puntos_ganados' => $puntosGanados,
            'total_correctas' => $totalCorrectas,
            'total_preguntas' => $totalPreguntas,
            'premios_obtenidos' => $premiosObtenidos,
        ];
    }
    /**
     * Verifica que el registro de una partida no haya sido manipulado
     * directamente en la base de datos, comparando su firma almacenada
     * con la recalculada a partir de los datos críticos.
     */
    public function verificarIntegridadPartida(int $idPartidaJugador): bool
    {
        $stmt = $this->conexion->prepare(
            'SELECT id_usuario, puntos_obtenidos, firma
             FROM partida_jugador WHERE id_partida_jugador = :id'
        );
        $stmt->execute(['id' => $idPartidaJugador]);
        $registro = $stmt->fetch();

        if (!$registro || empty($registro['firma'])) {
            return false;
        }

        return \App\Utils\SelloIntegridad::verificar(
            [
                $idPartidaJugador,
                (int) $registro['id_usuario'],
                (int) $registro['puntos_obtenidos'],
            ],
            $registro['firma']
        );
    }
}
