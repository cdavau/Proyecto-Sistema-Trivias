<?php

namespace App\Juego;

use App\Config\Database;
use PDO;

class RankingService
{
    private PDO $conexion;

    public function __construct(private Database $database)
    {
        $this->conexion = $this->database->obtenerConexion();
    }

    public function obtenerRankingPuntos(int $limite = 10): array
    {
        $stmt = $this->conexion->prepare(
            'SELECT u.id_usuario, u.nombre, u.apodo, u.avatar, u.puntos_totales
             FROM usuario u
             WHERE u.estado = "activo"
             ORDER BY u.puntos_totales DESC
             LIMIT :limite'
        );
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function obtenerRankingVelocidad(int $limite = 10): array
    {
        $stmt = $this->conexion->prepare(
            'SELECT u.id_usuario, u.nombre, u.apodo, u.avatar,
                    AVG(pj.tiempo_respuesta_promedio) AS velocidad_promedio,
                    COUNT(pj.id_partida_jugador) AS partidas_jugadas
             FROM usuario u
             JOIN partida_jugador pj ON pj.id_usuario = u.id_usuario
             WHERE pj.tiempo_respuesta_promedio IS NOT NULL
             GROUP BY u.id_usuario, u.nombre, u.apodo, u.avatar
             ORDER BY velocidad_promedio ASC
             LIMIT :limite'
        );
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function obtenerTemasMasJugados(): array
    {
        $stmt = $this->conexion->query(
            'SELECT nombre_tema, veces_jugado, porcentaje_aciertos FROM vista_estadisticas_temas ORDER BY veces_jugado DESC'
        );
        return $stmt->fetchAll();
    }
}
