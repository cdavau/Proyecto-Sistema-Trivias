<?php

require_once __DIR__ . '/bootstrap.php';

use App\Avatares\AvatarService;
use App\Config\Database;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ADMINISTRADOR]);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: gestion_avatares.php');
    exit;
} \App\Utils\Csrf::validar();

$db = Database::obtenerInstancia();
$avatarService = new AvatarService($db, new Validador(), new ManejadorErroresArchivo());

$idAvatar = (int) ($_POST['id_avatar'] ?? 0);
$nuevoEstado = ($_POST['nuevo_estado'] ?? '1') === '1';

if ($nuevoEstado) {
    $avatarService->activar($idAvatar);
} else {
    $avatarService->desactivar($idAvatar);
}

header('Location: gestion_avatares.php?exito=1');
exit;
