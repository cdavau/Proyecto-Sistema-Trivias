<?php

// Prueba el CRUD de usuarios: crear, listar, obtener por id, actualizar y eliminar (baja lógica).

require_once __DIR__ . '/config/entorno.php';

require_once __DIR__ . '/interfaces/ManejadorErroresInterface.php';
require_once __DIR__ . '/interfaces/ValidadorInterface.php';
require_once __DIR__ . '/interfaces/UsuarioInterface.php';
require_once __DIR__ . '/utils/ManejadorErroresArchivo.php';
require_once __DIR__ . '/utils/Validador.php';
require_once __DIR__ . '/utils/Roles.php';
require_once __DIR__ . '/exceptions/DatabaseException.php';
require_once __DIR__ . '/exceptions/AutenticacionException.php';
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/usuarios/UsuarioService.php';

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Usuarios\UsuarioService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\Validador;

header('Content-Type: text/plain; charset=utf-8');

$db      = Database::obtenerInstancia();
$service = new UsuarioService($db, new Validador(), new ManejadorErroresArchivo());

try {

    $correoPrueba = 'maria.' . time() . '@trivias.com';
    $idNuevo = $service->crear('María González', 'mariag_' . time(), '8-' . time(), $correoPrueba, 'Password2026', Roles::ARMADOR);
    echo "✅ CREAR: usuario creado con ID {$idNuevo}\n\n";


    $usuarios = $service->listar();
    echo "✅ LISTAR: " . count($usuarios) . " usuario(s) en total\n";
    foreach (array_slice($usuarios, 0, 5) as $u) {
        echo "   - [{$u['id_usuario']}] {$u['nombre']} ({$u['nombre_rol']}) - {$u['estado']}\n";
    }
    echo "\n";


    $usuario = $service->obtenerPorId($idNuevo);
    echo "✅ OBTENER POR ID: {$usuario['nombre']} - {$usuario['correo']} - rol: {$usuario['nombre_rol']}\n\n";


    $service->actualizar($idNuevo, ['nombre' => 'María González Actualizada']);
    $usuarioActualizado = $service->obtenerPorId($idNuevo);
    echo "✅ ACTUALIZAR: nuevo nombre = {$usuarioActualizado['nombre']}\n\n";

    $service->eliminar($idNuevo);
    $usuarioEliminado = $service->obtenerPorId($idNuevo);
    echo "✅ ELIMINAR (baja lógica): estado actual = {$usuarioEliminado['estado']}\n";

} catch (AutenticacionException $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
}
