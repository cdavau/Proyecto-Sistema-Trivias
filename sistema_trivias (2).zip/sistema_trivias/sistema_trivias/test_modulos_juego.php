<?php



ini_set('display_errors', '1');
error_reporting(E_ALL);

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Preguntas\PreguntaService;
use App\Premios\PremioService;
use App\Temas\TemaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Validador;

header('Content-Type: text/plain; charset=utf-8');

$db = Database::obtenerInstancia();
$validador = new Validador();
$manejador = new ManejadorErroresArchivo();

$temaService = new TemaService($db, $validador, $manejador);
$preguntaService = new PreguntaService($db, $validador, $manejador);
$premioService = new PremioService($db, $validador, $manejador);

try {

    $temas = $temaService->listarTemas();
    echo "✅ TEMAS existentes: " . count($temas) . "\n";
    foreach ($temas as $t) {
        echo "   - [{$t['id_tema']}] {$t['nombre_tema']}\n";
    }
    echo "\n";

    $nivelesTema = $temaService->listarTemaNivel();
    echo "✅ NIVELES POR TEMA: " . count($nivelesTema) . "\n";
    foreach ($nivelesTema as $n) {
        echo "   - [{$n['id_tema_nivel']}] {$n['nombre_especifico']} (orden nivel: {$n['orden']})\n";
    }
    echo "\n";

    $idTemaNivelPrueba = $nivelesTema[0]['id_tema_nivel'];
    echo "Usando tema_nivel de prueba: {$nivelesTema[0]['nombre_especifico']} (id {$idTemaNivelPrueba})\n\n";

    $idPregunta = $preguntaService->crear(
        $idTemaNivelPrueba,
        '¿Qué símbolo se usa para declarar una variable en PHP?',
        'opcion_multiple',
        1, 
        [
            ['texto' => '$', 'es_correcta' => true],
            ['texto' => '#', 'es_correcta' => false],
            ['texto' => '&', 'es_correcta' => false],
            ['texto' => '@', 'es_correcta' => false],
        ]
    );
    echo "✅ PREGUNTA creada con ID {$idPregunta}\n";

    $pregunta = $preguntaService->obtenerPorId($idPregunta);
    echo "   Enunciado: {$pregunta['enunciado']}\n";
    foreach ($pregunta['opciones'] as $opcion) {
        $marca = $opcion['es_correcta'] ? '✔' : ' ';
        echo "   [{$marca}] {$opcion['texto_opcion']}\n";
    }
    echo "\n";

    $idPregunta2 = $preguntaService->crear(
        $idTemaNivelPrueba,
        'PHP es un lenguaje de tipado estricto por defecto.',
        'verdadero_falso',
        1,
        [
            ['texto' => 'Verdadero', 'es_correcta' => false],
            ['texto' => 'Falso', 'es_correcta' => true],
        ]
    );
    echo "✅ PREGUNTA V/F creada con ID {$idPregunta2}\n\n";

    $idPremio = $premioService->crear(
        'Medalla PHP Básico',
        'imagenes/premios/medalla_php_basico.png',
        100,
        $nivelesTema[0]['id_nivel'],
        $nivelesTema[0]['id_tema']
    );
    echo "✅ PREMIO creado con ID {$idPremio}\n";

    $premio = $premioService->obtenerPorId($idPremio);
    echo "   {$premio['nombre_premio']} - {$premio['ponderacion_puntos']} puntos - Nivel: {$premio['nombre_nivel']} - Tema: {$premio['nombre_tema']}\n\n";

    echo "🎉 Todos los módulos (Temas, Preguntas, Premios) funcionan correctamente.\n";

} catch (AutenticacionException $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
}
