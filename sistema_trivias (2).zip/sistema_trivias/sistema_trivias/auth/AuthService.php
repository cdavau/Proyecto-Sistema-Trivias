<?php

namespace App\Auth;

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Interfaces\AutenticacionInterface;
use App\Interfaces\ManejadorErroresInterface;
use App\Interfaces\ValidadorInterface;
use PDO;

class AuthService implements AutenticacionInterface
{
    private const MAXIMO_INTENTOS = 3;
    private const MINUTOS_BLOQUEO = 15;

    private PDO $conexion;

    public function __construct(
        private Database $database,
        private ValidadorInterface $validador,
        private ManejadorErroresInterface $manejadorErrores
    ) {
        $this->conexion = $this->database->obtenerConexion();
    }

    public function autenticar(string $correo, string $password, string $ip): array
    {
        $correoValidado = $this->validador->validarCorreo($correo);

        if ($correoValidado === null) {
            throw new AutenticacionException('Correo o contraseña incorrectos.');
        }

        if ($this->estaBloqueado($correoValidado)) {
            throw new AutenticacionException(
                'Cuenta bloqueada temporalmente por múltiples intentos fallidos. ' .
                'Intenta nuevamente en ' . self::MINUTOS_BLOQUEO . ' minutos.'
            );
        }

        $stmt = $this->conexion->prepare(
            'SELECT id_usuario, nombre, apodo, password_hash, id_rol, estado
             FROM usuario
             WHERE correo = :correo
             LIMIT 1'
        );
        $stmt->execute(['correo' => $correoValidado]);
        $usuario = $stmt->fetch();

        if (!$usuario) {
            $this->registrarIntento(null, $correoValidado, $ip, false);
            throw new AutenticacionException('Correo o contraseña incorrectos.');
        }

        if ($usuario['estado'] !== 'activo') {
            $this->registrarIntento($usuario['id_usuario'], $correoValidado, $ip, false);
            throw new AutenticacionException('Esta cuenta se encuentra inactiva o bloqueada.');
        }

        if (!password_verify($password, $usuario['password_hash'])) {
            $this->registrarIntento($usuario['id_usuario'], $correoValidado, $ip, false);
            throw new AutenticacionException('Correo o contraseña incorrectos.');
        }

        $this->registrarIntento($usuario['id_usuario'], $correoValidado, $ip, true);

        return [
            'id_usuario' => $usuario['id_usuario'],
            'nombre'     => $usuario['nombre'],
            'apodo'      => $usuario['apodo'],
            'id_rol'     => $usuario['id_rol'],
        ];
    }
    private function estaBloqueado(string $correo): bool
    {
        $stmt = $this->conexion->prepare(
            'SELECT exitoso
             FROM intento_login
             WHERE correo_ingresado = :correo
               AND fecha_hora >= (NOW() - INTERVAL :minutos MINUTE)
             ORDER BY fecha_hora DESC
             LIMIT :maximo'
        );
        $stmt->bindValue(':correo', $correo);
        $stmt->bindValue(':minutos', self::MINUTOS_BLOQUEO, PDO::PARAM_INT);
        $stmt->bindValue(':maximo', self::MAXIMO_INTENTOS, PDO::PARAM_INT);
        $stmt->execute();

        $intentosRecientes = $stmt->fetchAll(PDO::FETCH_COLUMN);

        if (count($intentosRecientes) < self::MAXIMO_INTENTOS) {
            return false;
        }

        foreach ($intentosRecientes as $exitoso) {
            if ((bool) $exitoso === true) {
                return false;
            }
        }

        return true;
    }

    private function calcularNumeroIntento(string $correo): int
    {
        $stmt = $this->conexion->prepare(
            'SELECT COUNT(*) AS total
             FROM intento_login
             WHERE correo_ingresado = :correo
               AND exitoso = 0
               AND fecha_hora >= (NOW() - INTERVAL :minutos MINUTE)'
        );
        $stmt->bindValue(':correo', $correo);
        $stmt->bindValue(':minutos', self::MINUTOS_BLOQUEO, PDO::PARAM_INT);
        $stmt->execute();

        $total = (int) $stmt->fetchColumn();

        return min($total + 1, self::MAXIMO_INTENTOS);
    }

    private function registrarIntento(?int $idUsuario, string $correo, string $ip, bool $exitoso): void
    {
        try {
            $numeroIntento = $exitoso ? 1 : $this->calcularNumeroIntento($correo);

            $stmt = $this->conexion->prepare(
                'INSERT INTO intento_login (id_usuario, correo_ingresado, ip, exitoso, numero_intento)
                 VALUES (:id_usuario, :correo, :ip, :exitoso, :numero_intento)'
            );
            $stmt->execute([
                'id_usuario'     => $idUsuario,
                'correo'         => $correo,
                'ip'             => $ip,
                'exitoso'        => $exitoso ? 1 : 0,
                'numero_intento' => $numeroIntento,
            ]);
        } catch (\PDOException $e) {
            $this->manejadorErrores->registrarError(
                $e->getMessage(),
                'AuthService::registrarIntento',
                ['correo' => $correo, 'ip' => $ip]
            );
        }
    }
}
