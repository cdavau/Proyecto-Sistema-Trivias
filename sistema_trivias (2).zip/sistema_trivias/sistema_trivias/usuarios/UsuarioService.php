<?php

namespace App\Usuarios;

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Interfaces\ManejadorErroresInterface;
use App\Interfaces\UsuarioInterface;
use App\Interfaces\ValidadorInterface;
use PDO;
use PDOException;

/**
 * UsuarioService
 *
 * Módulo de Usuarios (Altas, Bajas y Consultas) - CRUD completo.
 * Incluye el registro público de usuarios nuevos.
 *
 * Reglas aplicadas:
 * - Toda entrada se sanitiza/valida con Validador antes de tocar la BD.
 * - Las contraseñas nunca se guardan en texto plano (password_hash).
 * - "Eliminar" es baja lógica (estado = inactivo), no se borra el registro.
 * - Correo y apodo son únicos (se valida antes de insertar).
 */
class UsuarioService implements UsuarioInterface
{
    private PDO $conexion;

    public function __construct(
        private Database $database,
        private ValidadorInterface $validador,
        private ManejadorErroresInterface $manejadorErrores
    ) {
        $this->conexion = $this->database->obtenerConexion();
    }

    public function crear(string $nombre, string $apodo, string $cedula, string $correo, string $password, int $idRol = 1): int
    {
        $nombreValido = $this->validador->validarTextoObligatorio($nombre, 'nombre', 3, 100);
        $apodoValido  = $this->validador->validarTextoObligatorio($apodo, 'apodo', 3, 50);
        $cedulaValida = $this->validador->validarCedula($cedula);
        $correoValido = $this->validador->validarCorreo($correo);
        $passwordOk   = $this->validador->validarPassword($password);
        $rolValido    = $this->validador->validarEntero($idRol, 1, 3);

        if (!$nombreValido || !$apodoValido || !$cedulaValida || !$correoValido || !$passwordOk || $rolValido === null) {
            throw new AutenticacionException(implode(' ', $this->validador->obtenerErrores()));
        }

        $stmt = $this->conexion->prepare(
            'SELECT id_usuario FROM usuario WHERE correo = :correo OR apodo = :apodo OR cedula = :cedula LIMIT 1'
        );
        $stmt->execute(['correo' => $correoValido, 'apodo' => $apodoValido, 'cedula' => $cedulaValida]);

        if ($stmt->fetch()) {
            throw new AutenticacionException('El correo, el apodo o la cédula ya están registrados.');
        }

        $passwordHash = password_hash($password, PASSWORD_BCRYPT);

        try {
            $stmt = $this->conexion->prepare(
                'INSERT INTO usuario (nombre, apodo, cedula, correo, password_hash, id_rol, estado)
                 VALUES (:nombre, :apodo, :cedula, :correo, :password_hash, :id_rol, "activo")'
            );
            $stmt->execute([
                'nombre'        => $nombreValido,
                'apodo'         => $apodoValido,
                'cedula'        => $cedulaValida,
                'correo'        => $correoValido,
                'password_hash' => $passwordHash,
                'id_rol'        => $rolValido,
            ]);

            return (int) $this->conexion->lastInsertId();

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'UsuarioService::crear');
            throw new AutenticacionException('No se pudo registrar el usuario. Intenta nuevamente.');
        }
    }

    public function listar(): array
    {
        $stmt = $this->conexion->query(
            'SELECT u.id_usuario, u.nombre, u.apodo, u.cedula, u.correo, u.avatar,
                    u.puntos_totales, u.estado, u.fecha_registro,
                    u.id_rol, r.nombre_rol
             FROM usuario u
             JOIN rol r ON r.id_rol = u.id_rol
             ORDER BY u.id_usuario DESC'
        );

        return $stmt->fetchAll();
    }

    public function obtenerPorId(int $idUsuario): ?array
    {
        $stmt = $this->conexion->prepare(
            'SELECT u.id_usuario, u.nombre, u.apodo, u.cedula, u.correo, u.avatar,
                    u.puntos_totales, u.estado, u.fecha_registro,
                    u.id_rol, r.nombre_rol
             FROM usuario u
             JOIN rol r ON r.id_rol = u.id_rol
             WHERE u.id_usuario = :id
             LIMIT 1'
        );
        $stmt->execute(['id' => $idUsuario]);

        $usuario = $stmt->fetch();

        return $usuario ?: null;
    }

    public function actualizar(int $idUsuario, array $datos): bool
    {
        $camposPermitidos = ['nombre', 'apodo', 'cedula', 'correo', 'avatar', 'id_rol', 'estado', 'password'];
        $sets = [];
        $parametros = ['id' => $idUsuario];

        foreach ($datos as $campo => $valor) {
            if (!in_array($campo, $camposPermitidos, true)) {
                continue; 
            }

            if ($campo === 'password') {
                if ($valor === '' || $valor === null) {
                    continue; 
                }
                if (!$this->validador->validarPassword($valor)) {
                    throw new AutenticacionException(implode(' ', $this->validador->obtenerErrores()));
                }
                $campo = 'password_hash';
                $valor = password_hash($valor, PASSWORD_BCRYPT);
                $sets[] = "{$campo} = :{$campo}";
                $parametros[$campo] = $valor;
                continue;
            }

           
            if ($campo === 'correo') {
                $valor = $this->validador->validarCorreo($valor);
                if ($valor === null) {
                    throw new AutenticacionException('Correo inválido.');
                }
            } elseif ($campo === 'cedula') {
                $valor = $this->validador->validarCedula($valor);
                if ($valor === null) {
                    throw new AutenticacionException('Cédula inválida.');
                }
            } elseif (in_array($campo, ['nombre', 'apodo', 'avatar'], true)) {
                $valor = $this->validador->sanitizarTexto($valor);
            } elseif ($campo === 'estado') {
                $valor = $this->validador->validarEnLista($valor, ['activo', 'inactivo', 'bloqueado'], 'estado');
                if ($valor === null) {
                    throw new AutenticacionException('Estado inválido.');
                }
            } elseif ($campo === 'id_rol') {
                $valor = $this->validador->validarEntero($valor, 1, 3);
                if ($valor === null) {
                    throw new AutenticacionException('Rol inválido.');
                }
            }

            $sets[] = "{$campo} = :{$campo}";
            $parametros[$campo] = $valor;
        }

        if (empty($sets)) {
            return false; 
        }

        try {
            $sql = 'UPDATE usuario SET ' . implode(', ', $sets) . ' WHERE id_usuario = :id';
            $stmt = $this->conexion->prepare($sql);
            return $stmt->execute($parametros);

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'UsuarioService::actualizar');
            throw new AutenticacionException('No se pudo actualizar el usuario.');
        }
    }

    public function eliminar(int $idUsuario): bool
    {
        try {
            $stmt = $this->conexion->prepare(
                'UPDATE usuario SET estado = "inactivo" WHERE id_usuario = :id'
            );
            return $stmt->execute(['id' => $idUsuario]);

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'UsuarioService::eliminar');
            throw new AutenticacionException('No se pudo eliminar el usuario.');
        }
    }
}
