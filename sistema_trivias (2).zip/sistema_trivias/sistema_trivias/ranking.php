<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Juego\RankingService;
use App\Utils\SesionUtil;

SesionUtil::iniciar();
if (!SesionUtil::estaAutenticado()) {
    header('Location: login.php');
    exit;
}

$db = Database::obtenerInstancia();
$rankingService = new RankingService($db);

$rankingPuntos = $rankingService->obtenerRankingPuntos(10);
$rankingVelocidad = $rankingService->obtenerRankingVelocidad(10);

function iniciales_avatar(string $avatar = null, string $nombre = ''): string
{
    if ($avatar && !str_starts_with($avatar, 'uploads/')) {
        return $avatar; 
    }
    return '👤';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ranking — Trivias UTP</title>
<link rel="stylesheet" href="assets/estilo.css">
<style>
    .contenedor { max-width: 820px; margin: 0 auto; padding: 44px 24px; }
    .volver { display: inline-block; margin-bottom: 20px; color: var(--text-muted); text-decoration: none; font-size: 13px; }

    .grid-rankings { display: grid; grid-template-columns: 1fr 1fr; gap: 22px; margin-top: 26px; }
    @media (max-width: 700px) { .grid-rankings { grid-template-columns: 1fr; } }

    .fila-ranking {
        display: flex; align-items: center; gap: 12px;
        padding: 12px 0; border-bottom: 1px solid rgba(255,255,255,0.08);
    }
    .fila-ranking:last-child { border-bottom: none; }
    .puesto {
        width: 28px; height: 28px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-weight: 800; font-size: 13px; flex-shrink: 0;
        background: rgba(255,255,255,0.08); color: var(--text-muted);
    }
    .puesto.oro { background: linear-gradient(180deg, var(--yellow), #ffb703); color: #1a1140; }
    .puesto.plata { background: #d8d8e8; color: #1a1140; }
    .puesto.bronce { background: #e0a978; color: #1a1140; }

    .avatar-mini {
        width: 34px; height: 34px; border-radius: 50%; flex-shrink: 0;
        background: rgba(255,255,255,0.08); display: flex; align-items: center; justify-content: center;
        font-size: 17px; overflow: hidden;
    }
    .avatar-mini img { width: 100%; height: 100%; object-fit: cover; }

    .info-jugador { flex: 1; }
    .info-jugador .nombre { font-weight: 700; font-size: 14px; }
    .info-jugador .apodo { font-size: 12px; color: var(--text-muted); }

    .valor-metrica { font-family: 'Space Mono', monospace; font-weight: 700; color: var(--yellow); }
</style>
</head>
<body>
<div class="contenedor">
    <a href="dashboard.php" class="volver">← Volver a mi marcador</a>
    <span class="eyebrow">📊 Estadísticas</span>
    <h1 style="margin: 14px 0 6px;">Ranking de jugadores</h1>
    <p style="color: var(--text-muted); font-size: 14px;">Los mejores puntajes y las respuestas más rápidas del sistema.</p>

    <div class="grid-rankings">
        <div class="tarjeta">
            <h3 style="margin-bottom: 4px;">🏆 Top puntos</h3>
            <?php if (empty($rankingPuntos)): ?>
                <p style="color: var(--text-muted); font-size: 13px;">Todavía no hay jugadores con puntos.</p>
            <?php endif; ?>
            <?php foreach ($rankingPuntos as $i => $j): ?>
                <?php $medalla = ['oro', 'plata', 'bronce'][$i] ?? ''; ?>
                <div class="fila-ranking">
                    <div class="puesto <?= $medalla ?>"><?= $i + 1 ?></div>
                    <div class="avatar-mini">
                        <?php if (!empty($j['avatar']) && str_starts_with($j['avatar'], 'uploads/')): ?>
                            <img src="<?= htmlspecialchars($j['avatar']) ?>" alt="">
                        <?php else: ?>
                            <?= $j['avatar'] ?: '👤' ?>
                        <?php endif; ?>
                    </div>
                    <div class="info-jugador">
                        <div class="nombre"><?= htmlspecialchars($j['nombre']) ?></div>
                        <div class="apodo">@<?= htmlspecialchars($j['apodo']) ?></div>
                    </div>
                    <div class="valor-metrica"><?= (int) $j['puntos_totales'] ?> pts</div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="tarjeta">
            <h3 style="margin-bottom: 4px;">⚡ Más rápidos</h3>
            <?php if (empty($rankingVelocidad)): ?>
                <p style="color: var(--text-muted); font-size: 13px;">Todavía no hay partidas completadas.</p>
            <?php endif; ?>
            <?php foreach ($rankingVelocidad as $i => $j): ?>
                <?php $medalla = ['oro', 'plata', 'bronce'][$i] ?? ''; ?>
                <div class="fila-ranking">
                    <div class="puesto <?= $medalla ?>"><?= $i + 1 ?></div>
                    <div class="avatar-mini">
                        <?php if (!empty($j['avatar']) && str_starts_with($j['avatar'], 'uploads/')): ?>
                            <img src="<?= htmlspecialchars($j['avatar']) ?>" alt="">
                        <?php else: ?>
                            <?= $j['avatar'] ?: '👤' ?>
                        <?php endif; ?>
                    </div>
                    <div class="info-jugador">
                        <div class="nombre"><?= htmlspecialchars($j['nombre']) ?></div>
                        <div class="apodo">@<?= htmlspecialchars($j['apodo']) ?></div>
                    </div>
                    <div class="valor-metrica"><?= number_format((float) $j['velocidad_promedio'], 1) ?>s</div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
</body>
</html>
