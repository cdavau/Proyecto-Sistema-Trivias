<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Temas\TemaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\Roles;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::requerirRol([Roles::ARMADOR, Roles::ADMINISTRADOR]);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: gestion_temas.php');
    exit;
} \App\Utils\Csrf::validar();

$db = Database::obtenerInstancia();
$temaService = new TemaService($db, new Validador(), new ManejadorErroresArchivo());

$idTemaNivel = (int) ($_POST['id_tema_nivel'] ?? 0);

try {
    $temaService->eliminarTemaNivel($idTemaNivel);
    header('Location: gestion_temas.php?exito=eliminado');
    exit;

} catch (AutenticacionException $e) {
    header('Location: gestion_temas.php?error=' . urlencode($e->getMessage()));
    exit;
}
