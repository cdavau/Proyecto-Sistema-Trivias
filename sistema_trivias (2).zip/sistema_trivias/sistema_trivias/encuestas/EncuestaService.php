<?php

namespace App\Encuestas;

use App\Config\Database;
use App\Exceptions\AutenticacionException;
use App\Interfaces\EncuestaInterface;
use App\Interfaces\ManejadorErroresInterface;
use App\Interfaces\ValidadorInterface;
use PDO;
use PDOException;

class EncuestaService implements EncuestaInterface
{
    private PDO $conexion;

    public function __construct(
        private Database $database,
        private ValidadorInterface $validador,
        private ManejadorErroresInterface $manejadorErrores
    ) {
        $this->conexion = $this->database->obtenerConexion();
    }

    public function crearEncuesta(string $preguntaEncuesta): int
    {
        $preguntaValida = $this->validador->validarTextoObligatorio($preguntaEncuesta, 'pregunta_encuesta', 5, 255);

        if (!$preguntaValida) {
            throw new AutenticacionException(implode(' ', $this->validador->obtenerErrores()));
        }

        $stmt = $this->conexion->prepare('INSERT INTO encuesta (pregunta_encuesta) VALUES (:pregunta)');
        $stmt->execute(['pregunta' => $preguntaValida]);

        return (int) $this->conexion->lastInsertId();
    }

    public function listarEncuestas(): array
    {
        $stmt = $this->conexion->query('SELECT id_encuesta, pregunta_encuesta, fecha_creacion FROM encuesta ORDER BY fecha_creacion DESC');
        return $stmt->fetchAll();
    }

    public function registrarRespuesta(int $idEncuesta, ?string $nombreContacto, string $respuestaTexto): int
    {
        $respuestaValida = $this->validador->validarTextoObligatorio($respuestaTexto, 'respuesta', 2, 500);
        $nombreValido = $nombreContacto ? $this->validador->sanitizarTexto($nombreContacto) : null;

        if (!$respuestaValida) {
            throw new AutenticacionException(implode(' ', $this->validador->obtenerErrores()));
        }

        try {
            $stmt = $this->conexion->prepare(
                'INSERT INTO respuesta_encuesta (id_encuesta, nombre_contacto, respuesta_texto)
                 VALUES (:id_encuesta, :nombre_contacto, :respuesta_texto)'
            );
            $stmt->execute([
                'id_encuesta' => $idEncuesta,
                'nombre_contacto' => $nombreValido,
                'respuesta_texto' => $respuestaValida,
            ]);

            return (int) $this->conexion->lastInsertId();

        } catch (PDOException $e) {
            $this->manejadorErrores->registrarError($e->getMessage(), 'EncuestaService::registrarRespuesta');
            throw new AutenticacionException('No se pudo registrar tu respuesta. Intenta nuevamente.');
        }
    }

    public function listarRespuestas(int $idEncuesta): array
    {
        $stmt = $this->conexion->prepare(
            'SELECT id_respuesta_encuesta, nombre_contacto, respuesta_texto, fecha
             FROM respuesta_encuesta WHERE id_encuesta = :id ORDER BY fecha DESC'
        );
        $stmt->execute(['id' => $idEncuesta]);
        return $stmt->fetchAll();
    }
}
