<?php

require_once __DIR__ . '/bootstrap.php';

use App\Config\Database;
use App\Juego\JuegoService;
use App\Preguntas\PreguntaService;
use App\Utils\ManejadorErroresArchivo;
use App\Utils\SesionUtil;
use App\Utils\Validador;

SesionUtil::iniciar();
if (!SesionUtil::estaAutenticado()) {
    header('Location: login.php');
    exit;
}

$usuarioSesion = SesionUtil::usuarioActual();
$idTemaNivel = (int) ($_GET['id_tema_nivel'] ?? 0);

$db = Database::obtenerInstancia();
$juegoService = new JuegoService($db, new ManejadorErroresArchivo());
$preguntaService = new PreguntaService($db, new Validador(), new ManejadorErroresArchivo());

if (!$juegoService->nivelDesbloqueado((int) $usuarioSesion['id_usuario'], $idTemaNivel)) {
    header('Location: jugar.php?error=nivel_bloqueado');
    exit;
}

$preguntas = $preguntaService->listarPorTemaNivel($idTemaNivel);

if (empty($preguntas)) {
    header('Location: jugar.php?error=sin_preguntas');
    exit;
}

shuffle($preguntas);
$preguntas = array_slice($preguntas, 0, 5);

$idPartidaJugador = $juegoService->iniciarPartida((int) $usuarioSesion['id_usuario'], $idTemaNivel);

$_SESSION['partida_actual'] = [
    'id_partida_jugador' => $idPartidaJugador,
    'id_tema_nivel' => $idTemaNivel,
    'ids_preguntas' => array_column($preguntas, 'id_pregunta'),
    'indice' => 0,
    'total_correctas' => 0,
];

header('Location: responder_pregunta.php');
exit;
